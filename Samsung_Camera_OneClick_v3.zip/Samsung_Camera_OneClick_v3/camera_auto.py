#!/usr/bin/env python3
"""Best-effort, fail-closed automation of REAL camera capture inside six Android apps.

Requires only Python 3.10+ and Android Platform Tools (adb). No Appium server.
Captures only from the applications' own UIs. Screenshots are diagnostic only.
Stops rather than guessing on ambiguous Save/Share controls.
"""
from __future__ import annotations
import argparse
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import re
import shutil
import struct
import subprocess
import sys
import time
import xml.etree.ElementTree as ET

BASE = Path(__file__).resolve().parent
CONFIG = BASE / "config.json"
PHOTO_SUFFIXES = {".jpg", ".jpeg", ".heic", ".heif", ".png", ".webp", ".dng"}
VIDEO_SUFFIXES = {".mp4", ".mov", ".3gp", ".mkv", ".webm"}
ALL_SUFFIXES = PHOTO_SUFFIXES | VIDEO_SUFFIXES
# Safety: never select publishing or messaging buttons, including ambiguous 'Your Story' in an editor.
DANGEROUS = re.compile(r"\b(post(?:ing)?|publish|send|share(?:\s+to)?|broadcast|go\s+live|add\s+to\s+(?:your\s+)?story|add\s+to\s+status)\b", re.I)
SAVE_LABELS = ["Save to device", "Save to gallery", "Save photo", "Save video", "Download video", "Download photo", "Download", "Save", "Save image"]
MORE_LABELS = ["More options", "More", "Options", "Menu"]
CAMERA_LABELS = ["Open camera", "Camera", "Camera icon", "Take photo"]
PHOTO_SHUTTER_LABELS = ["Take picture", "Take photo", "Capture photo", "Photo shutter", "Shutter", "Capture", "Take a photo", "camera_shutter", "shutter_button", "capture_button"]
VIDEO_START_LABELS = ["Start recording", "Record video", "Start video recording", "Record", "Video shutter", "record_button", "video_capture_button"]
VIDEO_STOP_LABELS = ["Stop recording", "Stop video", "Stop", "End recording", "stop_recording", "stop_button"]
VIDEO_MODE_LABELS = ["Video", "VIDEO", "Video mode", "Switch to video"]
PHOTO_MODE_LABELS = ["Photo", "PHOTO", "Photo mode", "Switch to photo"]
CAMERA_HINTS = ["shutter", "capture", "flip camera", "switch camera", "flash", "timer", "filters", "effects", "camera mode", "video mode", "photo mode", "gallery", "front camera", "rear camera", "wide", "ultra wide", "portrait"]


def stamp():
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def iso():
    return datetime.now(timezone.utc).isoformat()


def valid_kind(path):
    suffix = Path(path).suffix.lower()
    if suffix in PHOTO_SUFFIXES:
        return "photo"
    if suffix in VIDEO_SUFFIXES:
        return "video"
    return None


def hash_file(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def actual_type(path: Path):
    """Fast header sniffing; does not claim full decode/codec validity."""
    with path.open("rb") as f:
        head = f.read(64)
    if head.startswith(b"\xff\xd8\xff") or head.startswith(b"\x89PNG\r\n\x1a\n") or head.startswith(b"RIFF") and head[8:12] == b"WEBP":
        return "photo"
    if head[4:8] == b"ftyp":
        brands = head[8:32].lower()
        if any(b in brands for b in (b"heic", b"heix", b"hevc", b"mif1", b"msf1", b"avif")):
            return "photo"
        return "video"
    if head.startswith(b"\x1a\x45\xdf\xa3"):
        return "video"
    if head[:4] in (b"II*\x00", b"MM\x00*"):
        return "photo"
    return "unknown"


def probe(path: Path):
    ff = shutil.which("ffprobe")
    if not ff:
        return {"note": "ffprobe not installed; metadata not checked"}
    try:
        p = subprocess.run([ff, "-v", "error", "-show_entries", "format=duration:stream=codec_type,codec_name,width,height", "-of", "json", str(path)], capture_output=True, text=True, timeout=40)
        return json.loads(p.stdout) if p.returncode == 0 else {"error": p.stderr[:300]}
    except (ValueError, subprocess.TimeoutExpired) as exc:
        return {"error": str(exc)}


class DeviceError(RuntimeError):
    pass


class UiError(RuntimeError):
    pass


class Adb:
    def __init__(self, serial: str | None = None, executable: str = "adb"):
        self.serial, self.executable = serial, executable

    def call(self, *params, check=True, binary=False, timeout=70):
        cmd = [self.executable] + (["-s", self.serial] if self.serial else []) + [str(x) for x in params]
        try:
            p = subprocess.run(cmd, capture_output=True, timeout=timeout)
        except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
            raise DeviceError(f"ADB failed: {exc}") from exc
        if check and p.returncode:
            raise DeviceError(f"{' '.join(cmd)}: {p.stderr.decode(errors='replace')[-400:]}")
        return p.stdout if binary else p.stdout.decode(errors="replace").strip()

    def shell(self, *cmd, check=True, timeout=70):
        return self.call("shell", *cmd, check=check, timeout=timeout)

    def devices(self):
        output = self.call("devices", "-l")
        return [line.split()[0] for line in output.splitlines()[1:] if re.search(r"\sdevice(?:\s|$)", line)]

    def package_installed(self, package):
        # Exact package check; do not mistake similarly named packages.
        text = self.shell("pm", "path", package, check=False)
        return text.startswith("package:")

    def launch(self, package):
        result = self.shell("monkey", "-p", package, "-c", "android.intent.category.LAUNCHER", "1", timeout=100)
        if "Events injected: 1" not in result:
            raise DeviceError(f"Unable to launch {package}: {result[-500:]}")
        time.sleep(3)

    def tap(self, x, y):
        self.shell("input", "tap", str(round(x)), str(round(y)))

    def press(self, x, y, ms):
        self.shell("input", "swipe", str(round(x)), str(round(y)), str(round(x)), str(round(y)), str(int(ms)), timeout=max(70, ms / 1000 + 15))

    def back(self):
        self.shell("input", "keyevent", "KEYCODE_BACK")
        time.sleep(1.2)

    def screenshot(self, where: Path):
        where.parent.mkdir(parents=True, exist_ok=True)
        where.write_bytes(self.call("exec-out", "screencap", "-p", binary=True))
        return where

    def screen_size(self):
        data = self.call("exec-out", "screencap", "-p", binary=True)
        if data[:8] != b"\x89PNG\r\n\x1a\n":
            raise DeviceError("Cannot determine screen dimensions from screenshot")
        return struct.unpack(">II", data[16:24])

    def xml(self):
        remote = "/sdcard/cameraqa_accessibility.xml"
        self.shell("uiautomator", "dump", remote, check=False, timeout=40)
        text = self.call("exec-out", "cat", remote, check=False)
        if not text.lstrip().startswith("<?xml") and not text.lstrip().startswith("<hierarchy"):
            raise UiError("No accessibility hierarchy; app may use custom-drawn controls")
        try:
            return ET.fromstring(text), text
        except ET.ParseError as exc:
            raise UiError("Android UI hierarchy is unavailable") from exc

    def scan(self, roots):
        # Only public/media storage. Do not read another app's protected data.
        paths = set()
        for root in roots:
            output = self.shell("find", root, "-type", "f", check=False, timeout=90)
            for line in output.splitlines():
                path = line.strip().replace("\r", "")
                if path.startswith("/sdcard/") and valid_kind(path):
                    paths.add(path)
        return paths

    def pull(self, remote, local: Path):
        local.parent.mkdir(parents=True, exist_ok=True)
        return self.call("pull", remote, str(local), check=False, timeout=150)


@dataclass
class UiNode:
    label: str
    desc: str
    rid: str
    bounds: tuple[int, int, int, int]
    clickable: bool
    enabled: bool
    @property
    def center(self):
        x1, y1, x2, y2 = self.bounds
        return ((x1 + x2) / 2, (y1 + y2) / 2)
    @property
    def token(self):
        return " | ".join(s for s in (self.label, self.desc, self.rid.split("/")[-1]) if s)


def parse_bounds(value):
    nums = re.findall(r"\d+", value)
    return tuple(int(n) for n in nums) if len(nums) == 4 else (0, 0, 0, 0)


def nodes_from_xml(root):
    items = []
    def walk(el, parents):
        a = el.attrib
        if el.tag == "node":
            box = parse_bounds(a.get("bounds", ""))
            cur = UiNode(a.get("text", ""), a.get("content-desc", ""), a.get("resource-id", ""), box, a.get("clickable") == "true", a.get("enabled", "true") == "true")
            items.append((cur, parents))
            parents = parents + [cur]
        for child in el:
            walk(child, parents)
    walk(root, [])
    return items


def safe_match(candidate: str, phrase: str):
    token, needle = candidate.lower().strip(), phrase.lower().strip()
    if not token or not needle:
        return 0
    if token == needle:
        return 120
    if token.startswith(needle + " ") or token.endswith(" " + needle):
        return 100
    # Labels may include content descriptor with multiple words and localized resource ids.
    if re.search(r"(?<![a-z])" + re.escape(needle) + r"(?![a-z])", token):
        return 75
    if needle.replace(" ", "_") in token:
        return 65
    return 0


class Ui:
    def __init__(self, adb: Adb, evidence: Path, fallback: bool = True):
        self.adb, self.evidence, self.fallback = adb, evidence, fallback
        self.logs = []
        self.size = adb.screen_size()
        self.root, self.raw_xml = None, ""
        self.items = []

    def refresh(self):
        root, text = self.adb.xml()
        self.root, self.raw_xml = root, text
        self.items = nodes_from_xml(root)
        return self

    def find(self, phrases, region=None):
        if isinstance(phrases, str):
            phrases = [phrases]
        # Score exact/description/id labels; never tap publishing controls.
        choices = []
        w, h = self.size
        for node, parents in self.items:
            if not node.enabled:
                continue
            label = node.token
            if DANGEROUS.search(label):
                continue
            scores = [safe_match(label, phrase) for phrase in phrases]
            score = max(scores, default=0)
            if not score:
                continue
            target = node if node.clickable else next((p for p in reversed(parents) if p.clickable and p.enabled), node)
            x, y = target.center
            if region == "top_right" and not (x > 0.60 * w and y < 0.30 * h):
                continue
            if region == "bottom" and y < 0.45 * h:
                continue
            if target.bounds == (0, 0, 0, 0):
                continue
            # Give a small preference to directly clickable / smaller targets, not oversized parents.
            score += 5 if node.clickable else 0
            area = (target.bounds[2] - target.bounds[0]) * (target.bounds[3] - target.bounds[1])
            choices.append((score, -area, target, label))
        if not choices:
            return None
        choices.sort(key=lambda p: (p[0], p[1]), reverse=True)
        return choices[0][2], choices[0][3]

    def action(self, labels, name, required=True, region=None, tries=2):
        for _ in range(tries):
            self.refresh()
            found = self.find(labels, region=region)
            if found:
                item, token = found
                self.adb.tap(*item.center)
                self.logs.append({"action": name, "via": "accessibility", "matched": token, "at": iso()})
                time.sleep(1.25)
                return True
            time.sleep(0.7)
        if required:
            raise UiError(f"Could not find safe {name} button. Look at the saved diagnostic screenshot/XML.")
        return False

    def tap_normalized(self, point, name, only_camera=True, hold_ms=0):
        if not self.fallback:
            raise UiError(f"{name} requires a custom camera shutter; fallback is disabled")
        self.refresh()
        if only_camera and not self.camera_ready():
            raise UiError(f"Refusing coordinate {name} tap: camera screen is not confirmed")
        if any(DANGEROUS.search(node.token) for node, _ in self.items if node.clickable and node.center[1] > 0.5*self.size[1]):
            raise UiError(f"Refusing coordinate {name}: editor may contain Share/Post/Send controls")
        w, h = self.size
        x, y = point
        if not (0 <= x <= 1 and 0 <= y <= 1):
            raise ValueError("Normalized coordinates must be between 0 and 1")
        X, Y = w*x, h*y
        if hold_ms:
            self.adb.press(X, Y, hold_ms)
        else:
            self.adb.tap(X, Y)
        self.logs.append({"action": name, "via": "normalized camera shutter fallback", "xy": point, "at": iso()})
        time.sleep(1.5)

    def camera_ready(self):
        alltext = " ".join(n.token.lower() for n, _ in self.items)
        distinct = sum(1 for hint in CAMERA_HINTS if hint in alltext)
        shutter = any(h in alltext for h in ("shutter", "capture_button", "camera_capture", "take picture", "take photo", "record button"))
        return shutter or distinct >= 2

    def evidence_dump(self, prefix):
        self.evidence.mkdir(parents=True, exist_ok=True)
        unique = f"{prefix}_{stamp()}_{len(self.logs)}"
        self.adb.screenshot(self.evidence / f"{unique}.png")
        try:
            self.refresh()
            (self.evidence / f"{unique}.xml").write_text(self.raw_xml, encoding="utf-8")
        except UiError:
            pass


def use_permissions(ui):
    # Grant one-time foreground permissions, never click login/account/share actions.
    for _ in range(4):
        try:
            ui.refresh()
        except UiError:
            break
        text = " ".join(n.token.lower() for n, _ in ui.items)
        if not any(t in text for t in ("permission", "while using", "allow access", "only this time", "allow camera", "allow microphone")):
            break
        if not ui.action(["While using the app", "Only this time", "Allow", "Allow all"], "foreground permission", required=False):
            break


def story_entry(ui: Ui, app):
    # Only enter Story creation, never click a Share/Post control.
    entry = {"instagram": ["Create story", "Story", "Open camera", "Camera"],
             "facebook": ["Create story", "Create a story", "Create Story", "Camera"]}[app]
    # For Instagram, swipe right from feed can open the camera in some builds, but only
    # if the current UI is recognizable as a feed. Avoid guessed taps on user content.
    for attempt in range(4):
        ui.refresh()
        if ui.camera_ready():
            return
        selected = False
        if app == "facebook":
            selected = ui.action(entry, "enter Facebook Story camera", required=False)
        else:
            selected = ui.action(entry, "enter Instagram Story camera", required=False)
            if not selected and attempt == 0:
                text = " ".join(n.token.lower() for n, _ in ui.items)
                if any(k in text for k in ("home", "search", "reels", "profile")):
                    w, h = ui.size
                    ui.adb.shell("input", "swipe", str(round(w*.15)), str(round(h*.47)), str(round(w*.85)), str(round(h*.47)), "380")
                    ui.logs.append({"action": "open Story camera", "via": "Instagram home swipe"})
                    selected = True
                    time.sleep(2)
        if not selected:
            break
    ui.refresh()
    if not ui.camera_ready():
        raise UiError("Story live camera not confirmed. Check login/permissions and app version; not tapping unknown controls.")


def whatsapp_entry(ui):
    ui.refresh()
    # User-provided flow: top-right camera icon. Require matching label in that region.
    if not ui.action(CAMERA_LABELS, "WhatsApp top-right camera icon", required=False, region="top_right"):
        raise UiError("WhatsApp top-right camera icon was not identifiable; refusing to open chat or Status instead.")
    ui.refresh()
    if not ui.camera_ready():
        raise UiError("WhatsApp live camera not confirmed")


def ensure_camera(ui, key):
    ui.refresh()
    if ui.camera_ready():
        return
    if key in ("facebook", "instagram"):
        story_entry(ui, key)
    elif key == "whatsapp":
        whatsapp_entry(ui)
    else:
        # Native/beauty apps often have onboarding. If no camera UI, stop safely.
        raise UiError("Live in-app camera not confirmed; complete any onboarding/permissions and inspect the camera")


def change_mode(ui, mode):
    terms = PHOTO_MODE_LABELS if mode == "photo" else VIDEO_MODE_LABELS
    ui.action(terms, f"choose {mode} mode", required=False, region="bottom")


def shutter(ui, config, name, record_ms=0):
    labels = VIDEO_START_LABELS if record_ms else PHOTO_SHUTTER_LABELS
    # For a hold, choose a detected element but perform swipe-hold instead of tap.
    if record_ms:
        ui.refresh()
        found = ui.find(labels)
        if not found:
            found = ui.find(PHOTO_SHUTTER_LABELS)
        if found:
            obj, token = found
            ui.adb.press(*obj.center, record_ms)
            ui.logs.append({"action": name, "via": "press-and-hold", "matched": token, "duration_ms": record_ms})
            time.sleep(1.5)
            return
        ui.tap_normalized(config["shutter"], name, hold_ms=record_ms)
    else:
        if not ui.action(labels, name, required=False):
            ui.tap_normalized(config["shutter"], name)


def stop_video(ui, config):
    if not ui.action(VIDEO_STOP_LABELS, "stop video recording", required=False):
        ui.tap_normalized(config["shutter"], "stop video recording")


def try_save(ui, required):
    ui.refresh()
    # Direct save control, not generic share/send/post. Exact 'Save' may also mean
    # Save draft; media verification below will catch missing exported files.
    if ui.action(SAVE_LABELS, "save captured media locally", required=False):
        return True
    if ui.action(MORE_LABELS, "open editor options", required=False, region="top_right"):
        if ui.action(SAVE_LABELS, "save captured media locally from menu", required=False):
            return True
    if required:
        raise UiError("No safe Save/Download control found. Refusing to tap unknown Story/Send buttons.")
    return False


def return_to_camera(ui, key, package):
    ui.refresh()
    if ui.camera_ready():
        return
    # Leave preview to live camera after local save; back never sends or publishes.
    ui.adb.back()
    ui.refresh()
    if ui.camera_ready():
        return
    if key in ("facebook", "instagram"):
        story_entry(ui, key)
    elif key == "whatsapp":
        # If Back exited camera, top-right camera can re-open it.
        whatsapp_entry(ui)
    else:
        raise UiError("After saving, app did not return to live camera")


def await_new_media(adb, baseline, roots, kind, seconds):
    deadline = time.monotonic() + seconds
    last = set()
    while time.monotonic() < deadline:
        current = adb.scan(roots)
        new = {p for p in current - baseline if valid_kind(p) == kind}
        if new:
            # Give video encoders / media scanner time to close the file.
            time.sleep(1.5)
            return sorted(new)
        last = current
        time.sleep(1.4)
    return []


def collect(adb, paths, into):
    output = []
    for remote in sorted(set(paths)):
        rel = remote.removeprefix("/sdcard/")
        local = into / rel
        result = adb.pull(remote, local)
        record = {"remote": remote, "local": str(local), "kind": valid_kind(remote), "ok": False}
        if local.is_file() and local.stat().st_size > 1024 and not result.lower().startswith("adb: error"):
            record.update({"ok": True, "bytes": local.stat().st_size, "sha256": hash_file(local), "header_type": actual_type(local)})
            if record["kind"] == "video":
                record["probe"] = probe(local)
            if record["header_type"] != record["kind"]:
                record["ok"] = False
                record["error"] = "File signature and extension do not indicate same media type"
        else:
            record["error"] = "Could not retrieve a valid nonempty file"
        output.append(record)
    return output


def run_app(adb, key, cfg, default_cfg, run_dir, fallback):
    appdir = run_dir / key
    appdir.mkdir(parents=True, exist_ok=True)
    report = {"app": key, "package": cfg["package"], "started_at": iso(), "goal": {"photos": 2, "videos": 1}, "captures": [], "actions": [], "status": "BLOCKED"}
    roots = list(dict.fromkeys(default_cfg["media_roots"] + cfg.get("media_roots", [])))
    ui = None
    try:
        if not adb.package_installed(cfg["package"]):
            raise DeviceError("App package not installed (check config.json for variant/package ID)")
        print(f"\n=== {cfg['name']} ===")
        before = adb.scan(roots)
        adb.launch(cfg["package"])
        ui = Ui(adb, appdir / "diagnostics", fallback=fallback)
        ui.evidence_dump("start")
        use_permissions(ui)
        ensure_camera(ui, key)
        paths_to_copy = set()
        for index in range(1, 4):
            kind = "photo" if index <= 2 else "video"
            name = f"{kind}_{index if kind == 'photo' else 1}"
            print(f"  {name}: capturing...")
            # Save the running baseline before each shutter action, not once per app.
            baseline = adb.scan(roots)
            if kind == "photo":
                change_mode(ui, "photo") if key in ("native", "snow", "soda") else None
                shutter(ui, cfg, name)
                time.sleep(float(default_cfg["photo_settle_seconds"]))
            else:
                seconds = float(default_cfg["video_duration_seconds"])
                if cfg["video_style"] == "hold":
                    shutter(ui, cfg, name, record_ms=int(seconds * 1000))
                else:
                    change_mode(ui, "video")
                    if not ui.action(VIDEO_START_LABELS, "start video recording", required=False):
                        ui.tap_normalized(cfg["shutter"], "start video recording")
                    time.sleep(seconds)
                    stop_video(ui, cfg)
                    time.sleep(2)
            if cfg["save_behavior"] == "explicit":
                try_save(ui, required=True)
            elif cfg["save_behavior"] == "auto_or_explicit":
                # If camera saves automatically, do not tap Save in a gallery/app editor.
                if not await_new_media(adb, baseline, roots, kind, 3.5):
                    try_save(ui, required=False)
            paths = await_new_media(adb, baseline, roots, kind, float(default_cfg["export_timeout_seconds"]))
            if not paths:
                raise UiError(f"No new {kind} file appeared in accessible shared media for {name}. Camera may have saved only to app-private storage, or Save was not successful.")
            # Preserve the exact new media path after each shutter/save operation.
            paths_to_copy.update(paths)
            report["captures"].append({"name": name, "kind": kind, "new_paths": paths, "captured_at": iso()})
            print(f"  {name}: saved {len(paths)} new file(s)")
            if index < 3 and cfg["save_behavior"] != "automatic":
                return_to_camera(ui, key, cfg["package"])
        records = collect(adb, paths_to_copy, appdir / "media")
        report["media"] = records
        verified_photos = sum(1 for r in records if r["ok"] and r["kind"] == "photo")
        verified_videos = sum(1 for r in records if r["ok"] and r["kind"] == "video")
        report["verified"] = {"photos": verified_photos, "videos": verified_videos}
        report["status"] = "PASS" if verified_photos == 2 and verified_videos == 1 and len(report["captures"]) == 3 else "NEEDS_REVIEW"
        if report["status"] != "PASS":
            report["message"] = "Multiple files per operation or verification failure; review results before accepting test"
        ui.evidence_dump("finish")
    except (UiError, DeviceError, ValueError) as exc:
        report["status"] = "NEEDS_ATTENTION"
        report["message"] = str(exc)
        print("  STOPPED:", exc)
        if ui:
            try:
                ui.evidence_dump("failure")
            except Exception:
                pass
        # If already captured some files, extract them to preserve partial work.
        paths_to_copy = set(p for capture in report["captures"] for p in capture["new_paths"])
        if paths_to_copy:
            report["media"] = collect(adb, paths_to_copy, appdir / "media")
    except Exception as exc:
        report["status"] = "ERROR"
        report["message"] = f"Unexpected error: {exc}"
        print("  ERROR:", exc)
        if ui:
            try:
                ui.evidence_dump("failure")
            except Exception:
                pass
    finally:
        if ui:
            report["actions"] = ui.logs
        report["finished_at"] = iso()
        (appdir / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    return report


def main(argv=None):
    p = argparse.ArgumentParser(description="One-command six-app real Android camera capture (best-effort, fails safely)")
    p.add_argument("--config", default=str(CONFIG))
    p.add_argument("--app", choices=["native", "facebook", "instagram", "snow", "whatsapp", "soda"], help="Run only one app")
    p.add_argument("--serial", help="Run on a specific ADB device")
    p.add_argument("--all-devices", action="store_true", help="Run sequentially on all connected authorized devices")
    p.add_argument("--inspect", action="store_true", help="Capture current screen/XML, do not run capture")
    p.add_argument("--no-shutter-fallback", action="store_true", help="Disable normalized camera shutter tap fallback")
    args = p.parse_args(argv)
    cfg = json.loads(Path(args.config).read_text(encoding="utf-8"))
    adb_exe = os.environ.get("ADB_EXE", "adb")
    if not shutil.which(adb_exe) and not Path(adb_exe).exists():
        print("ERROR: adb.exe not found. Install Android SDK Platform-Tools or set ADB_EXE.", file=sys.stderr)
        return 2
    base_adb = Adb(executable=adb_exe)
    serials = base_adb.devices()
    if args.serial:
        if args.serial not in serials:
            print(f"Device '{args.serial}' not authorized/connected. Connected: {serials}", file=sys.stderr)
            return 2
        serials = [args.serial]
    elif not args.all_devices and len(serials) != 1:
        print(f"Connect exactly one authorized device, or use --all-devices/--serial. Connected: {serials}", file=sys.stderr)
        return 2
    if not serials:
        print("No authorized devices. Enable USB debugging and accept the RSA authorization prompt.", file=sys.stderr)
        return 2
    all_reports = []
    run_root = BASE / "results" / stamp()
    run_root.mkdir(parents=True, exist_ok=True)
    if args.inspect:
        for s in serials:
            device = Adb(serial=s, executable=adb_exe)
            ui = Ui(device, run_root / s / "inspect")
            ui.evidence_dump("current_ui")
            print("Inspected", s, "at", ui.evidence)
        return 0
    apps = cfg["apps"] if not args.app else {args.app: cfg["apps"][args.app]}
    for s in serials:
        device = Adb(serial=s, executable=adb_exe)
        print(f"\nDEVICE: {s}")
        for name, item in apps.items():
            all_reports.append({"device": s, **run_app(device, name, item, cfg["defaults"], run_root / s, not args.no_shutter_fallback)})
    success = sum(r["status"] == "PASS" for r in all_reports)
    print(f"\nRESULT: {success}/{len(all_reports)} applications PASSED")
    print("Reports, media and diagnostic screenshots:", run_root)
    (run_root / "summary.json").write_text(json.dumps({"started_at": iso(), "reports": all_reports}, indent=2, ensure_ascii=False), encoding="utf-8")
    return 0 if success == len(all_reports) else 1


if __name__ == "__main__":
    raise SystemExit(main())
