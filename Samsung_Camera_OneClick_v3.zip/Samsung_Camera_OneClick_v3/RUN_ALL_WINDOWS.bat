@echo off
setlocal
cd /d "%~dp0"
echo ===============================================
echo Samsung six-app Camera QA - best effort automation
echo ===============================================
echo.
where adb >nul 2>nul
if errorlevel 1 (
    if exist "%~dp0platform-tools\adb.exe" (
        set "ADB_EXE=%~dp0platform-tools\adb.exe"
    ) else (
        echo ERROR: adb.exe not found.
        echo Install Android SDK Platform-Tools, put adb on PATH,
        echo or extract platform-tools into this project folder.
        echo Official: https://developer.android.com/tools/releases/platform-tools
        pause
        exit /b 2
    )
)
where py >nul 2>nul
if not errorlevel 1 (
    py -3 camera_auto.py --all-devices
) else (
    where python >nul 2>nul
    if errorlevel 1 (
        echo ERROR: Python 3.10 or later is required.
        echo Download: https://www.python.org/downloads/
        pause
        exit /b 2
    )
    python camera_auto.py --all-devices
)
echo.
echo Results were written into the results folder.
pause
