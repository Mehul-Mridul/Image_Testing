import importlib.util
import json
from pathlib import Path
import tempfile
import unittest
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("camera_auto", ROOT / "camera_auto.py")
m = importlib.util.module_from_spec(spec)
import sys
sys.modules[spec.name] = m
spec.loader.exec_module(m)


class CameraAutoTests(unittest.TestCase):
    def test_config_has_six_apps_with_two_photos_one_video(self):
        cfg = json.loads((ROOT / "config.json").read_text())
        self.assertEqual(set(cfg["apps"]), {"native", "facebook", "instagram", "snow", "whatsapp", "soda"})
        self.assertEqual(cfg["defaults"]["photos_per_app"], 2)
        self.assertEqual(cfg["apps"]["whatsapp"]["save_behavior"], "explicit")
        for item in cfg["apps"].values():
            self.assertEqual(len(item["shutter"]), 2)
            self.assertIn(item["video_style"], {"toggle", "hold"})

    def test_xml_parser_and_descendant_ancestor_clicking(self):
        xml = ET.fromstring('<hierarchy><node text="" bounds="[0,0][1080,2400]" clickable="false"><node bounds="[0,2000][1080,2399]" clickable="true" text=""><node text="Take picture" content-desc="" bounds="[300,2150][800,2320]" clickable="false" enabled="true"/></node></node></hierarchy>')
        pairs = m.nodes_from_xml(xml)
        self.assertEqual(len(pairs), 3)
        self.assertEqual(pairs[-1][0].label, "Take picture")
        # A non-clickable label can target a clickable ancestor.
        class FakeAdb:
            def screen_size(self): return (1080, 2400)
        ui = m.Ui(FakeAdb(), Path(tempfile.gettempdir()))
        ui.items = pairs
        found = ui.find(["Take picture"])
        self.assertIsNotNone(found)
        self.assertEqual(found[0].bounds, (0,2000,1080,2399))

    def test_forbidden_controls_not_clickable(self):
        xml = ET.fromstring('<hierarchy><node text="Share to Story" bounds="[0,0][300,100]" clickable="true" enabled="true"/><node text="Save to device" bounds="[0,150][300,230]" clickable="true" enabled="true"/></hierarchy>')
        class FakeAdb:
            def screen_size(self): return (1080, 2400)
        ui = m.Ui(FakeAdb(), Path(tempfile.gettempdir()))
        ui.items = m.nodes_from_xml(xml)
        self.assertIsNone(ui.find(["Share to Story", "Send"]))
        self.assertEqual(ui.find(m.SAVE_LABELS)[0].label, "Save to device")

    def test_whatsapp_entry_requires_top_right(self):
        xml = ET.fromstring('<hierarchy><node text="Camera" bounds="[20,2000][130,2200]" clickable="true" enabled="true"/><node text="Camera" bounds="[910,20][1050,140]" clickable="true" enabled="true"/></hierarchy>')
        class FakeAdb:
            def screen_size(self): return (1080, 2400)
        ui = m.Ui(FakeAdb(), Path(tempfile.gettempdir()))
        ui.items = m.nodes_from_xml(xml)
        found = ui.find(m.CAMERA_LABELS, region="top_right")
        self.assertEqual(found[0].bounds, (910,20,1050,140))

    def test_media_signature(self):
        with tempfile.TemporaryDirectory() as folder:
            photo = Path(folder) / 'a.jpg'
            photo.write_bytes(b'\xff\xd8\xff' + b'\x00'*100)
            video = Path(folder) / 'a.mp4'
            video.write_bytes(b'\x00\x00\x00\x18ftypisom'+b'\x00'*80)
            self.assertEqual(m.actual_type(photo), "photo")
            self.assertEqual(m.actual_type(video), "video")

    def test_no_deceptive_pass_without_verified_files(self):
        self.assertTrue(m.DANGEROUS.search("Send"))
        self.assertTrue(m.DANGEROUS.search("Share to Story"))
        self.assertTrue(m.DANGEROUS.search("Add to Status"))
        self.assertIsNone(m.DANGEROUS.search("Save to device"))
        self.assertEqual(m.safe_match("Photo shutter", "Shutter"), 100)

if __name__ == '__main__':
    unittest.main()
