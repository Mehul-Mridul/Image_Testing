import importlib.util
import json
import tempfile
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
spec = importlib.util.spec_from_file_location("camera_auto", ROOT / "camera_auto.py")
m = importlib.util.module_from_spec(spec)
sys.modules[spec.name] = m
spec.loader.exec_module(m)


class MockSamsung:
    def __init__(self):
        self.mode = "photo"
        self.recording = False
        self.files = set()
        self.pcount = 0
        self.vcount = 0
    def package_installed(self, package): return True
    def scan(self, roots): return set(self.files)
    def launch(self, package): self.mode = "photo"
    def screen_size(self): return 1080, 2400
    def xml(self):
        # Self-contained simulated accessible Samsung camera UI.
        header = '<hierarchy><node text="Flash" bounds="[0,100][150,200]" enabled="true" clickable="true" />'
        modes = '<node text="Photo" bounds="[150,2200][320,2299]" enabled="true" clickable="true"/><node text="Video" bounds="[340,2200][520,2299]" enabled="true" clickable="true"/>'
        button = 'Take picture' if self.mode == 'photo' else 'Stop recording' if self.recording else 'Start recording'
        shutter = f'<node text="{button}" bounds="[450,1900][620,2150]" enabled="true" clickable="true" />'
        xml = header + modes + shutter + '</hierarchy>'
        import xml.etree.ElementTree as ET
        return ET.fromstring(xml), xml
    def tap(self, x, y):
        if 2200 <= y <= 2299:
            self.mode = "video" if x >= 340 else "photo"
            return
        if self.mode == "photo":
            self.pcount += 1
            self.files.add(f'/sdcard/DCIM/Camera/mock_{self.pcount}.jpg')
        elif not self.recording:
            self.recording = True
        else:
            self.recording = False
            self.vcount += 1
            self.files.add(f'/sdcard/DCIM/Camera/mock_{self.vcount}.mp4')
    def screenshot(self, dest):
        dest.parent.mkdir(parents=True, exist_ok=True)
        dest.write_bytes(b'png mock diagnostic')
    def pull(self, remote, dest):
        dest.parent.mkdir(parents=True, exist_ok=True)
        if remote.endswith('.jpg'):
            dest.write_bytes(b'\xff\xd8\xff' + b'\x11' * 2048)
        else:
            dest.write_bytes(b'\x00\x00\x00\x18ftypisom' + b'\x33' * 3000)
        return '1 file pulled'


class SimulatedDeviceTest(unittest.TestCase):
    def test_native_flow_uses_real_capture_actions_and_collects_three_files(self):
        cfg = json.loads((ROOT/'config.json').read_text())
        dev = MockSamsung()
        with tempfile.TemporaryDirectory() as td, patch.object(m.time, 'sleep', lambda seconds: None), patch.object(m, 'probe', lambda path: {"note": "mock"}):
            report = m.run_app(dev, 'native', cfg['apps']['native'], cfg['defaults'], Path(td), True)
            self.assertEqual(report['status'], 'PASS', report.get('message'))
            self.assertEqual(report['verified'], {'photos': 2, 'videos': 1})
            self.assertEqual(len(report['captures']), 3)
            self.assertEqual(dev.pcount, 2)
            self.assertEqual(dev.vcount, 1)

if __name__ == '__main__':
    unittest.main()
