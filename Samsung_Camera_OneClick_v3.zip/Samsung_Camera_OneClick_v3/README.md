# Samsung 6-App Camera QA — One-Click Runner (v3)

**Purpose:** Automatically use the real camera UI in **Samsung Camera, Facebook Stories, Instagram Stories, SNOW, WhatsApp, SODA** on a physical Samsung Galaxy S26+ or Samsung tablet. Each app's goal is **two real photos + one 10-second video**, with local save/export and retrieval to the PC. The video duration can be changed in `config.json`.

**You run:** `RUN_ALL_WINDOWS.bat` (double-click) after one-time prerequisites below.

**Reality check:** This is a *best-effort* black-box automation implementation, **not a confirmed turn-key success across the six apps**. No phone/app screenshots, UI hierarchies or physical device were supplied for calibration, and current UI differs by app release/account/phone/tablet. The runner dynamically discovers text, content descriptions, resource IDs and clickable bounds. For a verified live camera, it can use estimated shutter coordinates as a fallback. For Save/Download and Story navigation, it **refuses to guess** and writes evidence when the UI is not identifiable. Do not interpret a failed/skipped run as an app defect. Only `PASS` after three files have been verified is a successful media-export test.

## One-time prerequisites (Windows 10/11)

1. Install **Python 3.10 or newer**: https://www.python.org/downloads/
2. Install **Android Platform Tools**: https://developer.android.com/tools/releases/platform-tools
   - Put the `platform-tools` folder inside this project (so it contains `platform-tools/adb.exe`), **or** put `adb.exe` on Windows PATH.
   - **No Appium server, Node.js, Python pip packages or root required.**
3. On the phone/tablet: **Settings > About phone/tablet > Software information > tap Build number 7 times > Developer options > USB debugging ON.** Connect by USB and accept **Allow USB debugging**.
4. **Install and log into Facebook, Instagram and WhatsApp yourself.** Open each camera app once, approve camera/microphone/media permissions, dismiss introductory popups, and close overlays. Choose your preferred front/back camera, filters, orientation and video settings. Keep screen unlocked and device awake.
5. Test with dedicated social media accounts. **Do not test using personal contacts or post real stories.** The automation is designed never to send/share/post.
6. Keep devices physically steady and point at the desired target. Plug in USB while capturing. For accurate camera QA, set brightness, focus, exposure, zoom, lens, scene and lighting consistently before the test.

## Run all six apps

**Double-click `RUN_ALL_WINDOWS.bat`.** It processes each connected authorized Android device **sequentially**. Keep the PowerShell/Command Prompt window open.

You may also run from PowerShell in this folder:

```powershell
python camera_auto.py --all-devices
```

To test just WhatsApp before the full run, double-click `RUN_WHATSAPP_ONLY_WINDOWS.bat`, or:

```powershell
python camera_auto.py --app whatsapp
```

To use only a particular device among several connected:

```powershell
adb devices
python camera_auto.py --serial YOUR_SERIAL
```

If only one device is connected, `python camera_auto.py` is enough. If none are authorized, use `adb devices` and confirm the USB prompt on the phone.

To save a screenshot and screen accessibility XML for troubleshooting (without capturing):

```powershell
python camera_auto.py --inspect
```

To disable fallback camera-shutter coordinates:

```powershell
python camera_auto.py --no-shutter-fallback
```

## Per-application expected flow

| App | Camera entry | Photo 1 and 2 | Video | Save |
|---|---|---|---|---|
| Samsung Camera | Launch | Photo shutter twice | Video tab → record 10s → stop | Automatic gallery save |
| Facebook | Create Story → live camera | Story shutter, one at a time | Story camera long-press shutter | Story editor Save/Download to device after EACH capture, never Share |
| Instagram | Story → live camera | Story shutter, one at a time | Story long-press shutter | Story editor Save/Download to device after EACH capture, never Share |
| SNOW | Launch | Shutter twice | Video mode → record → stop | Automatic, else attempt explicit Save |
| WhatsApp | **Top-right Camera icon** | Shutter, then Save to device, twice | Hold shutter, then Save to device | Local device save only; do not send a message/status |
| SODA | Launch | Shutter twice | Video mode → record → stop | Automatic, else attempt explicit Save |

**Note:** Facebook and Instagram's UI may expose the Story camera through a different entry point. WhatsApp's Save button and gallery path must be observable through the user's app build. An accessibility-invisible icon will stop the run instead of guessing a Save coordinate. Samsung camera shutter fallback is an approximate normalized screen point and may need adjustment based on model/orientation.

## Where are photos/videos and reports?

In `results/<RUN_TIMESTAMP>/<DEVICE_SERIAL>/<APP_NAME>/`:

- `media/` — only **new media files** visible in shared storage, copied without resizing/transcoding.
- `report.json` — each app's actions, file paths, SHA-256 checksums and status.
- `diagnostics/` — screenshot + XML at start/finish or after any failure. **Diagnostic screenshots are NOT counted as photos.**
- `results/<RUN_TIMESTAMP>/summary.json` — overall run statuses.

Status `PASS` means 2 retrieved files with photo signatures and 1 with video signature. If `ffprobe` is installed separately, additional video metadata is included. Without it, duration/codec is not confirmed and should be independently checked before scientific/performance analysis.

Status `NEEDS_ATTENTION` means automation could not safely navigate or no new accessible file was found. `NEEDS_REVIEW` means files/quantities didn't match exactly. `ERROR` is an unexpected software error. A single application failing **does not stop subsequent apps**.

## Troubleshoot/iterate

If a specific app stops, open its `diagnostics/failure_*.png` and `.xml` and check:

- Is the user logged in, are camera permissions granted, is a privacy banner/dialog blocking the UI?
- Is the app using a custom graphic icon with no Android accessibility description? The runner cannot derive an arbitrary Save button's location safely.
- Is the camera shutter in a different location on tablet? Update `shutter` in `config.json` as `[x_fraction, y_fraction]` (0.0 to 1.0), **only after checking a real camera screenshot**.
- Did Instagram/Facebook export to private app storage? `adb` cannot access another app's protected private data without root. The app must use its own Save/Download to shared storage.
- Does SNOW or SODA use a *hold to record* camera shutter? Change `video_style` in `config.json` to `"hold"` if verified on the device.
- Does video recording require permission, mode selection, or a prompt? Finish onboarding once manually and retry.
- If a Save button is not in the accessibility hierarchy, a verified device-specific visual automation adapter must be added. Do **not** substitute `screencap`/`screenrecord` media for real camera photos/videos.

The code is a reusable foundation, not universal screen recognition. For robust unattended production operation, **calibrate app-specific UI selectors or image templates against your devices, add state assertions and run validation** before trusting overnight/unattended runs.

## Safety limitations

- Never intentionally taps **Send, Share, Post, Publish, Go live**, etc.; avoids clicking ambiguous save coordinates. Test first with non-sensitive content and throwaway accounts, because an unrecognized custom UI can still cause misnavigation.
- Does not modify app internals, root the device, upload to third parties or send messages.
- Reads only public/shared media folders from ADB and copies files created in this test session. The script uses screenshots for troubleshooting; those screens may contain private account information. Review before sharing diagnostic files.
- All image/video recordings come from each third-party application's actual capture UI, with save confirmed by new media file paths; merely taking ADB screenshots never counts as a media capture.

## Developer validation

```powershell
python -m unittest discover -s tests -v
python -m py_compile camera_auto.py
```

These unit tests check safety selection, parsing, package config and file recognition. They do **not** substitute for device and app integration tests. Real-device testing remains outstanding.
