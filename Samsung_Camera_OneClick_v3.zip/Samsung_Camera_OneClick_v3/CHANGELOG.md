# Changelog

## v3 — One-click runner (2026-11-18)
- Rebuilt as a Python standard-library + ADB tool (no Appium or Node.js runtime required).
- Includes a Windows double-click launcher and 6 preconfigured app flows.
- Works through Android accessibility UI labels, with guarded in-camera shutter tap fallback.
- WhatsApp: top-right camera icon → two Save-to-device photos → 10-second hold-to-record video → Save-to-device.
- Facebook/Instagram: enter Story camera, never post, and export each capture using Save/Download.
- Copies new real files from public media storage, hashes output, optionally probes video metadata, reports each failure and saves diagnostics.
- Includes unit tests and detailed setup/troubleshooting guide.
- **Not yet tested on real Samsung devices; no guarantee each app is fully automated without app-version calibration.**
