@echo off
setlocal
cd /d "%~dp0"
where adb >nul 2>nul
if errorlevel 1 if exist "%~dp0platform-tools\adb.exe" set "ADB_EXE=%~dp0platform-tools\adb.exe"
where py >nul 2>nul
if not errorlevel 1 (py -3 camera_auto.py --app whatsapp) else (python camera_auto.py --app whatsapp)
pause
