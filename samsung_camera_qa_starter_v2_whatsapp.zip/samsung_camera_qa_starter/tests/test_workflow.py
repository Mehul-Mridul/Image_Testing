"""Unit checks for the uncalibrated WhatsApp Save-to-device workflow.

No Android device or Appium installation required.
"""
import copy
import json
import sys
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import cameraqa  # noqa: E402

ROOT = Path(__file__).resolve().parents[1]


class WhatsAppWorkflowTest(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.cfg = json.loads((ROOT / 'config' / 'apps.json').read_text(encoding='utf-8'))
        cls.steps = cls.cfg['apps']['whatsapp']['steps']

    def test_guide_tracks_user_reported_camera_icon_and_save(self):
        app = self.cfg['apps']['whatsapp']
        self.assertEqual(app['storage'], 'camera_icon_save_to_device')
        self.assertTrue(app['requires_local_save'])
        self.assertFalse(app['calibrated'])
        self.assertIn('TOP_RIGHT_CAMERA_ICON', self.steps[0]['locator']['value'])
        self.assertEqual([s['op'] for s in self.steps if s['op'] in ('photo','video_record_hold','save')],
                         ['photo','save','photo','save','video_record_hold','save'])

    def test_config_workflow_validates_as_template(self):
        # Placeholders are intentionally rejected before live automation.
        with self.assertRaisesRegex(RuntimeError, 'Uncalibrated placeholder'):
            cameraqa.validate_steps(self.steps, require_local_save=True)
        calibrated_template = copy.deepcopy(self.steps)
        for s in calibrated_template:
            locator = s.get('locator')
            if locator and 'value' in locator:
                locator['value'] = locator['value'].replace('REPLACE_', 'calibrated_')
        cameraqa.validate_steps(calibrated_template, require_local_save=True)

    def test_missing_save_is_rejected(self):
        steps = self._calibrated_steps()
        steps = [s for s in steps if not (s['op'] == 'save' and 'second photo' in s.get('note',''))]
        with self.assertRaisesRegex(RuntimeError, '(before the preceding capture was saved|Expected 3)'):
            cameraqa.validate_steps(steps, require_local_save=True)

    def test_send_control_rejected(self):
        steps = self._calibrated_steps()
        steps[2]['locator']['value'] = 'Send to chat'
        with self.assertRaisesRegex(RuntimeError, 'Blocked possible publication'):
            cameraqa.validate_steps(steps, require_local_save=True)

    def test_video_hold_inherits_configured_duration(self):
        steps = [{'op': 'video_record_hold', 'locator': {'by':'normalized','x':0.5,'y':0.9}}]
        with patch.object(cameraqa, 'interact') as mocked, patch.object(cameraqa, 'screenshot'):
            log, err = cameraqa.execute_steps(object(), 'TEST_SERIAL', steps, 10, ROOT / '_unused')
        self.assertIsNone(err)
        self.assertTrue(log[0]['success'])
        self.assertEqual(mocked.call_args.args[2]['hold_ms'], 10000)

    def test_alternate_video_toggle_flow(self):
        alt = json.loads((ROOT/'examples'/'whatsapp.video_toggle.example.json').read_text())
        steps = copy.deepcopy(alt['steps'])
        for s in steps:
            loc = s.get('locator')
            if loc and 'value' in loc:
                loc['value'] = loc['value'].replace('REPLACE_', 'calibrated_')
        cameraqa.validate_steps(steps, require_local_save=True)
        self.assertEqual(sum(s['op']=='video_start' for s in steps), 1)
        self.assertEqual(sum(s['op']=='video_stop' for s in steps), 1)

    def _calibrated_steps(self):
        steps = copy.deepcopy(self.steps)
        for s in steps:
            locator = s.get('locator')
            if locator and 'value' in locator:
                locator['value'] = locator['value'].replace('REPLACE_', 'calibrated_')
        return steps


if __name__ == '__main__':
    unittest.main()
