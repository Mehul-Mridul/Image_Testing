# Samsung 6-App Camera QA Automation — Starter Project

**Scope:** A completely standalone project for Samsung phones/tablets. It does not interact with your existing robot-testing workflow.

**Target:** Two *real in-app camera photos* and one *real in-app camera video* per application for Samsung Camera, Facebook Stories, Instagram Stories, SNOW, WhatsApp and SODA. Twelve images + six videos per device when every app can export its unsent captures.

> **Status:** Tested for Python syntax and configuration structure only. No physical device or app UI was connected. The configuration deliberately contains no fabricated button identifiers. Until you calibrate the controls on your actual phone/tablet, the runner reports `NOT_CALIBRATED` and does not tap anything. This is a functional automation framework, **not** a claim that all six apps are already automated.

## 1. Workstation requirements

- Windows 10/11, Linux, or macOS computer, stable USB cable, fully charged Samsung Galaxy S26+ or supported Galaxy Tab.
- Python 3.10+; Node.js LTS; Android SDK Platform Tools (`adb`); Appium 2+ and a compatible UiAutomator2 driver; optional FFmpeg/`ffprobe` for video metadata.
- Install **Appium Inspector** for examining accessibility IDs, resource IDs, bounds, and hierarchy.
- All six apps installed, permissions pre-granted by you, personal login/test accounts prepared, and a suitable test subject/scene.

### Example Windows PowerShell setup

```powershell
# 1. Install Node LTS, Python, Android Platform-Tools, and Appium Inspector manually.
# 2. Verify they are on PATH:
node --version
python --version
adb version

# 3. Open PowerShell inside this project folder:
python -m venv .venv
.\.venv\Scripts\Activate.ps1
python -m pip install -r requirements.txt
npm install -g appium
appium driver install uiautomator2
appium driver doctor uiautomator2
```

If PowerShell blocks `.ps1` activation due to local policy, use `.venv\Scripts\python.exe` directly instead of changing company security settings.

### Device preparation

1. In **Settings > About phone/tablet > Software information**, tap **Build number** seven times to enable Developer options (exact menus may vary).
2. Enable USB debugging. Attach USB and approve the device's USB-debugging trust prompt.
3. Keep the phone unlocked, screen on, in the chosen orientation, and mounted/held steady. Use a good USB cable and select a camera target with stable lighting.
4. Verify:

```powershell
adb devices -l
python cameraqa.py devices
adb -s YOUR_SERIAL shell getprop ro.product.model
adb -s YOUR_SERIAL shell wm size
```

Only `device` (not `unauthorized`) should be shown for your serial. **Do not disable OS security or root the device.**

In a **separate PowerShell terminal**, start the Appium server:

```powershell
appium
```

Default URL used by this project: `http://127.0.0.1:4723`.

## 2. Package IDs (verify against your installed APK)

| App | Common package |
|---|---|
| Samsung Camera | `com.sec.android.app.camera` |
| Facebook | `com.facebook.katana` |
| Instagram | `com.instagram.android` |
| SNOW | `com.campmobile.snow` |
| WhatsApp | `com.whatsapp` |
| SODA | `com.snowcorp.soda.android` |

Run:

```powershell
adb -s YOUR_SERIAL shell pm list packages camera
adb -s YOUR_SERIAL shell pm list packages facebook
adb -s YOUR_SERIAL shell pm list packages instagram
adb -s YOUR_SERIAL shell pm list packages campmobile
adb -s YOUR_SERIAL shell pm list packages whatsapp
adb -s YOUR_SERIAL shell pm list packages soda
```

A Samsung tablet could have a different Camera UI, and some tablets may not offer the exact phone camera modes. Versions, accounts, locales, and A/B-tested UI rollouts can change selectors.

## 3. Capture flows to calibrate

Calibrate **each app on each type of device**, without assuming the phone's coordinates work on a tablet.

### Native Samsung Camera

- Launch Camera; select Photo mode, correct lens/front/back camera, zoom, aspect ratio, optional resolution settings.
- Press real shutter once; allow save to finish; press real shutter again.
- Select Video mode; tap Record; wait configured duration; tap Stop.
- Media is usually automatically stored in `DCIM/Camera` (verify location on the actual device).

### Facebook Stories

- Launch Facebook; enter Create Story; select the *live in-app camera*, not an already saved gallery photo.
- Press shutter for photo 1. From the editor choose **Save/Download to device** and wait for confirmation. Return to live Story camera.
- Repeat for photo 2. Switch to live Story video mode, record, stop, select Save/Download.
- **Never press Share to Story.** Download/save controls are version dependent; inspect the installed app. The app may store exported content in `DCIM`, `Pictures`, or another gallery folder.

### Instagram Stories

- Launch Instagram; enter Story camera (NOT camera roll/gallery); take photo 1; in the editor use the local Download/Save action.
- Navigate back to camera; repeat for photo 2. Record Story video (some versions require press-and-hold of the shutter); save video from the editor.
- **Do not publish a Story.** Media after export may have story-specific processing/compression; preserve the resulting exported bytes.

### SNOW

- Launch camera; set filter/beauty/AR effect to a defined baseline (either OFF or a recorded effect name), correct lens, orientation.
- Take 2 photos; confirm autosave or use explicit Save for each.
- Select video and record; confirm the video was saved to shared gallery and is discoverable. Do not assume that photo and video share identical save paths.

### WhatsApp — confirmed user workflow: top-right Camera → Save to device

The operator has identified a **camera icon at the top right of WhatsApp** and an in-app **Save to device** control. This flow **does not use a chat recipient or WhatsApp Status**, and never sends or publishes any media.

1. Open WhatsApp at its main screen. Tap the **top-right camera icon** (verify its accessibility label or screen coordinates in your app build).
2. Tap the WhatsApp camera shutter once to create **photo 1**. On the photo preview, tap **Save to device**. Wait for the save, and return to the WhatsApp live camera.
3. Capture **photo 2**, tap **Save to device**, and return to the live camera again.
4. Capture **one video**. The template uses `video_record_hold`: hold the camera shutter for the configured 10 seconds, then release to stop. If your WhatsApp version instead has separate video mode / Start / Stop buttons, replace this step with `tap` to enter video mode, `video_start`, `wait_video`, and `video_stop`.
5. From the video preview, tap **Save to device**. Verify that the result is in accessible on-device media storage.
6. The collector pulls the **actual saved photo/video files**, not screenshots. Never tap Send, Post, or Status.

A WhatsApp workflow template is already present at `config/apps.json → apps.whatsapp.steps` and in `examples/whatsapp.example.json`. All selectors are deliberately named `REPLACE_...`; set the correct ones with Appium Inspector and then change `calibrated` to `true`. The navigation `back` steps must also be verified on your installed app; they may need an app-specific button or another route to the live camera. **The described Save to device control comes from your observed UI; its visibility, device save folder, and automation selectors have not yet been independently verified.**

### SODA

- Launch camera; set beauty/filter baseline, correct lens and mode. Capture 2 photographs and verify they exist in a gallery location.
- Switch to video, record, stop and confirm video saving (some app versions have a separate Save/export button).

## 4. Calibrate controls — the most important stage

A generic automation script cannot know the Story editor's exact Save button in your installed Instagram/Facebook version without inspecting it. Never trust random coordinates from the internet.

**Preferred approach:** Use [Appium Inspector](https://appium.github.io/appium-inspector/latest/) with capabilities:

```json
{
  "platformName": "Android",
  "appium:automationName": "UiAutomator2",
  "appium:udid": "YOUR_SERIAL",
  "appium:noReset": true
}
```

At Appium URL `http://127.0.0.1:4723`, inspect the UI while manually navigating into the Story camera, editor, or video mode. Record `resource-id`, `content-desc` (accessibility ID), or XPath. Accessibility IDs or resource IDs are preferable to coordinates.

**Fallback for custom camera graphics:** use normalized screen position (0..1):

```json
{"op":"photo", "locator":{"by":"normalized", "x":0.50,"y":0.87}, "after_seconds":2}
```

These coordinates are illustrative ONLY. Adjust using a screenshot taken from the *actual* device and current orientation.

To get a screenshot and (if available) XML hierarchy while an app is open:

```powershell
python cameraqa.py inspect --app instagram --serial YOUR_SERIAL
```

Saved under `calibration/YOUR_SERIAL/instagram/DATE_TIME/`. A camera shutter often does **not** appear in the accessibility hierarchy; use coordinates in that case. `Appium Inspector` is often better than raw XML for this task.

### Available step operations in `apps.json`

| op | Meaning | Fields |
|---|---|---|
| `tap` | Tap UI button | `locator` |
| `photo` | Real in-app shutter action | `locator`, optional `after_seconds` |
| `save` | Tap the app’s **Save to device** button for the preceding capture | `locator`, optional `after_seconds` |
| `video_start` | Tap to start recording (or a manually configured hold) | `locator` |
| `video_record_hold` | Press and hold shutter for `video_duration_seconds`, then release (ends recording) | `locator` |
| `wait_video` | Wait configured video duration | no locator |
| `video_stop` | Stop recording | `locator` |
| `hold` | Long press UI element | `locator`, `hold_ms` |
| `back` | Android back action | none |
| `wait` | Pause for rendering/saving | `seconds` |
| `screenshot` | Diagnostic screen screenshot only | no locator |

Locators can be:

```json
{"by":"accessibility_id","value":"REAL_ACCESSIBILITY_DESCRIPTION"}
{"by":"id","value":"com.example.app:id/real_button"}
{"by":"xpath","value":"//android.widget.ImageButton[@content-desc='Real label']"}
{"by":"normalized","x":0.50,"y":0.87}
```

The runner uses ADB input for coordinate taps/holds, Appium for selectors, and ADB for media transfer. You can edit `config/apps.json` and add the actual step list in chronological order. Once every step has been calibrated for that specific app+device version, set `"calibrated": true`.

**Examples** are under `examples/`. Every `REPLACE_...` selector is intentionally a placeholder and must be changed. A Story recorder may use a press-and-hold (`video_record_hold`, with configured duration), whereas the native app may use `video_start`, `wait_video`, then `video_stop`.

**Important:** The `validate_steps` guard blocks step selectors containing obvious post/publish/send verbs and requires exactly 2 `photo` actions + 1 video action (`video_start` or `video_record_hold`). For WhatsApp, Instagram Stories, and Facebook Stories, the guard also requires **exactly three Save-to-device actions, one after each capture**. This is a configuration sanity check, not proof that a selected UI control is actually the Save button. It cannot guarantee that a mistakenly calibrated coordinate will not tap a publish button. Visually verify the flow first with a test account and do not enable the full six-app sequence until verified.

## 4A. WhatsApp configuration quickstart (new)

The default `config/apps.json` contains **nine explicit WhatsApp actions**:

```
Tap top-right Camera icon
Photo 1 → Save to device → Back to live camera
Photo 2 → Save to device → Back to live camera
Hold shutter for video duration → Save to device
```

Use `python cameraqa.py inspect --app whatsapp --serial YOUR_SERIAL` at the WhatsApp main screen **and again on the image/video preview** to identify real control labels. You can also use Appium Inspector. Replace every `REPLACE_...` selector in `config/apps.json`; verify the two `back` actions restore the live camera, and set `"calibrated": true` for WhatsApp only after testing the workflow manually.

Example of a real **selector shape** (the value below is a placeholder, not a discovered WhatsApp ID):

```json
{"op":"save", "locator":{"by":"accessibility_id", "value":"REPLACE_WITH_ACTUAL_SAVE_TO_DEVICE_LABEL"}}
```

If the camera button has no accessibility label, a normalized location from **your own device screenshot** can be used, but cross-check it visually before running to avoid accidentally sending or posting. The command to run the calibrated WhatsApp flow is:

```powershell
python cameraqa.py run --app whatsapp --serial YOUR_SERIAL
```

When successful, `results/YOUR_SERIAL/<timestamp>/whatsapp/report.json` records the saved images and video found on the device. A result is `PASS` only if two new accessible photo files and one new accessible video file can be transferred; the code does not consider an Appium tap alone proof of capture.

## 5. Run tests

After calibration, first perform a short test on Samsung Camera only:

```powershell
python cameraqa.py run --app native --serial YOUR_SERIAL
```

Then Instagram and Facebook one at a time:

```powershell
python cameraqa.py run --app instagram --serial YOUR_SERIAL
python cameraqa.py run --app facebook --serial YOUR_SERIAL
```

When all app flows have been calibrated/checked:

```powershell
python cameraqa.py run --all --serial YOUR_SERIAL
```

**Do not rely on `--all` until the WhatsApp top-right camera, the three Save-to-device buttons, and the other five apps have been calibrated and tested.** Apps still marked `calibrated: false` are skipped with `NOT_CALIBRATED`, including WhatsApp until its real selectors are supplied.

### Output

```text
results/
  DEVICE_SERIAL/
    20261118_153000/
      native/
        before.png                  # diagnostic UI only, not a camera image
        after.png
        media/
          DCIM/Camera/IMG_....jpg   # actual file pulled from shared storage
          DCIM/Camera/VID_....mp4
        report.json
      facebook/
        media/...
        report.json
      ...
      summary.json
```

The runner snapshots shared media file paths *before launching each app* and pulls **new** files visible under `DCIM`, `Pictures`, `Movies`, and `Download` afterward. It writes SHA-256 hashes and file sizes, and `ffprobe` metadata for video if FFmpeg is installed. This approach **does not** access private app storage or guarantee coverage of all app-specific file paths.

### Acceptance criteria

For each app on each device:

1. **UI success:** Correct camera opened, no gallery-input substitution, two real shutter events, one real video recording.
2. **Export success:** New exported media files appear in accessible device storage. The runner verifies *exactly* 2 photo files and *exactly* 1 video file in the scan scope.
3. **File integrity:** Nonempty files, correct extensions/decodable media, plausible resolution, video duration close to configured duration, distinct SHA-256 files when expected.
4. **No external publishing:** No Story or WhatsApp Status posted and no messages sent.
5. **Repeatability:** Run 3 times on S26+, then repeat after calibrating the Galaxy Tab profile. Record app/OS version, orientation, lens, filter, video duration and environment.

The current runner automatically checks file counts, nonempty size and optional video metadata, but does **not yet automatically assert** every criterion above. Add assertions for resolution, content, autofocus/blur, exact-duration tolerances and app-specific save confirmation after calibration. If an app exports media only to its private cache, the collector will fail even though the capture UI appears to work; this is an honest `FAIL`/`BLOCKED`, not a false pass.

## 6. Known limitations and production extensions

- **No app UI selectors preloaded.** Instagram/Facebook/WhatsApp/SNOW/SODA controls change, and I cannot inspect your S26+ remotely. Calibrate first.
- **No private-data bypass.** Android scoped storage blocks easy access to an app's private unsent media. Use the application's normal Save/Export flow when available.
- **Temporary UI freezes, dialogs and login state:** add per-app checks, conditional handlers and retry loops without duplicate media creation. Do not blindly retry the capture step after a timeout.
- **Camera ownership and quality:** screenshot files are for debugging only. App in-camera video may have different compression/settings from the native camera.
- **Device stability:** disable battery-saving interruptions only as permitted by test policy; avoid screen rotation, notification popups and unstable USB.
- **Multi-device support:** run one device at a time first. Parallel sessions later require separate Appium ports/UiAutomator2 systemPorts and separate output directories.
- **Enhanced verification:** use `ffprobe`/`exiftool` for codecs, exposure, camera metadata, duration; use MediaStore queries and app-specific export adapters to detect assets beyond the four public directories.

## 7. Suggested implementation order

1. Native Samsung Camera (two photos + one video + verified pulls)
2. Instagram Stories (capture, download, no publishing)
3. Facebook Stories (capture, download, no publishing)
4. SODA (confirm autosave and video export)
5. SNOW (confirm autosave and video export)
6. WhatsApp (top-right camera icon, two photos and one video, each followed by Save to device)
7. Recalibrate selectors for Samsung tablet
8. Add a small GUI / report dashboard after the foundation is stable

## Helpful documentation

- Android ADB: https://developer.android.com/tools/adb
- Appium UiAutomator2: https://appium.github.io/appium-uiautomator2-driver/latest/getting-started/
- Appium Inspector: https://appium.github.io/appium-inspector/latest/
- Android MediaStore: https://developer.android.com/training/data-storage/shared/media
