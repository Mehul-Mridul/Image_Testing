# Changes — WhatsApp camera Save-to-device workflow (v2)

- WhatsApp now uses the user-described **top-right camera icon**, not chat/status or a private-storage workaround.
- Added an explicit capture-by-capture flow: Photo 1 → Save, Photo 2 → Save, Video → Save.
- Added the `save` operation and a validation guard requiring three appropriately ordered Save-to-device steps for WhatsApp and Story apps.
- Added `video_record_hold` for camera UIs where holding the shutter records video; it uses the global configured duration and releases to stop.
- Added a WhatsApp alternate template for apps with separate video Start/Stop controls.
- Updated Story example to use `save` for local downloads.
- No UI labels or coordinates are fabricated. WhatsApp remains `calibrated: false` until you inspect the actual UI on your Samsung devices.
- No media is sent or published by the designed workflow. Note: unintended navigation/taps remain possible until tested against the real UI.
