"""Starter for reproducible, UI-driven Android third-party camera capture testing.

This intentionally contains NO fabricated UI selectors. Calibrate apps.json on actual
Samsung devices before attempting to run capture tests.
"""
from __future__ import annotations

import argparse
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys
import time
from typing import Any

ROOT = Path(__file__).resolve().parent
CONFIG = ROOT / "config" / "apps.json"
IMAGE_EXTS = {".jpg", ".jpeg", ".heic", ".heif", ".png", ".webp", ".dng"}
VIDEO_EXTS = {".mp4", ".mov", ".3gp", ".mkv", ".webm"}
SHARING_PATTERN = re.compile(r"\b(send|publish|post|share(?: to)?(?: story| status)?)\b", re.I)


def adb(serial: str | None, *args: str, check: bool = True, binary: bool = False):
    cmd = ["adb"] + (["-s", serial] if serial else []) + list(args)
    proc = subprocess.run(cmd, capture_output=True, check=False)
    if check and proc.returncode:
        raise RuntimeError(f"ADB command failed: {' '.join(cmd)}\n{proc.stderr.decode(errors='replace')}")
    if binary:
        return proc.stdout
    return proc.stdout.decode(errors="replace").strip()


def check_tools():
    if not shutil.which("adb"):
        raise RuntimeError("ADB not found on PATH. Install Android SDK Platform-Tools first.")


def configured_serial(cli_serial: str | None):
    rows = adb(None, "devices").splitlines()[1:]
    devices = [line.split()[0] for line in rows if "\tdevice" in line]
    if cli_serial:
        if cli_serial not in devices:
            raise RuntimeError(f"Device {cli_serial} is not authorized/connected. Available: {devices}")
        return cli_serial
    if len(devices) != 1:
        raise RuntimeError("Connect exactly one authorized Android device or provide --serial. Found: " + repr(devices))
    return devices[0]


def load_config():
    return json.loads(CONFIG.read_text(encoding="utf-8"))


def installed(serial: str, package: str):
    return f"package:{package}" in adb(serial, "shell", "pm", "list", "packages", package).splitlines()


def inspect(serial: str, app: str):
    location = ROOT / "calibration" / serial / app / datetime.now().strftime("%Y%m%d_%H%M%S")
    location.mkdir(parents=True, exist_ok=True)
    (location / "screen.png").write_bytes(adb(serial, "exec-out", "screencap", "-p", binary=True))
    dump = adb(serial, "shell", "uiautomator", "dump", "/sdcard/cameraqa_window.xml", check=False)
    if "dumped" in dump.lower() or "dump" in dump.lower():
        xml = adb(serial, "exec-out", "cat", "/sdcard/cameraqa_window.xml", check=False)
        (location / "hierarchy.xml").write_text(xml, encoding="utf-8")
    print(f"Saved screenshot / UI hierarchy (when available) to: {location}")
    print("Tip: Use Appium Inspector for resource IDs and content-desc. Custom camera controls may only support coordinates.")


def scan_media(serial: str, roots: list[str]):
    # ADB's `find` may return partial output when one root is missing or blocked.
    output = adb(serial, "shell", "find", *roots, "-type", "f", check=False)
    paths = set()
    for raw in output.splitlines():
        p = raw.strip().replace("\r", "")
        if p.startswith("/sdcard/") and Path(p).suffix.lower() in IMAGE_EXTS | VIDEO_EXTS:
            paths.add(p)
    return paths


def screenshot(serial: str, path: Path):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_bytes(adb(serial, "exec-out", "screencap", "-p", binary=True))


def hashfile(path: Path):
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for part in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(part)
    return digest.hexdigest()


def probe_video(path: Path):
    if not shutil.which("ffprobe"):
        return {"warning": "ffprobe not installed; duration and codec were not checked"}
    proc = subprocess.run(
        ["ffprobe", "-v", "error", "-show_entries", "format=duration:stream=codec_name,codec_type,width,height", "-of", "json", str(path)],
        capture_output=True, text=True,
    )
    if proc.returncode:
        return {"error": (proc.stderr or "ffprobe failed")[:300]}
    return json.loads(proc.stdout)


def collect_media(serial: str, before: set[str], roots: list[str], destination: Path, settle_seconds: float):
    deadline = time.monotonic() + max(10, settle_seconds + 7)
    fresh = set()
    while time.monotonic() < deadline:
        latest = scan_media(serial, roots) - before
        if latest == fresh and fresh:
            break
        fresh = latest
        time.sleep(2)
    destination.mkdir(parents=True, exist_ok=True)
    records = []
    for remote in sorted(fresh):
        relative = remote.removeprefix("/sdcard/")
        local = destination / relative
        local.parent.mkdir(parents=True, exist_ok=True)
        proc = subprocess.run(["adb", "-s", serial, "pull", remote, str(local)], capture_output=True, text=True)
        kind = "photo" if local.suffix.lower() in IMAGE_EXTS else "video"
        rec: dict[str, Any] = {"source": remote, "type": kind, "local": str(local.relative_to(destination)), "pulled": proc.returncode == 0}
        if proc.returncode == 0 and local.exists():
            rec.update({"bytes": local.stat().st_size, "sha256": hashfile(local)})
            if kind == "video":
                rec["probe"] = probe_video(local)
        else:
            rec["error"] = proc.stderr[:400]
        records.append(rec)
    return records


def validate_steps(steps, require_local_save: bool = False):
    if not steps:
        raise RuntimeError("No calibrated steps defined for this application")
    supported = {"tap", "hold", "back", "wait", "wait_video", "photo", "video_start", "video_stop", "video_record_hold", "save", "screenshot"}
    photos = sum(s["op"] == "photo" for s in steps)
    videos = sum(s["op"] in {"video_start", "video_record_hold"} for s in steps)
    if (photos, videos) != (2, 1):
        raise RuntimeError(f"Expected 2 photo actions and 1 video action, found {photos} photos and {videos} videos")
    pending_save = False
    saves = 0
    for s in steps:
        if s["op"] not in supported:
            raise RuntimeError(f"Unsupported step: {s['op']}")
        locator = s.get("locator", {})
        value = str(locator.get("value", ""))
        if SHARING_PATTERN.search(value):
            raise RuntimeError(f"Blocked possible publication/send action: {value}")
        if "REPLACE" in value or "YOUR_" in value:
            raise RuntimeError(f"Uncalibrated placeholder selector in step: {s}")
        if s["op"] in {"tap", "hold", "photo", "video_start", "video_stop", "video_record_hold", "save"} and not locator:
            raise RuntimeError(f"Missing locator for step {s['op']}")
        # For apps with an explicit Save-to-device button (e.g. WhatsApp), ensure
        # every capture is followed by a local save before another capture starts.
        if require_local_save and s["op"] in {"photo", "video_start", "video_record_hold"}:
            if pending_save:
                raise RuntimeError("A new capture begins before the preceding capture was saved locally")
            pending_save = True
        elif require_local_save and s["op"] == "save":
            if not pending_save:
                raise RuntimeError("A Save-to-device step has no preceding unsaved capture")
            pending_save = False
            saves += 1
    if require_local_save and (pending_save or saves != 3):
        raise RuntimeError(f"Expected 3 ordered Save-to-device steps, found {saves}")


def interact(driver, serial: str, step: dict):
    locator = step["locator"]
    mode = locator["by"]
    if mode == "normalized":
        x = float(locator["x"])
        y = float(locator["y"])
        if not (0 <= x <= 1 and 0 <= y <= 1):
            raise ValueError("Normalized coordinates must be between 0 and 1")
        size = driver.get_window_size()
        X = round(x * size["width"])
        Y = round(y * size["height"])
        if step["op"] == "hold" or step.get("hold_ms"):
            ms = int(step.get("hold_ms", 1000))
            adb(serial, "shell", "input", "swipe", str(X), str(Y), str(X), str(Y), str(ms))
        else:
            adb(serial, "shell", "input", "tap", str(X), str(Y))
        return
    from appium.webdriver.common.appiumby import AppiumBy
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.support.ui import WebDriverWait
    by = {
        "accessibility_id": AppiumBy.ACCESSIBILITY_ID,
        "id": AppiumBy.ID,
        "xpath": AppiumBy.XPATH,
        "android_uiautomator": AppiumBy.ANDROID_UIAUTOMATOR,
    }.get(mode)
    if by is None:
        raise ValueError(f"Locator mode {mode} is not supported")
    element = WebDriverWait(driver, 15).until(EC.element_to_be_clickable((by, locator["value"])))
    if step["op"] == "hold" or step.get("hold_ms"):
        # Use coordinates here to avoid relying on deprecated TouchAction APIs.
        rect = element.rect
        X = round(rect["x"] + rect["width"] / 2)
        Y = round(rect["y"] + rect["height"] / 2)
        ms = int(step.get("hold_ms", 1000))
        adb(serial, "shell", "input", "swipe", str(X), str(Y), str(X), str(Y), str(ms))
    else:
        element.click()


def execute_steps(driver, serial: str, steps: list[dict], video_seconds: float, evidence: Path):
    log = []
    for i, step in enumerate(steps, start=1):
        op = step["op"]
        started = datetime.now(timezone.utc).isoformat()
        print(f"  [{i}/{len(steps)}] {op}: {step.get('note','')}")
        try:
            if op == "video_record_hold":
                # Apps such as WhatsApp can record only while the shutter is held.
                # Holding for the configured duration ALSO stops the video on release.
                interact(driver, serial, {**step, "hold_ms": max(1000, round(video_seconds * 1000))})
            elif op in {"tap", "hold", "photo", "video_start", "video_stop", "save"}:
                interact(driver, serial, step)
            elif op == "back":
                driver.back()
            elif op == "wait":
                time.sleep(float(step.get("seconds", 1.5)))
            elif op == "wait_video":
                time.sleep(video_seconds)
            elif op == "screenshot":
                screenshot(serial, evidence / f"step_{i:02d}.png")
            if "after_seconds" in step:
                time.sleep(float(step["after_seconds"]))
            log.append({"step": i, "op": op, "time": started, "success": True})
        except Exception as exc:
            screenshot(serial, evidence / f"FAILED_step_{i:02d}.png")
            log.append({"step": i, "op": op, "time": started, "success": False, "error": str(exc)})
            return log, str(exc)
    return log, None


def run_one(serial: str, key: str, app: dict, defaults: dict, session_dir: Path):
    out = session_dir / key
    out.mkdir(parents=True, exist_ok=True)
    report = {"app": key, "name": app["name"], "package": app["package"], "started": datetime.now(timezone.utc).isoformat(), "status": "NOT_CALIBRATED"}
    if not app.get("calibrated"):
        report["message"] = "First inspect the app UI, fill in steps, and set calibrated=true. No guessed taps were executed."
    elif not installed(serial, app["package"]):
        report.update(status="BLOCKED", message="Package not installed on target device")
    else:
        try:
            validate_steps(app["steps"], require_local_save=app.get("requires_local_save", False))
            from appium import webdriver
            from appium.options.android import UiAutomator2Options
            options = UiAutomator2Options().load_capabilities({
                "platformName": "Android",
                "appium:automationName": "UiAutomator2",
                "appium:udid": serial,
                "appium:noReset": True,
                "appium:newCommandTimeout": 240,
            })
            before = scan_media(serial, defaults["media_roots"])
            driver = webdriver.Remote("http://127.0.0.1:4723", options=options)
            try:
                driver.activate_app(app["package"])
                time.sleep(3)
                screenshot(serial, out / "before.png")
                log, err = execute_steps(driver, serial, app["steps"], defaults["video_duration_seconds"], out / "diagnostics")
                screenshot(serial, out / "after.png")
                report["steps"] = log
            finally:
                driver.quit()
            records = collect_media(serial, before, defaults["media_roots"], out / "media", defaults.get("settle_seconds", 2))
            report["media"] = records
            nphotos = sum(r["type"] == "photo" and r["pulled"] and r.get("bytes", 0) > 1024 for r in records)
            nvideos = sum(r["type"] == "video" and r["pulled"] and r.get("bytes", 0) > 1024 for r in records)
            report["new_photos"] = nphotos
            report["new_videos"] = nvideos
            report["expected_photos"] = 2
            report["expected_videos"] = 1
            report["status"] = "PASS" if err is None and nphotos == 2 and nvideos == 1 else "FAIL"
            if err:
                report["error"] = err
            if nphotos != 2 or nvideos != 1:
                report["message"] = "Could not verify precisely 2 new photos + 1 new video in accessible shared media; inspect the app's export method or app-specific storage."
        except Exception as exc:
            report.update(status="BLOCKED", error=str(exc))
            try:
                screenshot(serial, out / "blocked.png")
            except Exception:
                pass
    report["finished"] = datetime.now(timezone.utc).isoformat()
    (out / "report.json").write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    print(f"{app['name']}: {report['status']} | {report.get('message', report.get('error', ''))}")
    return report


def main():
    parser = argparse.ArgumentParser(description="From-scratch Samsung multi-app camera QA starter")
    sub = parser.add_subparsers(dest="command", required=True)
    sub.add_parser("devices")
    check = sub.add_parser("inspect")
    check.add_argument("--app", required=True)
    check.add_argument("--serial")
    run = sub.add_parser("run")
    run.add_argument("--app", choices=["native", "facebook", "instagram", "snow", "whatsapp", "soda"])
    run.add_argument("--all", action="store_true")
    run.add_argument("--serial")
    args = parser.parse_args()
    check_tools()
    if args.command == "devices":
        print(adb(None, "devices", "-l"))
        return
    serial = configured_serial(args.serial)
    config = load_config()
    if args.command == "inspect":
        if args.app not in config["apps"]:
            parser.error(f"Unknown app: {args.app}")
        inspect(serial, args.app)
        return
    if args.command == "run":
        if not args.all and not args.app:
            parser.error("Set either --app APP or --all")
        if args.all and args.app:
            parser.error("Choose --app or --all, not both")
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        session = ROOT / "results" / serial / timestamp
        session.mkdir(parents=True, exist_ok=True)
        apps = config["apps"] if args.all else {args.app: config["apps"][args.app]}
        reports = [run_one(serial, k, v, config["defaults"], session) for k, v in apps.items()]
        (session / "summary.json").write_text(json.dumps({"device": serial, "reports": reports}, indent=2), encoding="utf-8")
        print("\nSummary:", ", ".join(f"{r['app']}={r['status']}" for r in reports))
        print("Output:", session)
        if any(r["status"] != "PASS" for r in reports):
            sys.exit(1)


if __name__ == "__main__":
    main()
