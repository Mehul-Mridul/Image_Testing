"""vNext UI orchestration. Rendering and decoder policy remain in the v5 modules.

The Qt file browser/shortcuts are actual implementations, but native HWND events
and physical-pixel equality require the Windows qualification matrix.
"""
from __future__ import annotations
import json
import re
import sys
from pathlib import Path
from time import monotonic
from dataclasses import replace
from PySide6.QtCore import Qt, QEvent, Signal, QObject, QRunnable, QTimer
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QDockWidget, QFileDialog, QMessageBox,
    QToolButton, QComboBox, QInputDialog, QLineEdit, QTextEdit, QPlainTextEdit,
    QAbstractSpinBox, QDialog, QVBoxLayout, QHBoxLayout, QLabel, QPushButton,
    QTableWidget, QTableWidgetItem, QKeySequenceEdit, QHeaderView,
)
from PySide6.QtGui import QAction, QKeySequence
from .gui import MainWindow as BaseWindow, ProbeTask
from .file_browser import FileBrowser
from .app_settings import AppSettings
from .media_catalog import scan_folder,sort_entries,is_video
from .comparison_sets import sequential_sets,pattern_sets,PatternRule,SetNavigator
from .commands import QtCommandRegistry
from .diagnostic_events import EventLog
from .pane_load import PaneLoadCoordinator
from .view_geometry import ViewState,Geometry,parse_sar
from .view_sync import ViewCoordinator
from .sync_alignment import align_here,target_pts,drift_ms,select_timestamp


class CatalogSignals(QObject):
    ready=Signal(int,object)
    failed=Signal(int,str)

class CatalogJob(QRunnable):
    def __init__(self,folder,recursive,token,signals):
        super().__init__()
        self.folder=folder;self.recursive=recursive;self.token=token;self.signals=signals
    def run(self):
        try:self.signals.ready.emit(self.token,scan_folder(self.folder,recursive=self.recursive))
        except Exception as exc:self.signals.failed.emit(self.token,str(exc))


class ShortcutEditor(QDialog):
    def __init__(self,registry,parent=None):
        super().__init__(parent)
        self.setWindowTitle('Keyboard shortcuts')
        self.resize(580,400)
        self.registry=registry
        l=QVBoxLayout(self)
        self.table=QTableWidget(0,3)
        self.table.setHorizontalHeaderLabels(['Action','Shortcut','Category'])
        self.table.horizontalHeader().setSectionResizeMode(0,QHeaderView.ResizeMode.Stretch)
        self.table.setSelectionBehavior(QTableWidget.SelectionBehavior.SelectRows)
        self.table.setEditTriggers(QTableWidget.EditTrigger.NoEditTriggers)
        l.addWidget(self.table)
        row=QHBoxLayout();row.addWidget(QLabel('New shortcut:'))
        self.key_editor=QKeySequenceEdit();row.addWidget(self.key_editor,1)
        set_button=QPushButton('Assign');set_button.clicked.connect(self.assign)
        reset=QPushButton('Reset All');reset.clicked.connect(self.reset)
        row.addWidget(set_button);row.addWidget(reset);l.addLayout(row)
        l.addWidget(QLabel('Duplicate shortcuts are rejected. Changes take effect immediately.'))
        self.populate()

    def populate(self):
        self.table.setRowCount(0)
        for command in self.registry.map.definitions.values():
            i=self.table.rowCount();self.table.insertRow(i)
            self.table.setItem(i,0,QTableWidgetItem(command.label))
            item=QTableWidgetItem(self.registry.map.sequence(command.command_id))
            item.setData(Qt.ItemDataRole.UserRole,command.command_id)
            self.table.setItem(i,1,item)
            self.table.setItem(i,2,QTableWidgetItem(command.category))
        self.table.resizeColumnsToContents()

    def assign(self):
        i=self.table.currentRow()
        if i<0:return
        command_id=self.table.item(i,1).data(Qt.ItemDataRole.UserRole)
        sequence=self.key_editor.keySequence().toString(QKeySequence.SequenceFormat.PortableText)
        try:self.registry.change(command_id,sequence)
        except ValueError as exc:
            QMessageBox.warning(self,'Shortcut conflict',str(exc));return
        self.populate();self.table.selectRow(i)

    def reset(self):
        self.registry.reset_all();self.populate()


class MainWindow(BaseWindow):
    def __init__(self):
        # BaseWindow invokes subclass hooks during initialization.
        self.settings=AppSettings()
        self.log=EventLog()
        self.navigator=SetNavigator()
        self.loads=PaneLoadCoordinator()
        self.views=ViewCoordinator()
        self.catalog_generation=0
        self.catalog=[]
        self._catalog_ready=False
        self._last_group_index=None
        self._active_alignment=None
        self._last_selected=0
        self._changing_for_group=False
        super().__init__()
        self.setWindowTitle('DirectRGB Compare vNext | SDR video inspection')
        QApplication.instance().installEventFilter(self)
        if self.settings.data['last_folder']:
            QTimer.singleShot(0,lambda:self.browser.set_folder(self.settings.data['last_folder']))

    def _init_ui(self):
        super()._init_ui()
        self.browser=FileBrowser(self)
        self.browser.folderChanged.connect(self._folder_changed)
        self.browser.multiLoadRequested.connect(self._selected_files)
        self.browser.fileActivated.connect(lambda path:self.load_paths(self.selected_index,[path]))
        self.browser.recursiveChanged.connect(self._recursive_changed)
        self.browser.recursive.setChecked(self.settings.data['recursive_scan'])
        self.browser_dock=QDockWidget('Video files',self)
        self.browser_dock.setObjectName('DirectRGBFileBrowserDock')
        self.browser_dock.setWidget(self.browser)
        self.addDockWidget(Qt.DockWidgetArea.LeftDockWidgetArea,self.browser_dock)
        self.browser_dock.setMinimumWidth(250)
        self.browser_dock.setVisible(True)
        self.actions=QtCommandRegistry(self,self.settings)
        # Reuse toolbar actions rather than generating duplicate shortcuts.
        toolbar_actions={a.text():a for t in self.findChildren(QWidget) if t.__class__.__name__=='QToolBar' for a in t.actions() if a.text()}
        command_entries=[
            ('file.open_folder','Open Folder','Ctrl+Shift+O',self.open_folder,None,'Files'),
            ('file.open_videos','Open videos…','Ctrl+O',None,'Open videos…','Files'),
            ('file.load_selected','Load Selected','Ctrl+L',self._selected_files_from_browser,None,'Files'),
            ('set.next','Next Set','Ctrl+PgDown',lambda:self.navigate_set(1),None,'Sets'),
            ('set.previous','Previous Set','Ctrl+PgUp',lambda:self.navigate_set(-1),None,'Sets'),
            ('view.next_pane','Next Pane','Tab',lambda:self.select_pane((self.selected_index+1)%self.visible_count),None,'Pane'),
            ('view.prev_pane','Previous Pane','Shift+Tab',lambda:self.select_pane((self.selected_index-1)%self.visible_count),None,'Pane'),
            ('transport.play','Play / Pause','Space',None,'Play / Pause','Playback'),
            ('transport.step_back','⟵ Frame',',',None,'⟵ Frame','Playback'),
            ('transport.step_forward','Frame ⟶','.',None,'Frame ⟶','Playback'),
            ('transport.back1','Seek -1s','Left',lambda:self.seek_all(max(0,self.clock.master_position-1)),None,'Playback'),
            ('transport.forward1','Seek +1s','Right',lambda:self.seek_all(self.clock.master_position+1),None,'Playback'),
            ('transport.back5','Seek -5s','Shift+Left',lambda:self.seek_all(max(0,self.clock.master_position-5)),None,'Playback'),
            ('transport.forward5','Seek +5s','Shift+Right',lambda:self.seek_all(self.clock.master_position+5),None,'Playback'),
            ('transport.home','Beginning','Home',lambda:self.seek_all(0),None,'Playback'),
            ('transport.end','End','End',lambda:self.seek_all(self._timeline_max),None,'Playback'),
            ('view.fit','Fit to pane','F',lambda:self.set_zoom_mode('fit',1),None,'View'),
            ('view.native','Native pixels','Ctrl+1',lambda:self.set_zoom_mode('native',1),None,'View'),
            ('view.200','200% pixels','Ctrl+2',lambda:self.set_zoom_mode('native',2),None,'View'),
            ('view.zoomin','+','Ctrl++',None,'+','View'),
            ('view.zoomout','−','Ctrl+-',None,'−','View'),
            ('view.reset','Reset','Ctrl+0',None,'Reset','View'),
            ('view.panleft','←','Alt+Left',None,'←','View'),
            ('view.panright','→','Alt+Right',None,'→','View'),
            ('view.panup','↑','Alt+Up',None,'↑','View'),
            ('view.pandown','↓','Alt+Down',None,'↓','View'),
            ('sync.here','Synchronize Here','Ctrl+Shift+Y',self.sync_here,None,'Sync'),
            ('diag.toggle','Toggle Diagnostics','Ctrl+D',self._toggle_diagnostics,None,'Diagnostics'),
            ('view.fullscreen','Full screen','F11',None,'Full screen','View'),
            ('commands.help','Shortcut Help','F1',self.show_shortcuts,None,'Commands'),
        ]
        for cid,label,shortcut,callback,existing,category in command_entries:
            action=toolbar_actions.get(existing) if existing else None
            if action is not None:
                action.setShortcut(QKeySequence())
            self.actions.register(cid,label,shortcut,callback,action=action,category=category)
        self._vnext_toolbar=self.addToolBar('Browser and comparison sets')
        self._vnext_toolbar.addAction(self.actions.actions['file.open_folder'])
        self._vnext_toolbar.addAction(self.actions.actions['set.previous'])
        self.set_label=QLabel('Set: none')
        self._vnext_toolbar.addWidget(self.set_label)
        self._vnext_toolbar.addAction(self.actions.actions['set.next'])
        seq_button=QToolButton(self);seq_button.setText('Create sequential sets')
        seq_button.clicked.connect(self.group_sequential)
        self._vnext_toolbar.addWidget(seq_button)
        self.pattern_button=QToolButton(self);self.pattern_button.setText('Group by filename…')
        self.pattern_button.clicked.connect(self.group_pattern)
        self._vnext_toolbar.addWidget(self.pattern_button)
        self._vnext_toolbar.addAction(self.actions.actions['sync.here'])
        self.sync_status_label=QLabel('Sync: not anchored')
        self._vnext_toolbar.addWidget(self.sync_status_label)
        self._vnext_toolbar.addAction(self.actions.actions['commands.help'])
        self._vnext_toolbar.addAction(self.actions.actions['diag.toggle'])
        export=self._vnext_toolbar.addAction('Export diagnostics')
        export.triggered.connect(self.export_diagnostics)
        self.zoom_combo.setToolTip('Fit/native geometry is DPI-aware; physical equality must be verified on Windows')

    def eventFilter(self,obj,event):
        # Protect text editing from app-wide single-key and modifier shortcuts.
        if event.type()==QEvent.Type.ShortcutOverride:
            focus=QApplication.focusWidget()
            if isinstance(focus,(QLineEdit,QTextEdit,QPlainTextEdit,QAbstractSpinBox,QKeySequenceEdit)) or (isinstance(focus,QComboBox) and focus.isEditable()):
                event.accept()
                return True
        return super().eventFilter(obj,event)

    def show_shortcuts(self):
        ShortcutEditor(self.actions,self).exec()

    def open_folder(self):
        folder=QFileDialog.getExistingDirectory(self,'Open video directory',self.browser.folder or str(Path.home()))
        if folder:self.browser.set_folder(folder)

    def _folder_changed(self,folder):
        self.settings.data['last_folder']=folder
        self.settings.save()
        self._catalog_scan()
        self.log.record('folder','opened',path=folder)

    def _recursive_changed(self,enabled):
        self.settings.data['recursive_scan']=enabled
        self.settings.save()
        if self.browser.folder:self._catalog_scan()

    def _catalog_scan(self):
        self.catalog_generation+=1
        self._catalog_ready=False
        self.set_label.setText('Scanning folder…')
        task=CatalogJob(self.browser.folder,self.browser.recursive.isChecked(),self.catalog_generation,self._catalog_signals)
        self.pool.start(task)

    def _catalog_done(self,generation,items):
        if generation!=self.catalog_generation:return
        self.catalog=items;self._catalog_ready=True
        self.set_label.setText(f'{len(items)} videos · Create Sets')
        self.log.record('catalog','scan complete',files=len(items),recursive=self.browser.recursive.isChecked())

    def _catalog_failed(self,generation,error):
        if generation!=self.catalog_generation:return
        self._catalog_ready=False
        self.set_label.setText('Scan failed')
        self.log.record('catalog','scan failed',error=error)
        self.statusBar().showMessage('Folder scan failed: '+error)

    def _connect_panes(self):
        super()._connect_panes()
        self._catalog_signals=CatalogSignals()
        self._catalog_signals.ready.connect(self._catalog_done)
        self._catalog_signals.failed.connect(self._catalog_failed)
        # Each pane can be positioned independently before Sync Here.
        for pane in self.panes:
            bottom=pane.layout().itemAt(pane.layout().count()-1).layout()
            prev=QToolButton(pane);prev.setText('◁');prev.setToolTip('Step only this video backward')
            prev.clicked.connect(lambda _=False,p=pane:self.individual_step(p,-1))
            next_=QToolButton(pane);next_.setText('▷');next_.setToolTip('Step only this video forward')
            next_.clicked.connect(lambda _=False,p=pane:self.individual_step(p,1))
            seek=QToolButton(pane);seek.setText('Go…');seek.setToolTip('Seek only this video to a timestamp')
            seek.clicked.connect(lambda _=False,p=pane:self.individual_seek(p))
            master=QToolButton(pane);master.setText('Master');master.setToolTip('Select this pane as Sync Here master')
            master.clicked.connect(lambda _=False,p=pane:self.select_pane(p.index))
            bottom.addWidget(prev);bottom.addWidget(next_);bottom.addWidget(seek);bottom.addWidget(master)
            pane.host.viewportChanged.connect(lambda p=pane:self._apply_view(p.index))
        # Additional zoom/pan signals already connected in superclass.

    def individual_step(self,pane,direction):
        if pane.player is None:return
        self.clock.paused=True
        for _,p in self._loaded():p.player.pause(True)
        try:pane.player.command('frame-step' if direction>0 else 'frame-back-step')
        except Exception as exc:self.statusBar().showMessage('Individual step failed: '+str(exc))
        self.log.record('sync','individual frame step',pane=pane.index,direction=direction)

    def individual_seek(self,pane):
        if pane.player is None:return
        self.clock.paused=True
        for _,p in self._loaded():p.player.pause(True)
        current=pane.player.get_double('video-pts') or 0.
        at,ok=QInputDialog.getDouble(self,'Seek this pane','Timestamp in seconds:',current,0,86400,3)
        if ok:
            pane.player.seek(at)
            self.log.record('sync','individual seek',pane=pane.index,target=at)

    def _available_catalog(self):
        if not self._catalog_ready:
            QMessageBox.information(self,'Folder scan','Open a folder and allow its file listing to finish.')
            return []
        query=self.browser.search.text().casefold().strip()
        entries=[e for e in self.catalog if query in e.name.casefold()]
        mode=['name','date','size','type'][self.browser.sort_box.currentIndex()]
        return [e.path for e in sort_entries(entries,mode)]

    def group_sequential(self):
        paths=self._available_catalog()
        if not paths:return
        groups=sequential_sets(paths,self.visible_count,preserve_order=True)
        preview='\n'.join(f'{g.key}: '+', '.join(Path(p).name if p else '(empty)' for p in g.slots) for g in groups[:6])
        if QMessageBox.question(self,'Preview sequential sets',
            f'{len(groups)} comparison sets will be created.\n\n{preview}\n\nLoad the first set?')!=QMessageBox.StandardButton.Yes:
            return
        self._set_groups(groups)

    def group_pattern(self):
        paths=self._available_catalog()
        if not paths:return
        variants,ok=QInputDialog.getText(self,'Comparison variants','Variants in pane order, comma-separated:',text='Original,ISP,HDR,Denoised')
        if not ok:return
        vs=tuple(v.strip() for v in variants.split(',') if v.strip())
        if not 1<=len(vs)<=4:
            QMessageBox.warning(self,'Variant count','Provide between 1 and 4 variants.');return
        expr=r'(?P<key>.+?)_(?P<variant>'+ '|'.join(re.escape(v) for v in vs)+r')'
        try:groups,unmatched=pattern_sets(paths,PatternRule(expr,vs))
        except ValueError as exc:QMessageBox.warning(self,'Pattern error',str(exc));return
        if not groups:
            QMessageBox.warning(self,'No matches','No files matched the specified variant names.');return
        preview='\n'.join(f'{g.key}: '+', '.join(Path(p).name if p else '(empty)' for p in g.slots) for g in groups[:8])
        question=f'{len(groups)} sets, {len(unmatched)} unmatched/duplicate files.\n\n{preview}\n\nLoad these groups?'
        if QMessageBox.question(self,'Preview comparison sets',question)!=QMessageBox.StandardButton.Yes:return
        self.layout_combo.setCurrentIndex(len(vs)-1)
        self._set_groups(groups)

    def _set_groups(self,groups):
        self.navigator.configure(groups)
        self._apply_group()

    def navigate_set(self,delta):
        if not self.navigator.sets:
            self.group_sequential()
            return
        old=self.navigator.index
        self.navigator.move(delta)
        if old!=self.navigator.index:self._apply_group()

    def _apply_group(self):
        group=self.navigator.current
        if not group:return
        self.clock.paused=True
        for _,pane in self._loaded():pane.player.pause(True)
        self._active_alignment=None
        self._alignment_source='none'
        self.sync_status_label.setText('Sync: not anchored')
        self._last_sync_seek.clear()
        for pane in self.panes:
            pane.offset_editor.blockSignals(True)
            pane.offset_editor.setValue(0)
            pane.offset=0.0
            pane.offset_editor.blockSignals(False)
        self.master_index=None
        self.visible_count=len(group.slots)
        self._changing_for_group=True
        try:
            if self.layout_combo.currentIndex()!=self.visible_count-1:
                self.layout_combo.setCurrentIndex(self.visible_count-1)
        finally:
            self._changing_for_group=False
        for i,path in enumerate(group.slots):
            # Group changes are atomic at the UI boundary: old clips are closed
            # immediately so no pane displays footage belonging to the prior set.
            self.panes[i].clear()
            if path and Path(path).is_file():self._start_probe(i,path)
            else:
                self.loads.cancel(i)
                self._loading.discard(i)
                self.panes[i].status.setText('Missing variant' if path else 'Empty variant slot')
        self._choose_master()
        self.set_label.setText(f'Set {self.navigator.index+1}/{len(self.navigator.sets)} · {group.key}')
        self.log.record('group','group selected',index=self.navigator.index,count=len(group.slots),generation=self.navigator.generation)

    def _selected_files_from_browser(self):
        self._selected_files(self.browser.selected_files())

    def _selected_files(self,paths):
        paths=[p for p in paths if is_video(p)]
        if not paths:return
        if len(paths)>4:
            dialog=QMessageBox(self)
            dialog.setWindowTitle('More than four videos')
            dialog.setText(f'{len(paths)} videos selected. Choose how to load them.')
            sets=dialog.addButton('Create comparison sets',QMessageBox.ButtonRole.AcceptRole)
            first=dialog.addButton('Load first four only',QMessageBox.ButtonRole.ActionRole)
            dialog.addButton(QMessageBox.StandardButton.Cancel)
            dialog.exec()
            if dialog.clickedButton()==sets:
                self._set_groups(sequential_sets(paths,self.visible_count,preserve_order=True))
            elif dialog.clickedButton()==first:
                self.load_paths(0,paths[:4])
            return
        self.load_paths(0,paths)

    def load_paths(self,start,paths):
        paths=list(paths)
        if len(paths)==1 and Path(paths[0]).is_dir():
            self.browser.set_folder(paths[0]);return
        if any(Path(p).is_dir() for p in paths):
            self.browser.set_folder(next(p for p in paths if Path(p).is_dir()));return
        paths=[p for p in paths if is_video(p) and Path(p).is_file()]
        if not paths:return
        if 1<len(paths)<=4 and len(paths)>self.visible_count:
            self.layout_combo.setCurrentIndex(len(paths)-1)
        if len(paths)>4:
            self._selected_files(paths);return
        # Manual loading exits the prior comparison set rather than silently
        # retaining a stale Next/Previous group mapping.
        if self.navigator.sets:
            self.navigator.configure([])
            self.set_label.setText('Set: none (manual selection)')
        # Multiple files dropped into empty slots first; overwriting occupied
        # panes only after the user confirms replacement.
        if len(paths)>1:
            preferred=list(range(start,min(self.visible_count,4)))+list(range(0,start))
            free=[i for i in preferred if not self.panes[i].path]
            taken=[i for i in preferred if self.panes[i].path]
            slots=(free+taken)[:len(paths)]
        else:
            slots=[start]
        if any(self.panes[i].path for i in slots):
            if QMessageBox.question(self,'Replace video?',f'Replace {sum(bool(self.panes[i].path) for i in slots)} existing pane(s)?')!=QMessageBox.StandardButton.Yes:
                return
        for i,path in zip(slots,paths):
            if i>=self.visible_count:self.layout_combo.setCurrentIndex(i)
            self._start_probe(i,path)

    def _start_probe(self,idx,path):
        # Keep the old decoded image visible until the new media passes probe.
        pane=self.panes[idx]
        req=self.loads.begin(idx,path,self.navigator.generation)
        pane.token=req.token
        pane.status.setText('Probing replacement…' if pane.player else 'Probing…')
        self._loading.add(idx)
        self.log.record('load','probe requested',pane=idx,token=req.token,path=path)
        self.pool.start(ProbeTask(idx,req.token,path,self._probe_signals))

    def _on_probe_error(self,idx,token,error):
        if not self.loads.complete(idx,token,self.navigator.generation):return
        self._loading.discard(idx)
        self.panes[idx].status.setText('Load failed; previous video preserved' if self.panes[idx].player else 'Load failed')
        self.log.record('load','probe failed',pane=idx,error=error)
        QMessageBox.warning(self,'Media probe failed',error)

    def _on_probe(self,idx,token,data):
        if not self.loads.complete(idx,token,self.navigator.generation):return
        eligible,warning=data.eligibility
        if not eligible:
            self._loading.discard(idx)
            self.log.record('load','unsupported HDR/wide gamut',pane=idx)
            self.panes[idx].status.setText('Blocked: HDR / wide-gamut source')
            QMessageBox.warning(self,'Unsupported source',warning)
            return
        pane=self.panes[idx]
        if pane.player:
            pane.player.close();pane.player=None
        super()._on_probe(idx,token,data)
        if pane.player:
            self._apply_view(idx)
            self.log.record('load','loaded',pane=idx,path=data.path,codec=data.codec)

    def remove_one(self,idx):
        self.loads.cancel(idx)
        self._loading.discard(idx)
        super().remove_one(idx)

    def move_pane(self,idx,direction):
        j=idx+direction
        if not 0<=j<self.visible_count or idx in self._loading or j in self._loading:return
        super().move_pane(idx,direction)
        self.views.states[idx],self.views.states[j]=self.views.states[j],self.views.states[idx]
        self.loads.tokens[idx],self.loads.tokens[j]=self.loads.tokens[j],self.loads.tokens[idx]

    def change_count(self,idx):
        super().change_count(idx)
        if not self._changing_for_group:
            self.navigator.configure([])
            if hasattr(self,'set_label'):self.set_label.setText('Set: none')

    def _geometry(self,idx):
        p=self.panes[idx]
        m=p.metadata
        if not m:return None
        try: rotation=int(float(m.rotation)) if m.rotation!='Unspecified' else 0
        except ValueError: rotation=0
        return Geometry(m.width,m.height,max(p.host.width(),1),max(p.host.height(),1),
                        max(float(p.host.devicePixelRatioF()),.01),parse_sar(m.sar),rotation%360)

    def _apply_view(self,idx):
        pane=self.panes[idx]
        g=self._geometry(idx)
        if pane.player is None or g is None:return
        for name,value in g.to_mpv(self.views.states[idx]).items():
            pane.player.set(name,value)

    def _apply_all_views(self):
        for idx,p in self._loaded():self._apply_view(idx)

    def apply_zoom_mode(self,*_):
        if not hasattr(self,'views'):return
        selection=self.zoom_combo.currentIndex()
        mode='fit' if selection==0 else 'native'
        mag=2 if selection==2 else 1
        self.set_zoom_mode(mode,mag)

    def set_zoom_mode(self,mode,mag):
        for i in (range(self.visible_count) if self.zoom_sync.isChecked() else [self.selected_index]):
            s=self.views.states[i]
            self.views.states[i]=replace(s,mode=mode,magnification=mag)
        self._apply_all_views()

    def _view_targets_index(self):
        return [i for i,_ in self._loaded()] if self.zoom_sync.isChecked() else [self.selected_index]

    def pane_zoom(self,index,amount,x,y):
        self.select_pane(index)
        self._zoom_at(index,2**amount,x,y)

    def zoom_by(self,delta):
        idx=self.selected_index;g=self._geometry(idx)
        if g:self._zoom_at(idx,2**delta,g.viewport_width/2,g.viewport_height/2)

    def _zoom_at(self,idx,factor,x,y):
        g=self._geometry(idx)
        if not g:return
        other={j:self._geometry(j) for j,_ in self._loaded() if j!=idx}
        self.views.zoom_sync=self.zoom_sync.isChecked()
        self.views.pan_sync=self.pan_sync.isChecked()
        self.views.zoom(idx,g,x,y,factor,other)
        self._apply_all_views()
        self.log.record('view','zoom',pane=idx,mode=self.views.states[idx].mode,
                        zoom=self.views.states[idx].magnification,cx=self.views.states[idx].cx,cy=self.views.states[idx].cy)

    def pane_pan(self,index,dx,dy):
        self.select_pane(index)
        g=self._geometry(index)
        if g:self._pan_pixels(index,dx*g.viewport_width,dy*g.viewport_height)

    def _pan_pixels(self,idx,dx,dy):
        g=self._geometry(idx)
        if not g:return
        self.views.pan_sync=self.pan_sync.isChecked()
        self.views.pan(idx,g,dx,dy,[j for j,_ in self._loaded()])
        self._apply_all_views()

    def pan_by(self,dx,dy):
        g=self._geometry(self.selected_index)
        if g:self._pan_pixels(self.selected_index,dx*g.viewport_width,dy*g.viewport_height)

    def reset_view(self):
        indexes=[i for i,_ in self._loaded()] if self.zoom_sync.isChecked() else [self.selected_index]
        self.views.reset(indexes=indexes)
        self.zoom_combo.blockSignals(True);self.zoom_combo.setCurrentIndex(0);self.zoom_combo.blockSignals(False)
        self._apply_all_views()

    def sync_here(self):
        loaded=self._loaded()
        if len(loaded)<2:
            QMessageBox.information(self,'Sync Here','Load at least two videos.');return
        if not self.clock.paused:
            QMessageBox.warning(self,'Sync Here','Pause all videos first, then position each pane on the same visual event.')
            return
        master=self.selected_index if self.panes[self.selected_index].player else loaded[0][0]
        measurements={i:select_timestamp(p.player.get_double('video-pts'),p.player.get_double('time-pos')) for i,p in loaded}
        estimated=any(kind!='video-pts' for _,kind in measurements.values())
        if estimated:
            text='This libmpv build does not expose a verified presented-frame PTS for all panes.\n\n'
            text+='Sync can use time-pos as a PROVISIONAL playback-position estimate, not a verified frame anchor.\n'
            text+='Do you want to create a provisional alignment?'
            if QMessageBox.question(self,'Frame PTS unavailable',text)!=QMessageBox.StandardButton.Yes:return
        if any(p.player.get_bool('vo-configured') is not True for _,p in loaded):
            QMessageBox.warning(self,'Video frame not ready','All loaded panes must have an active video renderer before setting anchors.')
            return
        observed={i:t for i,(t,kind) in measurements.items()}
        try:anchor=align_here(master,observed)
        except ValueError as exc:
            QMessageBox.warning(self,'Presentation timestamps unavailable',str(exc));return
        self._active_alignment=anchor
        self._alignment_source=('PROVISIONAL time-pos' if estimated else 'video-pts')
        self.sync_status_label.setText('Sync: '+self._alignment_source)
        self.master_index=master
        self.clock.master_position=anchor.observed_pts[master]
        for i,p in loaded:
            p.offset_editor.blockSignals(True)
            p.offset_editor.setValue(anchor.offsets[i])
            p.offset=anchor.offsets[i]
            p.offset_editor.blockSignals(False)
        self.log.record('sync','manual anchors set',master=master,
                        offsets=str(anchor.offsets),observed_pts=str(anchor.observed_pts))
        self.statusBar().showMessage(f'Sync Here: pane {master+1}, {self._alignment_source}. Verify actual frame alignment.')
        self.refresh_diagnostics()

    def _sync_pause_positions(self):
        if self.master_index is None:return
        master=self.panes[self.master_index].player
        if not master:return
        pts,_=select_timestamp(master.get_double('video-pts'),master.get_double('time-pos'))
        if pts is None:return
        for idx,pane in self._loaded():
            if idx==self.master_index:continue
            target=target_pts(pts,pane.offset,pane.metadata.duration if pane.metadata else None)
            if target is None:
                pane.status.setText('Out of sync time range')
                continue
            pane.player.seek(target)

    def seek_all(self,t):
        self.clock.master_position=max(0,float(t))
        for idx,pane in self._loaded():
            tgt=(self.clock.master_position if idx==self.master_index else
                 target_pts(self.clock.master_position,pane.offset,pane.metadata.duration if pane.metadata else None))
            if tgt is None:
                pane.status.setText('Target outside video duration')
                continue
            pane.player.seek(tgt)
        self.time_label.setText(f'{self.format_time(t)} / {self.format_time(self._timeline_max)}')

    def _tick(self):
        super()._tick()
        # Existing master re-seek loop still performs best-effort correction.
        # vNext's new anchor calculations are numerical but not frame-locked.

    def _toggle_diagnostics(self):
        self.diagnostics_dock.setVisible(not self.diagnostics_dock.isVisible())

    def refresh_diagnostics(self):
        super().refresh_diagnostics()
        if not hasattr(self,'actions'):return
        pane=self.panes[self.selected_index]
        if not self.diagnostics.hasFocus():
            try:base=json.loads(self.diagnostics.toPlainText())
            except ValueError:base={}
            base['vnext']={
                'view_state':vars(self.views.states[self.selected_index]),
                'load_pending':{i:vars(req) for i,req in self.loads.pending.items()},
                'comparison_set':self.navigator.index+1 if self.navigator.sets else None,
                'comparison_set_total':len(self.navigator.sets),
                'manual_sync_anchor':vars(self._active_alignment) if self._active_alignment else None,
                'alignment_time_source':getattr(self,'_alignment_source','none'),
                'recent_events':self.log.dump()[-12:]
            }
            self.diagnostics.setPlainText(json.dumps(base,indent=2,ensure_ascii=False,default=str))

    def export_diagnostics(self):
        name,_=QFileDialog.getSaveFileName(self,'Export diagnostic events',str(Path.home()/'directrgb_diagnostics.json'),'JSON (*.json)')
        if not name:return
        result={'application':'DirectRGBCompare vNext','renderer_policy':'UNCHANGED v5',
                'faststone_cms_off_numerical_match':'NOT VERIFIED',
                'events':self.log.dump(),
                'group':self.navigator.current.key if self.navigator.current else None,
                'sync_anchor':vars(self._active_alignment) if self._active_alignment else None,
                'alignment_time_source':getattr(self,'_alignment_source','none'),
                'views':{str(i):vars(s) for i,s in self.views.states.items()}}
        Path(name).write_text(json.dumps(result,indent=2,default=str),encoding='utf8')

    def closeEvent(self,event):
        self.settings.save()
        QApplication.instance().removeEventFilter(self)
        super().closeEvent(event)

    def dropEvent(self,event):
        paths=[u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.load_paths(0,paths)
            event.acceptProposedAction()


def run():
    from .paths import missing_runtime_files
    app=QApplication(sys.argv)
    app.setApplicationName('DirectRGB Compare')
    if sys.platform=='win32':
        missing=missing_runtime_files()
        if missing:
            QMessageBox.critical(None,'Required runtime missing','Missing: '+', '.join(missing)+'\nRun RUN_FIRST.bat to provision native libraries.')
            return 2
    win=MainWindow()
    win.show()
    return app.exec()
