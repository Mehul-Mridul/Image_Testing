"""Windows PySide6 shell embedding libmpv into four native, independent panes.

Known limits: without libmpv render-API ownership we cannot inspect GPU texels;
child HWND input routing for mouse dragging depends on backend. Toolbar pan/zoom
and keyboard shortcuts remain available for deterministic control.
"""
from __future__ import annotations
import json
import math
import sys
from pathlib import Path
from time import monotonic
from PySide6.QtCore import Qt, QObject, QRunnable, Signal, QThreadPool, QTimer, QSize, QEvent
from PySide6.QtGui import QAction, QDragEnterEvent, QDropEvent, QKeySequence
from PySide6.QtWidgets import (
    QApplication, QMainWindow, QWidget, QFrame, QHBoxLayout, QVBoxLayout,
    QGridLayout, QLabel, QToolButton, QPushButton, QComboBox, QSlider,
    QFileDialog, QMessageBox, QDockWidget, QPlainTextEdit, QDoubleSpinBox,
    QCheckBox, QToolBar, QMenu, QInputDialog, QSplitter,
)
from .mpv_native import MpvPanePlayer, MpvError
from .probe import probe_file, VideoMetadata
from .policy import DisplayMode, Overrides
from .sync import Clock


class ProbeSignals(QObject):
    done = Signal(int, int, object)
    fail = Signal(int, int, str)

class ProbeTask(QRunnable):
    def __init__(self, index: int, token: int, path: str, signals: ProbeSignals):
        super().__init__()
        self.index, self.token, self.path, self.signals = index, token, path, signals

    def run(self):
        try:
            data = probe_file(self.path)
            self.signals.done.emit(self.index, self.token, data)
        except Exception as exc:
            self.signals.fail.emit(self.index, self.token, f'{type(exc).__name__}: {exc}')


class NativeVideoHost(QFrame):
    clicked = Signal()
    viewportChanged = Signal()
    filesDropped = Signal(object)
    zoomBy = Signal(float, float, float)
    movedBy = Signal(float, float)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.setObjectName('videoHost')
        self.setAttribute(Qt.WidgetAttribute.WA_NativeWindow, True)
        self.setMinimumSize(120, 90)
        self.setMouseTracking(True)
        self._drag_pos = None
        # Let the enclosing VideoPane accept file drops; child hosts otherwise steal them.
        self.setAcceptDrops(True)

    def dragEnterEvent(self,event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()

    def dropEvent(self,event):
        paths=[u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        if paths: self.filesDropped.emit(paths);event.acceptProposedAction()

    def resizeEvent(self,event):
        super().resizeEvent(event)
        self.viewportChanged.emit()

    def wheelEvent(self, event):
        self.zoomBy.emit(event.angleDelta().y() / 120.0 * 0.14,
                         event.position().x(), event.position().y())
        event.accept()

    def mousePressEvent(self, event):
        if event.button() == Qt.MouseButton.LeftButton:
            self._drag_pos = event.position()
            self.clicked.emit()
        super().mousePressEvent(event)

    def mouseMoveEvent(self, event):
        if self._drag_pos is not None:
            delta = event.position() - self._drag_pos
            self._drag_pos = event.position()
            self.movedBy.emit(delta.x() / max(self.width(), 1),
                              delta.y() / max(self.height(), 1))
            event.accept()
            return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self, event):
        self._drag_pos = None
        super().mouseReleaseEvent(event)


class VideoPane(QFrame):
    openRequested = Signal(int)
    removeRequested = Signal(int)
    selected = Signal(int)
    moveRequested = Signal(int, int)
    filesDropped = Signal(int, object)
    zoomBy = Signal(int, float, float, float)
    panBy = Signal(int, float, float)
    offsetChanged = Signal(int, float)

    def __init__(self, index: int):
        super().__init__()
        self.index = index
        self.metadata: VideoMetadata | None = None
        self.player: MpvPanePlayer | None = None
        self.path = None
        self.token = 0
        self.offset = 0.0
        self.loaded_at = None
        self.setAcceptDrops(True)
        self.setObjectName('pane')
        self.setFrameShape(QFrame.Shape.StyledPanel)
        layout = QVBoxLayout(self)
        layout.setContentsMargins(5, 5, 5, 5)
        layout.setSpacing(5)
        header = QHBoxLayout()
        self.name = QLabel(f'Pane {index + 1} — drop a video or click Open')
        self.name.setMinimumWidth(20)
        self.name.setToolTip('Click to select pane')
        header.addWidget(self.name, 1)
        self.open_btn = QToolButton(); self.open_btn.setText('Open')
        self.open_btn.clicked.connect(lambda: self.openRequested.emit(self.index))
        header.addWidget(self.open_btn)
        self.remove_btn = QToolButton(); self.remove_btn.setText('×')
        self.remove_btn.setToolTip('Remove video')
        self.remove_btn.clicked.connect(lambda: self.removeRequested.emit(self.index))
        header.addWidget(self.remove_btn)
        self.left_btn = QToolButton(); self.left_btn.setText('←')
        self.left_btn.setToolTip('Move pane left in sequence')
        self.left_btn.clicked.connect(lambda: self.moveRequested.emit(self.index, -1))
        header.addWidget(self.left_btn)
        self.right_btn = QToolButton(); self.right_btn.setText('→')
        self.right_btn.setToolTip('Move pane right in sequence')
        self.right_btn.clicked.connect(lambda: self.moveRequested.emit(self.index, 1))
        header.addWidget(self.right_btn)
        layout.addLayout(header)

        self.host = NativeVideoHost()
        self.host.zoomBy.connect(lambda amount,x,y: self.zoomBy.emit(self.index, amount,x,y))
        self.host.movedBy.connect(lambda dx,dy: self.panBy.emit(self.index,dx,dy))
        self.host.filesDropped.connect(lambda paths: self.filesDropped.emit(self.index,paths))
        self.host.clicked.connect(lambda:self.selected.emit(self.index))
        self.placeholder = QLabel('No video loaded\nDrag and drop a file here')
        self.placeholder.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.placeholder.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents, True)
        host_layout = QVBoxLayout(self.host)
        host_layout.addWidget(self.placeholder)
        layout.addWidget(self.host, 1)
        bottom = QHBoxLayout()
        self.status = QLabel('Waiting')
        bottom.addWidget(self.status, 1)
        bottom.addWidget(QLabel('Offset (s)'))
        self.offset_editor = QDoubleSpinBox()
        self.offset_editor.setRange(-86400, 86400)
        self.offset_editor.setDecimals(3)
        self.offset_editor.setSingleStep(.033)
        self.offset_editor.setFixedWidth(92)
        self.offset_editor.valueChanged.connect(self._offset_changed)
        bottom.addWidget(self.offset_editor)
        layout.addLayout(bottom)

    def _offset_changed(self, offset):
        self.offset = float(offset)
        self.offsetChanged.emit(self.index, self.offset)

    def mousePressEvent(self, event):
        self.selected.emit(self.index)
        super().mousePressEvent(event)

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls():
            event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [u.toLocalFile() for u in event.mimeData().urls() if u.isLocalFile()]
        if paths:
            self.filesDropped.emit(self.index, paths)
            event.acceptProposedAction()

    def clear(self):
        self.token += 1
        self.metadata = None
        self.path = None
        self.loaded_at = None
        if self.player:
            self.player.close()
            self.player = None
        self.placeholder.setText('No video loaded\nDrag and drop a file here')
        self.placeholder.show()
        self.name.setText(f'Pane {self.index + 1} — drop a video or click Open')
        self.status.setText('Waiting')


class MainWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle('DirectRGB Compare  |  SDR video inspection')
        self.clock = Clock()
        self.panes = [VideoPane(i) for i in range(4)]
        self.selected_index = 0
        self.master_index = None
        self.visible_count = 2
        self._scrubbing = False
        self._loading = set()
        self._step_await = None
        self._last_sync_seek = {}
        self._is_fullscreen = False
        self._timeline_max = 0.0
        self._probe_signals = ProbeSignals()
        self._probe_signals.done.connect(self._on_probe)
        self._probe_signals.fail.connect(self._on_probe_error)
        self.pool = QThreadPool.globalInstance()
        self._init_ui()
        self._connect_panes()
        self._layout_panes()
        self.timer = QTimer(self)
        self.timer.setInterval(150)
        self.timer.timeout.connect(self._tick)
        self.timer.start()
        screen = QApplication.primaryScreen().availableGeometry()
        self.resize(min(1420, int(screen.width()*0.82)),
                    min(880, int(screen.height()*0.82)))
        self.setMinimumSize(670, 440)
        self.select_pane(0)

    def _init_ui(self):
        self.grid_host = QWidget()
        self.grid = QGridLayout(self.grid_host)
        self.grid.setSpacing(6)
        self.grid.setContentsMargins(8,8,8,8)
        self.setCentralWidget(self.grid_host)
        tb = QToolBar('Comparison controls')
        tb.setMovable(False)
        self.addToolBar(tb)
        tb.addWidget(QLabel(' Views  '))
        self.layout_combo = QComboBox()
        self.layout_combo.addItems(['1 video', '2 videos', '3 videos', '4 videos'])
        self.layout_combo.setCurrentIndex(1)
        self.layout_combo.currentIndexChanged.connect(self.change_count)
        tb.addWidget(self.layout_combo)
        tb.addSeparator()
        self._toolbar_action(tb, 'Open videos…', self.open_multiple, 'Ctrl+O')
        self._toolbar_action(tb, 'Play / Pause', self.toggle_play, 'Space')
        self._toolbar_action(tb, '⟵ Frame', lambda: self.step(-1), ',')
        self._toolbar_action(tb, 'Frame ⟶', lambda: self.step(1), '.')
        self._toolbar_action(tb, 'Stop', self.stop_all)
        tb.addSeparator()
        tb.addWidget(QLabel(' Speed '))
        self.speed = QComboBox()
        self.speed.addItems(['0.25×','0.5×','1×','1.5×','2×'])
        self.speed.setCurrentText('1×')
        self.speed.currentTextChanged.connect(self.change_speed)
        tb.addWidget(self.speed)
        self.loop_box = QCheckBox('Loop')
        self.loop_box.toggled.connect(lambda value: setattr(self.clock,'loop',value))
        tb.addWidget(self.loop_box)
        tb.addSeparator()
        self._toolbar_action(tb,'Full screen',self.fullscreen_toggle,'F11')
        self._toolbar_action(tb,'Save renderer PNG',self.save_screenshot)

        tb2 = QToolBar('Pixel inspection controls')
        tb2.setMovable(False)
        self.addToolBarBreak()
        self.addToolBar(tb2)
        tb2.addWidget(QLabel(' View '))
        self.zoom_combo = QComboBox()
        self.zoom_combo.addItems(['Fit', '100% native pixels', '200% native pixels'])
        self.zoom_combo.currentIndexChanged.connect(self.apply_zoom_mode)
        tb2.addWidget(self.zoom_combo)
        self._toolbar_action(tb2, '−', lambda: self.zoom_by(-0.20), 'Ctrl+-')
        self._toolbar_action(tb2, '+', lambda: self.zoom_by(0.20), 'Ctrl+=')
        self._toolbar_action(tb2, '←', lambda: self.pan_by(-.07,0), 'Alt+Left')
        self._toolbar_action(tb2, '→', lambda: self.pan_by(.07,0), 'Alt+Right')
        self._toolbar_action(tb2, '↑', lambda: self.pan_by(0,-.07), 'Alt+Up')
        self._toolbar_action(tb2, '↓', lambda: self.pan_by(0,.07), 'Alt+Down')
        self._toolbar_action(tb2, 'Reset', self.reset_view, 'Ctrl+0')
        self.zoom_sync = QCheckBox('Sync zoom'); self.zoom_sync.setChecked(True)
        self.pan_sync = QCheckBox('Sync pan'); self.pan_sync.setChecked(True)
        tb2.addWidget(self.zoom_sync); tb2.addWidget(self.pan_sync)
        tb2.addSeparator()
        tb2.addWidget(QLabel(' Color mode '))
        self.mode = QComboBox()
        self.mode.addItems([m.value for m in DisplayMode])
        self.mode.currentIndexChanged.connect(self.color_mode_changed)
        tb2.addWidget(self.mode)
        tb2.addWidget(QLabel(' Range '))
        self.range_override = QComboBox()
        self.range_override.addItems(['auto','limited','full'])
        tb2.addWidget(self.range_override)
        tb2.addWidget(QLabel(' Matrix '))
        self.matrix_override = QComboBox()
        self.matrix_override.addItems(['auto','bt709','smpte170m','bt470bg','bt2020nc'])
        tb2.addWidget(self.matrix_override)
        self._toolbar_action(tb2,'Apply diagnostic override',self.apply_diagnostics)

        transport = QWidget()
        transport_box = QHBoxLayout(transport)
        transport_box.setContentsMargins(10, 2, 10, 3)
        self.begin_btn = QPushButton('⏮'); self.begin_btn.clicked.connect(lambda: self.seek_all(0))
        self.end_btn = QPushButton('⏭'); self.end_btn.clicked.connect(lambda: self.seek_all(self._timeline_max))
        transport_box.addWidget(self.begin_btn)
        self.timeline = QSlider(Qt.Orientation.Horizontal)
        self.timeline.setRange(0,10000)
        self.timeline.sliderPressed.connect(lambda: setattr(self,'_scrubbing',True))
        self.timeline.sliderReleased.connect(self.slider_released)
        transport_box.addWidget(self.timeline, 1)
        transport_box.addWidget(self.end_btn)
        self.time_label = QLabel('00:00.000 / 00:00.000')
        self.time_label.setMinimumWidth(175)
        transport_box.addWidget(self.time_label)
        dock_transport = QDockWidget('', self)
        dock_transport.setFeatures(QDockWidget.DockWidgetFeature.NoDockWidgetFeatures)
        dock_transport.setTitleBarWidget(QWidget())
        dock_transport.setWidget(transport)
        self.addDockWidget(Qt.DockWidgetArea.BottomDockWidgetArea, dock_transport)

        self.diagnostics = QPlainTextEdit()
        self.diagnostics.setReadOnly(True)
        self.diagnostics.setLineWrapMode(QPlainTextEdit.LineWrapMode.NoWrap)
        self.diagnostics.setPlaceholderText('Select a pane to see declared metadata and observed renderer properties')
        self.diagnostics_dock = QDockWidget('Metadata and color pipeline',self)
        self.diagnostics_dock.setWidget(self.diagnostics)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.diagnostics_dock)
        self.diagnostics_dock.resize(350,650)
        self.statusBar().showMessage('Direct RGB is a requested policy; pixel-perfect FastStone matching must be measured on Windows.')
        self.color_mode_changed()
        self.setStyleSheet('''
            QMainWindow { background: #14171d; color: #e9edf3; }
            QFrame#pane { background: #202630; border: 1px solid #3b434d; border-radius: 5px; }
            QFrame#videoHost { background: #08090b; border: none; }
            QLabel { color: #e6e9ed; }
            QToolBar { background: #212631; spacing: 7px; border-bottom:1px solid #404550; }
            QToolButton, QPushButton { padding: 4px 7px; }
            QPlainTextEdit { background: #16191e; color:#d2dee9; font-family: Consolas; font-size: 11px; }
            QDockWidget { color: #e2ebef; }
        ''')

    def _toolbar_action(self, toolbar, title, cb, shortcut=None):
        action = QAction(title,self)
        if shortcut:
            action.setShortcut(QKeySequence(shortcut))
            action.setShortcutContext(Qt.ShortcutContext.ApplicationShortcut)
        action.triggered.connect(cb)
        toolbar.addAction(action)
        return action

    def _connect_panes(self):
        for pane in self.panes:
            pane.openRequested.connect(self.open_one)
            pane.removeRequested.connect(self.remove_one)
            pane.selected.connect(self.select_pane)
            pane.moveRequested.connect(self.move_pane)
            pane.filesDropped.connect(self.load_paths)
            pane.zoomBy.connect(self.pane_zoom)
            pane.panBy.connect(self.pane_pan)
            pane.offsetChanged.connect(lambda idx, off: self._sync_pause_positions() if self.clock.paused else None)

    def _layout_panes(self):
        while self.grid.count():
            self.grid.takeAt(0)
        for idx, pane in enumerate(self.panes):
            pane.setVisible(idx < self.visible_count)
            if idx >= self.visible_count:
                continue
            if self.visible_count == 1:
                r,c = 0,0
            elif self.visible_count == 2:
                r,c = 0,idx
            elif self.visible_count == 3:
                r,c = 0,idx
            else:
                r,c = divmod(idx,2)
            self.grid.addWidget(pane, r, c)
        self.grid.setRowStretch(0,1); self.grid.setRowStretch(1,1)
        for i in range(4):
            self.grid.setColumnStretch(i,1)

    def change_count(self, idx):
        self.visible_count = idx+1
        self._layout_panes()
        self._choose_master()
        self.select_pane(min(self.selected_index,self.visible_count-1))

    def select_pane(self, index):
        self.selected_index = index
        for i, pane in enumerate(self.panes):
            pane.setStyleSheet('QFrame#pane { border: 2px solid #64afd0; }' if i == index else '')
        self.refresh_diagnostics()

    def _choose_master(self):
        loaded = [i for i,p in enumerate(self.panes[:self.visible_count]) if p.player is not None]
        if self.master_index not in loaded:
            self.master_index = loaded[0] if loaded else None
        self._timeline_max = max((p.metadata.duration for p in self.panes[:self.visible_count]
                                  if p.metadata), default=0.0)

    def open_one(self, idx):
        path, _ = QFileDialog.getOpenFileName(self,'Open video', '',
                    'Video files (*.mp4 *.mkv *.mov *.avi *.webm *.m4v *.ts *.mxf);;All files (*)')
        if path:
            self.load_paths(idx,[path])

    def open_multiple(self):
        paths,_ = QFileDialog.getOpenFileNames(self,'Open one to four videos','',
                    'Video files (*.mp4 *.mkv *.mov *.avi *.webm *.m4v *.ts *.mxf);;All files (*)')
        if paths:
            self.visible_count = min(4, max(self.visible_count,len(paths)))
            self.layout_combo.setCurrentIndex(self.visible_count-1)
            self.load_paths(0,paths[:4])

    def load_paths(self, start, paths):
        for idx, path in enumerate(paths,start):
            if idx >= 4:
                break
            if idx >= self.visible_count:
                self.layout_combo.setCurrentIndex(idx)
            self._start_probe(idx,path)

    def _start_probe(self, idx, path):
        pane = self.panes[idx]
        pane.clear()
        pane.token += 1
        token = pane.token
        pane.name.setText(f'{Path(path).name} (probing…)')
        pane.status.setText('Reading metadata off UI thread')
        self._loading.add(idx)
        self.pool.start(ProbeTask(idx,token,path,self._probe_signals))
        self._choose_master()

    def _on_probe_error(self, idx, token, error):
        pane = self.panes[idx]
        if token != pane.token: return
        self._loading.discard(idx)
        pane.status.setText('Cannot open: see error')
        QMessageBox.warning(self,'Media probe error',error)
        self._choose_master()

    def _on_probe(self, idx, token, data: VideoMetadata):
        pane = self.panes[idx]
        if pane.token != token: return
        self._loading.discard(idx)
        pane.metadata, pane.path = data, data.path
        pane.name.setText(f'{idx+1} · {Path(data.path).name}')
        pane.name.setToolTip(data.path)
        eligible, warning = data.eligibility
        if not eligible:
            pane.status.setText('Blocked: HDR / wide-gamut path not validated')
            pane.placeholder.setText(warning)
            QMessageBox.warning(self,'Direct RGB source not supported',warning)
            self.refresh_diagnostics()
            return
        try:
            player = MpvPanePlayer(int(pane.host.winId()))
            pane.player = player  # Ensure failed initialization is always cleaned up.
            player.load(data.path)
            pane.loaded_at = monotonic()
            pane.placeholder.hide()
            missing = [k for k,v in [('matrix',data.matrix),('range',data.range)] if v == 'Unspecified']
            pane.status.setText(('Unspecified '+ '/'.join(missing) + ' — inspect effective decode') if missing
                                else 'Loaded · SDR policy · awaiting decode')
            player.pause(self.clock.paused)
            player.set('speed',str(self.clock.speed))
            if self.mode.currentIndex() == 1:
                player.apply_overrides(Overrides(self.range_override.currentText(),
                                                 self.matrix_override.currentText()))
            self._apply_view_to_player(player)
            if self.master_index is not None and self.master_index != idx:
                master = self.panes[self.master_index].player
                if master:
                    t = master.get_double('time-pos') or 0
                    player.seek(Clock.local_time(t,pane.offset))
            self._choose_master()
            self.select_pane(idx)
        except Exception as exc:
            pane.status.setText('Renderer failed: see error')
            if pane.player:
                pane.player.close(); pane.player = None
            QMessageBox.critical(self, 'libmpv renderer error',
                 f'{exc}\n\nThe requested GPU settings were NOT applied. No fallback was silently selected.')

    def _loaded(self):
        return [(i,p) for i,p in enumerate(self.panes[:self.visible_count]) if p.player]

    def remove_one(self, idx):
        self.panes[idx].clear()
        self._choose_master()
        self.refresh_diagnostics()

    def move_pane(self, idx, direction):
        j = idx+direction
        if j < 0 or j >= self.visible_count:
            return
        if idx in self._loading or j in self._loading:
            self.statusBar().showMessage('Finish metadata loading before rearranging panes.')
            return
        self.panes[idx], self.panes[j] = self.panes[j], self.panes[idx]
        # Native video child HWND remains owned by original QWidget, not detached.
        for i,p in enumerate(self.panes): p.index = i
        if self.master_index == idx: self.master_index = j
        elif self.master_index == j: self.master_index = idx
        self._layout_panes()
        self.select_pane(j)

    def toggle_play(self):
        if not self._loaded(): return
        self.clock.paused = not self.clock.paused
        for _,pane in self._loaded(): pane.player.pause(self.clock.paused)
        if self.clock.paused:
            self._sync_pause_positions()

    def _sync_pause_positions(self):
        if self.master_index is None: return
        master = self.panes[self.master_index].player
        if not master: return
        t = master.get_double('video-pts')
        if t is None: t = master.get_double('time-pos') or 0
        for idx,pane in self._loaded():
            if idx == self.master_index: continue
            pane.player.seek(Clock.local_time(t,pane.offset))

    def stop_all(self):
        self.clock.paused = True
        for _,pane in self._loaded(): pane.player.pause(True)
        self.seek_all(0)

    def seek_all(self, t):
        self.clock.master_position = max(0.0,t)
        for idx,pane in self._loaded():
            local = self.clock.master_position if idx == self.master_index else Clock.local_time(
                self.clock.master_position,pane.offset)
            pane.player.seek(local)
        self.time_label.setText(f'{self.format_time(t)} / {self.format_time(self._timeline_max)}')

    def slider_released(self):
        self._scrubbing = False
        self.seek_all(self.timeline.value()/10000.0*self._timeline_max)

    def step(self, direction):
        self.clock.paused = True
        for _, pane in self._loaded(): pane.player.pause(True)
        if self.master_index is None: return
        master = self.panes[self.master_index].player
        if not master: return
        before = master.get_double('video-pts')
        if before is None: before = master.get_double('time-pos')
        master.command('frame-step' if direction > 0 else 'frame-back-step')
        self._step_await = (before,monotonic())

    def change_speed(self, speed):
        self.clock.speed = float(speed.replace('×',''))
        for _,p in self._loaded(): p.player.set('speed',self.clock.speed)

    def _tick(self):
        for idx,pane in self._loaded():
            for event in pane.player.drain_events():
                if event['error'] < 0:
                    pane.status.setText('Decoder/render command failed: ' + event['message'])
                elif event['event'] == 8:
                    pane.status.setText('Decoded file loaded · check GPU output in diagnostics')
            if (pane.loaded_at and monotonic()-pane.loaded_at>4 and pane.isVisible()
                    and pane.player.get_bool('vo-configured') is False):
                pane.status.setText('Renderer not configured — inspect GPU/runtime diagnostics')
        if self.master_index is None: return
        master = self.panes[self.master_index].player
        if master is None: return
        pts = master.get_double('video-pts')
        pos = master.get_double('time-pos')
        step_position = pts if pts is not None else pos
        if pos is None and pts is None: return
        t = pos if pos is not None else pts
        self.clock.master_position = t
        if not self._scrubbing and self._timeline_max:
            self.timeline.setValue(int(min(1,max(0,t/self._timeline_max))*10000))
        self.time_label.setText(f'{self.format_time(t)} / {self.format_time(self._timeline_max)}')
        if self._step_await is not None:
            before, started = self._step_await
            if step_position is not None and (before is None or abs(step_position-before)>0.00001):
                self._step_await = None
                self._sync_pause_positions()
            elif monotonic()-started > 1.5:
                self._step_await = None
                self.statusBar().showMessage('Frame step timeout: decoder did not present a new PTS; check video.')
        if not self.clock.paused:
            if self.clock.loop and self._timeline_max and t >= self._timeline_max-0.03:
                self.seek_all(0)
            errors = []
            for idx,p in self._loaded():
                if idx == self.master_index: continue
                target = Clock.local_time(t,p.offset)
                actual = p.player.get_double('video-pts')
                if actual is None: actual=p.player.get_double('time-pos')
                error = Clock.error_ms(actual,target)
                if error is not None:
                    errors.append(f'{idx+1}: {error:+.0f}ms')
                    if target<0 or (p.metadata and p.metadata.duration>0 and target>p.metadata.duration):
                        p.status.setText('Target timestamp outside this video')
                        continue
                    if abs(error)/1000.0 > Clock.tolerance_seconds(p.metadata.fps if p.metadata else 0):
                        # Coarse closed-loop seeking: accurate pause and drift alarms
                        # rather than a claim of hard realtime multi-decoder sync.
                        now = monotonic()
                        if now - self._last_sync_seek.get(idx, 0) >= 0.6:
                            p.player.seek(target)
                            self._last_sync_seek[idx] = now
            self.statusBar().showMessage('Live relative video-PTS offsets: ' +
                (', '.join(errors) if errors else 'unavailable'))
        if int(monotonic()*2) != int((monotonic()-.15)*2):
            self.refresh_diagnostics()

    @staticmethod
    def format_time(seconds):
        s = max(0.0,float(seconds or 0)); m,sec = divmod(s,60)
        return f'{int(m):02d}:{sec:06.3f}'

    def apply_zoom_mode(self, *_):
        for _,pane in self._view_targets(): self._apply_view_to_player(pane.player)

    def _apply_view_to_player(self, player):
        if not player: return
        idx = self.zoom_combo.currentIndex()
        player.set('video-unscaled','no' if idx == 0 else 'yes')
        player.set('video-zoom', '1' if idx == 2 else '0')
        player.set('video-pan-x', 0)
        player.set('video-pan-y', 0)

    def _view_targets(self):
        if self.zoom_sync.isChecked(): return self._loaded()
        pane = self.panes[self.selected_index]
        return [(self.selected_index,pane)] if pane.player else []

    def _pan_targets(self):
        if self.pan_sync.isChecked(): return self._loaded()
        pane = self.panes[self.selected_index]
        return [(self.selected_index,pane)] if pane.player else []

    def zoom_by(self, delta):
        for _,pane in self._view_targets():
            value = pane.player.get_double('video-zoom') or 0
            pane.player.set('video-zoom',max(-5,min(5,value+delta)))

    def pane_zoom(self, index, delta):
        self.select_pane(index)
        self.zoom_by(delta)

    def pane_pan(self,index,dx,dy):
        self.select_pane(index)
        self.pan_by(dx,dy)

    def pan_by(self,dx,dy):
        for _,pane in self._pan_targets():
            for axis,d in [('x',dx),('y',dy)]:
                key='video-pan-'+axis
                cur = pane.player.get_double(key) or 0
                pane.player.set(key, max(-3,min(3,cur+d)))

    def reset_view(self):
        self.zoom_combo.setCurrentIndex(0)
        for _,p in self._loaded(): self._apply_view_to_player(p.player)

    def color_mode_changed(self, *_):
        diag = self.mode.currentIndex() == 1
        self.range_override.setEnabled(diag)
        self.matrix_override.setEnabled(diag)
        if not diag:
            self.range_override.setCurrentIndex(0)
            self.matrix_override.setCurrentIndex(0)
            for _,pane in self._loaded():
                try: pane.player.apply_overrides(Overrides())
                except MpvError as exc: self.statusBar().showMessage(f'Filter removal failed: {exc}')
        self.refresh_diagnostics()

    def apply_diagnostics(self):
        if self.mode.currentIndex() != 1:
            QMessageBox.information(self,'Direct mode', 'Select Diagnostic RGB to permit overrides.')
            return
        o = Overrides(self.range_override.currentText(), self.matrix_override.currentText())
        errors = []
        for idx,pane in self._loaded():
            try: pane.player.apply_overrides(o)
            except MpvError as e: errors.append(f'Pane {idx+1}: {e}')
        if errors: QMessageBox.warning(self,'Overrides not applied','\n'.join(errors))
        self.refresh_diagnostics()

    def refresh_diagnostics(self):
        if not hasattr(self, 'diagnostics'): return
        pane = self.panes[self.selected_index]
        details = {'selected_pane':self.selected_index+1, 'display_mode': self.mode.currentText(),
                   'ICC_applied_by_application':'No ICC profile requested',
                   'compositor':'Unverified; Windows Advanced Color/DWM can transform output',
                   'output_contract':'Unmanaged SDR RGB requested, NOT proven byte identical',
                   'video_info': pane.metadata.to_dict() if pane.metadata else 'No video',
                   'diagnostic_overrides': {'range':self.range_override.currentText(),
                                            'matrix':self.matrix_override.currentText()},
                   'runtime_renderer': pane.player.runtime_diagnostics() if pane.player else 'Not initialized'}
        # Avoid aggressive updates while user is selecting/copying diagnostic text.
        if not self.diagnostics.hasFocus():
            self.diagnostics.setPlainText(json.dumps(details,indent=2,ensure_ascii=False))

    def save_screenshot(self):
        pane = self.panes[self.selected_index]
        if not pane.player:
            QMessageBox.information(self,'No video','Load and select a video first.')
            return
        fname,_ = QFileDialog.getSaveFileName(self,'Save renderer screenshot',
                              str(Path.home()/'DirectRGB_renderer.png'),'PNG image (*.png)')
        if fname:
            try:
                pane.player.command('screenshot-to-file',fname,'window')
                self.statusBar().showMessage('Screenshot requested; verify file completion. May include GPU/VO transforms.')
            except MpvError as exc:
                QMessageBox.warning(self,'Screenshot error',str(exc))

    def fullscreen_toggle(self):
        if self.isFullScreen():
            self.showNormal(); self.diagnostics_dock.show()
        else:
            self.diagnostics_dock.hide(); self.showFullScreen()

    def dragEnterEvent(self, event):
        if event.mimeData().hasUrls(): event.acceptProposedAction()

    def dropEvent(self, event):
        paths = [x.toLocalFile() for x in event.mimeData().urls() if x.isLocalFile()]
        if paths:
            self.load_paths(0,paths[:4]); event.acceptProposedAction()

    def closeEvent(self, event):
        self.timer.stop()
        for pane in self.panes:
            if pane.player: pane.player.close(); pane.player = None
        super().closeEvent(event)


def run():
    if sys.platform != 'win32':
        # Qt UI may run for development on Linux; renderer explicitly requires Windows.
        print('Note: D3D11 native render only available on Windows.',file=sys.stderr)
    app = QApplication(sys.argv)
    app.setApplicationName('DirectRGB Compare')
    if sys.platform == 'win32':
        from .paths import missing_runtime_files
        missing = missing_runtime_files()
        if missing:
            QMessageBox.critical(None, 'Missing packaged runtimes',
                'Missing: ' + ', '.join(missing) + '\n\nRun RUN_FIRST.bat from the project folder. '
                'It will download the required FFmpeg / libmpv files and build a portable EXE. '
                'No manual DLL copying is necessary.')
            return 2
    win = MainWindow()
    win.show()
    return app.exec()
