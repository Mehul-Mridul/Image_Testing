"""Qt file browser with async filesystem model, extension/name filtering, multiselect."""
from __future__ import annotations
from pathlib import Path

from PySide6.QtCore import Qt, QSortFilterProxyModel, QModelIndex, Signal, QDir
from PySide6.QtWidgets import (QWidget,QVBoxLayout,QHBoxLayout,QTreeView,QLineEdit,
    QToolButton,QComboBox,QLabel,QAbstractItemView,QFileSystemModel,QCheckBox)
from .media_catalog import is_video


class MediaFilter(QSortFilterProxyModel):
    def __init__(self,parent=None):
        super().__init__(parent)
        self.query=''
        self.setDynamicSortFilter(True)

    def filterAcceptsRow(self,row,parent):
        source=self.sourceModel()
        idx=source.index(row,0,parent)
        if source.isDir(idx):return True
        name=source.fileName(idx)
        return is_video(name) and self.query.casefold() in name.casefold()

    def set_query(self,query):
        self.query=query.strip()
        self.invalidateFilter()


class FileBrowser(QWidget):
    folderChanged=Signal(str)
    fileActivated=Signal(str)
    multiLoadRequested=Signal(object)
    folderDropped=Signal(str)
    recursiveChanged=Signal(bool)

    def __init__(self,parent=None):
        super().__init__(parent)
        self.history=[]
        self._folder=''
        layout=QVBoxLayout(self);layout.setContentsMargins(5,5,5,5)
        row=QHBoxLayout()
        self.back=QToolButton();self.back.setText('←');self.back.setToolTip('Previous folder')
        self.back.clicked.connect(self.go_back)
        row.addWidget(self.back)
        self.path_edit=QLineEdit();self.path_edit.setPlaceholderText('Folder path')
        self.path_edit.returnPressed.connect(lambda:self.set_folder(self.path_edit.text()))
        row.addWidget(self.path_edit,1)
        layout.addLayout(row)
        self.crumbs=QWidget(self)
        self.crumb_layout=QHBoxLayout(self.crumbs)
        self.crumb_layout.setContentsMargins(0,0,0,0)
        self.crumb_layout.setSpacing(2)
        layout.addWidget(self.crumbs)
        self.search=QLineEdit();self.search.setPlaceholderText('Filter video filenames…')
        layout.addWidget(self.search)
        row=QHBoxLayout()
        self.sort_box=QComboBox();self.sort_box.addItems(['Name','Date','Size','Type'])
        self.sort_box.currentIndexChanged.connect(self._sort_changed)
        row.addWidget(self.sort_box)
        self.recursive=QCheckBox('Include subfolders')
        self.recursive.toggled.connect(self.recursiveChanged.emit)
        row.addWidget(self.recursive)
        layout.addLayout(row)
        self.model=QFileSystemModel(self)
        self.model.setRootPath(QDir.rootPath())
        self.model.setFilter(QDir.Filter.AllDirs | QDir.Filter.Files | QDir.Filter.NoDotAndDotDot)
        self.proxy=MediaFilter(self);self.proxy.setSourceModel(self.model)
        self.search.textChanged.connect(self.proxy.set_query)
        self.tree=QTreeView()
        self.tree.setModel(self.proxy)
        self.tree.setSelectionMode(QAbstractItemView.SelectionMode.ExtendedSelection)
        self.tree.setDragEnabled(True)
        self.tree.setUniformRowHeights(True)
        self.tree.setSortingEnabled(True)
        self.tree.sortByColumn(0,Qt.SortOrder.AscendingOrder)
        self.tree.doubleClicked.connect(self._activate)
        self.tree.setColumnWidth(0,200)
        layout.addWidget(self.tree,1)
        row=QHBoxLayout()
        self.count=QLabel('Choose a folder')
        row.addWidget(self.count,1)
        self.load=QToolButton();self.load.setText('Load selected')
        self.load.clicked.connect(lambda:self.multiLoadRequested.emit(self.selected_files()))
        row.addWidget(self.load)
        layout.addLayout(row)
        self.tree.selectionModel().selectionChanged.connect(lambda *_:self._update_count())

    def _update_count(self):
        self.count.setText(f'{len(self.selected_files())} selected')

    def _sort_changed(self,idx):
        col=[0,3,1,2][idx]
        self.tree.sortByColumn(col,Qt.SortOrder.DescendingOrder if idx in (1,2) else Qt.SortOrder.AscendingOrder)

    def selected_files(self):
        paths=[]
        for idx in self.tree.selectionModel().selectedRows(0):
            source_index=self.proxy.mapToSource(idx)
            path=self.model.filePath(source_index)
            if Path(path).is_file() and is_video(path): paths.append(str(Path(path).resolve()))
        return paths

    def _activate(self,idx):
        source_index=self.proxy.mapToSource(idx)
        path=self.model.filePath(source_index)
        if self.model.isDir(source_index):self.set_folder(path)
        elif is_video(path):self.fileActivated.emit(path)

    @property
    def folder(self):return self._folder

    def set_folder(self,folder,save_history=True):
        root=Path(folder).expanduser()
        if not root.is_dir():
            self.count.setText('Folder unavailable')
            return False
        target=str(root.resolve())
        if save_history and self._folder and self._folder!=target:self.history.append(self._folder)
        self._folder=target
        self.path_edit.setText(target)
        self._update_breadcrumbs(target)
        index=self.model.index(target)
        self.tree.setRootIndex(self.proxy.mapFromSource(index))
        self.back.setEnabled(bool(self.history))
        self.folderChanged.emit(target)
        return True

    def _update_breadcrumbs(self,folder):
        while self.crumb_layout.count():
            item=self.crumb_layout.takeAt(0)
            if item.widget():item.widget().deleteLater()
        path=Path(folder)
        # Show a concise navigable trail; the address field always contains
        # the full path including UNC shares and drive names.
        chain=[path,*list(path.parents)]
        chain=list(reversed(chain))[-5:]
        for part in chain:
            button=QToolButton(self.crumbs)
            button.setText(part.name or str(part))
            button.setToolTip(str(part))
            button.clicked.connect(lambda _=False,where=str(part):self.set_folder(where))
            self.crumb_layout.addWidget(button)
        self.crumb_layout.addStretch(1)

    def go_back(self):
        if self.history:
            self.set_folder(self.history.pop(),save_history=False)

