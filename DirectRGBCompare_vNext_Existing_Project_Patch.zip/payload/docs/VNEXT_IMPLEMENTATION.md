# DirectRGB Compare vNext — Actual implementation handoff

## Scope completed in source

Six requested categories are implemented on top of the prior v5 source without
editing the decoder, render policy, numerical RGB fixture tools or native libmpv binding.

1. **Folder browser**: `directrgb/file_browser.py` implements a Qt QFileSystemModel
   browser with breadcrumb path buttons, back, search, sortable columns, multiselection,
   optional recursive catalogue, last folder persistence. `media_catalog.py` handles
   background catalogue scanning without decoding or probing the whole folder.
2. **Drag/drop and multi-selection**: root, pane and native-host drop handlers;
   selected videos fill empty pane slots first, replacements ask for confirmation;
   >4 files offer sets / first four / cancel. `pane_load.py` uses per-pane
   generation tokens; failed probe preserves previous video.
3. **Next/previous comparison sets**: sequential grouping with preview respects
   current catalogue sort; pattern grouping previews configured ordered filename
   variants and retains missing slots, never silently shifts assignments. Next/Prev
   shortcuts Ctrl+PgDown/Ctrl+PgUp; group changes close old videos *before*
   attempting to load the next set, preventing comparison across different sets.
4. **Configurable shortcuts**: `commands.py` centralized QAction registry, collision
   checks and settings persistence. F1 shortcut editor. Application-level shortcut
   override filter protects Qt text-entry and spin boxes. Embedded HWND focus still
   requires actual Windows verification.
5. **Cursor-centred zoom + synchronized pan**: `view_geometry.py` computes Qt-logical
   viewport transforms considering DPR, sample aspect, 90-degree rotation and
   letterboxing. `view_sync.py` tracks normalized crop centres and synchronized
   zoom factor. mpv adapter uses documented `video-pan` and log2 `video-zoom`
   properties; source color processing has not been changed. Physical-pixel
   accuracy and native-child mouse input still require Windows validation.
6. **Click-to-synchronize**: Individual pane `Go…`, previous/next frame and `Master`
   controls allow manual event positioning; `Sync Here` calculates offsets from
   exposed actual-frame PTS *when available*. Some libmpv builds may not expose a
   usable `video-pts`. In that case the UI **explicitly asks** before using
   `time-pos` as provisional playback-position data, labels this as *not verified*
   frame PTS and includes that provenance in diagnostics. No silent timebase guess.

Added: `app_settings.py` versioned atomic settings, `diagnostic_events.py` bounded
structured events and redaction by default, Export diagnostics toolbar action,
`tools/vnext_gui_smoke.py` separate native Qt shell check.

## Explicitly unchanged color path

SHA256 inherited from the archived v5 baseline:

```
directrgb/policy.py       aa373c95266e5c45daadd11be620d60be9acda5931ef2eda71c4706825d89c5e
directrgb/mpv_native.py   4d2cbe47de440178d38550798fc07ab2a02f000774fdff8c7dee24e8649c8424
directrgb/validation.py   b39cc37f1ea8e0a5a9067ac6a1551365a4b56cd923ea71f367a7c7d3e5ffd5da
directrgb/color_math.py   ed0904edc1c1989a879e88a450790cf020e71a4d39ddd5c853699166bbc18a3c
```

**Unchanged source does not prove previously unverified FastStone equivalence.**
Zooming and scaling the displayed content can change pixels; compare color in
validated native-pixel mode only. The new user-interface features do not insert
creative color transformations or additional CPU frame conversion.

## Smoke tests on Windows

1. Install/prepare dependencies with `RUN_FIRST.bat` from the extracted project.
2. Run `CHECK_VNEXT_GUI.bat`. This constructs the Qt app, shows browser and pane
   shell, verifies required commands. It does not play frames.
3. Run `CHECK_WINDOWS_GUI.bat`. This tests a real libmpv/D3D11 host and synthetic
   test video. It does not verify FastStone color matching.
4. Run the EXE from `dist\DirectRGBCompare\DirectRGBCompare.exe` and manually
   exercise all six workflows, all screen DPIs and HWND focus.
5. Run reference RGB numerical tests and original FastStone CMS-OFF visual plus
   numerical comparison, windowed vs fullscreen, same-video 2/3/4 pane checks.
6. Stress-test 1–4 4K portrait streams and record hardware and measured metrics.

### Windows user acceptance checklist

| Test | Expected | Current status |
|---|---|---|
| Open folder with 500+ video files | File browser responsive; no eager decoding | NOT TESTED on Windows |
| Ctrl/Shift multi-select and drag/drop | Correct pane assignment; confirmation for overwrite | NOT TESTED |
| Navigate sets rapidly | Old groups not displayed; stale probes discarded | Logic unit-tested; Windows NOT TESTED |
| Pattern grouping with missing variant | Empty slot, no shifted pane | Unit-tested; Windows NOT TESTED |
| Shortcut editor, editing focus and native HWND focus | No unexpected transport commands during text entry | Static + logic-tested; Windows NOT TESTED |
| Cursor zoom at rotated/portrait/letterboxed content | Selected anchor stable; expected crop alignment | Mathematical unit-tested; GPU output NOT TESTED |
| 100/125/150/200% display scale | One physical source display pixel = one real monitor pixel in native mode | NOT TESTED |
| Paused Sync Here | Offsets from actual PTS if present or provisional warning | Math-tested; actual properties NOT TESTED |
| RGB FFV1 + BT.709 fixtures | No unexplained differences vs independent reference | Reference tests pass; GPU NOT TESTED |
| FastStone CMS-OFF comparison | Numeric capture and manually checked appearance | NOT TESTED |
| Portable exe with 4K portrait streams | Stable frame presentation; bounded resource use | NOT TESTED |

### Known limitations to close before production sign-off

- Native libmpv HWND mouse/keyboard routing and Qt actions have not been tested
  on Windows. If native child intercepts wheel/drag, use existing toolbar and
  keyboard controls until Windows input forwarding is implemented.
- `time-pos` is an approximate source playback position, **not proof of actual
  presentation timestamp**. Use only after explicit approval in Sync Here.
  A frame-accurate implementation requires a native presentation feedback path
  tied to the actual renderer frame, not a guess from time-pos.
- Current view-to-mpv mapping is validated mathematically for Qt rectangles,
  not verified on physical monitor pixels. SAR/rotation and Win DPI must be
  tested against actual captured rendered output.
- An initialization failure after successful replacement probing may discard
  the previous pane's decoder: native HWND ownership needs a Windows-tested
  double-buffer/staged replacement architecture for full rollback guarantees.
- The original coarse 150-ms multi-decoder sync controller is not genlocked.
  Sync Here calculates offsets but does not change the underlying scheduler.
- HDR, untagged metadata anomalies and wide-gamut remain outside verified SDR
  rendering; the existing policy's source restrictions remain in place.
- Unchanged v5 bootstrap can still encounter network/runtime issues; CI is
  required to validate downloadable dependencies and packaging on Windows.

## Test reporting

Linux tests: `python -m pytest -q tests`. Unit tests validate file discovery,
grouping, load tokens, shortcut mapping, time math and geometry. Source compile:
`python -m compileall -q directrgb run.py`.

Do not describe the application as a Windows-certified finished version until
Windows Qt, D3D11, FastStone and 4K stress tests have been completed and recorded.
