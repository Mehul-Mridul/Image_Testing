DirectRGB Compare vNext source upgrade (2026-11-11)

Extract this complete patch ZIP. Double-click APPLY_VNEXT_SOURCE_PATCH.bat.
Enter the existing DirectRGBCompare project folder (contains RUN_FIRST.bat).
Type YES when the displayed target is correct.

The updater checks that the existing v5 Direct RGB policy hash matches the
archived v5 version, backs up every overwritten application source file,
installs new modules, and runs Python unit tests if your .venv exists.
On failed tests/copy checks, the updater rolls back changed source files.
It never modifies videos, ffmpeg/mpv DLLs or the compiled EXE.

After success, rebuild: build_windows.bat. Then test CHECK_VNEXT_GUI.bat
and CHECK_WINDOWS_GUI.bat; verify FastStone color numerically on Windows.

If the source policy hash has changed on your PC, this updater intentionally
REFUSES to merge automatically. Use the separate full vNext source ZIP and
review your current custom modifications before migrating.
