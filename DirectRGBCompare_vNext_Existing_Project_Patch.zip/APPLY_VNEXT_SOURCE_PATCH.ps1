param([string]$ProjectPath='')
$ErrorActionPreference='Stop'
$srcRoot=Join-Path (Split-Path -Parent $MyInvocation.MyCommand.Path) 'payload'
if (!(Test-Path -LiteralPath (Join-Path $srcRoot 'directrgb\vnext_gui.py') -PathType Leaf)) { throw 'Incomplete patch ZIP; extract all files.' }
if (!$ProjectPath) {
    $ProjectPath=Read-Host 'Enter the full path to your existing DirectRGBCompare project folder (the folder with RUN_FIRST.bat)'
}
$ProjectPath=$ProjectPath.Trim('"')
if (!(Test-Path -LiteralPath (Join-Path $ProjectPath 'RUN_FIRST.bat') -PathType Leaf)) { throw 'Project not found: expected RUN_FIRST.bat in the supplied directory' }
$project=(Resolve-Path -LiteralPath $ProjectPath).Path
$policy=Join-Path $project 'directrgb\policy.py'
if (!(Test-Path -LiteralPath $policy -PathType Leaf)) { throw 'Existing project is missing directrgb\policy.py' }
$expected='aa373c95266e5c45daadd11be620d60be9acda5931ef2eda71c4706825d89c5e'
$actual=(Get-FileHash -Algorithm SHA256 -LiteralPath $policy).Hash.ToLowerInvariant()
if ($actual -ne $expected) {
    throw "Existing RGB policy SHA256 differs from the archived v5 baseline. REFUSING to overwrite a potentially modified color pipeline. Your hash: $actual. Use a separate copy of the full vNext source instead."
}
$stamp=Get-Date -Format 'yyyyMMdd-HHmmss'
$backup=Join-Path $project ".vnext-backup\$stamp"
New-Item -ItemType Directory -Force -Path $backup | Out-Null
Write-Host "Target: $project"
Write-Host "Backup: $backup"
$answer=Read-Host 'Apply convenience-feature source patch to this project? (type YES)'
if ($answer -cne 'YES') { throw 'Patch cancelled; no application source modified.' }
$changed=New-Object 'System.Collections.Generic.List[object]'
try {
    $sources=Get-ChildItem -LiteralPath $srcRoot -Recurse -File
    foreach ($src in $sources) {
        $rel=$src.FullName.Substring($srcRoot.Length).TrimStart('\')
        $dst=Join-Path $project $rel
        $bak=Join-Path $backup $rel
        $exists=Test-Path -LiteralPath $dst -PathType Leaf
        if ($exists) {
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $bak) | Out-Null
            Copy-Item -LiteralPath $dst -Destination $bak -Force
        }
        $changed.Add([pscustomobject]@{Dest=$dst;Backup=$bak;WasExisting=$exists})
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dst) | Out-Null
        Copy-Item -LiteralPath $src.FullName -Destination $dst -Force
        $a=(Get-FileHash -Algorithm SHA256 -LiteralPath $src.FullName).Hash
        $b=(Get-FileHash -Algorithm SHA256 -LiteralPath $dst).Hash
        if ($a -ne $b) { throw "Copy verification failed: $rel" }
    }
    $python=Join-Path $project '.venv\Scripts\python.exe'
    if (Test-Path -LiteralPath $python -PathType Leaf) {
        Push-Location $project
        try {
            & $python -m pytest -q tests
            if ($LASTEXITCODE -ne 0) { throw 'Post-install regression tests failed. Restoring previous sources.' }
            & $python -m compileall -q directrgb run.py
            if ($LASTEXITCODE -ne 0) { throw 'Post-install Python compile failed. Restoring previous sources.' }
        } finally { Pop-Location }
    } else {
        Write-Warning 'No .venv found. Source patched but tests must run after RUN_FIRST.bat provisions Python.'
    }
    Write-Host 'SUCCESS: vNext source modules installed and copied files verified.' -ForegroundColor Green
    Write-Host 'Your existing EXE has NOT been replaced. Run build_windows.bat to build a new EXE, then CHECK_VNEXT_GUI.bat and CHECK_WINDOWS_GUI.bat.'
} catch {
    Write-Warning "PATCH FAILURE: $($_.Exception.Message). Restoring old source files."
    foreach ($entry in $changed) {
        if ($entry.WasExisting) {
            Copy-Item -LiteralPath $entry.Backup -Destination $entry.Dest -Force
        } elseif (Test-Path -LiteralPath $entry.Dest) {
            Remove-Item -LiteralPath $entry.Dest -Force
        }
    }
    throw
}
