@echo off
setlocal
cd /d "%~dp0"
echo DirectRGB Compare vNext - guarded source upgrade
echo Existing EXE will not be changed until you explicitly rebuild it.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY_VNEXT_SOURCE_PATCH.ps1"
if errorlevel 1 (
 echo Source upgrade did not complete. Review the error above.
 pause
 exit /b 1
)
pause
