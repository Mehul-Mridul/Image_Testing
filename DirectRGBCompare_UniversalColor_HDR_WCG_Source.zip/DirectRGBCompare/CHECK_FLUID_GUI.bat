@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
 echo Missing .venv\Scripts\python.exe. Run RUN_FIRST.bat to provision Windows dependencies.
 pause
 exit /b 2
)
echo Validating Qt fluid UI interactions (not native color accuracy)...
".venv\Scripts\python.exe" tools\fluid_gui_smoke.py
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
 echo FLUID Qt UI TEST FAILED. Preserve the traceback and docs report.
) else (
 echo Qt chrome smoke passed. Native 4K playback, DPI, HWND and RGB still require qualification.
)
pause
exit /b %RESULT%
