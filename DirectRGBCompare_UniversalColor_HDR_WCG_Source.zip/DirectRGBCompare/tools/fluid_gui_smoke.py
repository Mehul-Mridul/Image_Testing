"""Actual Qt-shell validation on Windows. NOT GPU RGB or playback certification.

Usage: .venv\\Scripts\\python.exe tools\\fluid_gui_smoke.py
Runs with isolated app settings and saves its report under docs/.
"""
from __future__ import annotations
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PySide6.QtCore import Qt,QPoint
from PySide6.QtTest import QTest
from PySide6.QtWidgets import QApplication
from directrgb.vnext_gui import MainWindow
from directrgb.motion import Spring
from directrgb.fluid_interactions import FluidButton,ActivePaneStrip
from directrgb.timeline_controller import ClipRange


def run():
    report={'suite':'Fluid Qt UI smoke','platform':sys.platform,'status':'RUNNING',
            'gpu_color_validation':'NOT VERIFIED',
            'actual_decode_and_frame_pacing':'NOT VERIFIED',
            'faststone_cms_off_parity':'NOT VERIFIED'}
    with tempfile.TemporaryDirectory(prefix='directrgb-fluid-') as td:
        original=os.environ.get('LOCALAPPDATA')
        os.environ['LOCALAPPDATA']=td
        app=QApplication.instance() or QApplication([])
        try:
            win=MainWindow()
            win.show();QTest.qWait(90)
            assert win.motion is not None
            assert isinstance(win.premium_play_button,FluidButton)
            assert all(isinstance(p.active_strip,ActivePaneStrip) for p in win.panes)
            assert win.browser_dock.isVisible(), 'Folder browser should start visible in a fresh profile'
            report['fresh_browser_present']=True
            # Opening/closing inside a transition must end at the last request.
            win._toggle_browser();QTest.qWait(22)
            win._toggle_browser();QTest.qWait(230)
            assert win.browser_dock.isVisible()
            report['reversible_browser_transition']=True
            # Test dock close button and ordinary toggles separately.
            win._toggle_diagnostics();QTest.qWait(20)
            win._toggle_diagnostics();QTest.qWait(240)
            assert not win.diagnostics_dock.isVisible()
            report['reversible_diagnostics_transition']=True
            # Press-feedback code is exercised by real Qt test input.
            btn=win.premium_play_button
            QTest.mousePress(btn,Qt.MouseButton.LeftButton)
            assert btn._emphasis >= .99
            QTest.mouseRelease(btn,Qt.MouseButton.LeftButton)
            QTest.qWait(160)
            report['immediate_press_feedback']=True
            # UI-only scrub with synthetic duration values, no media loaded.
            win.comparison_timeline.configure({0:ClipRange(2),1:ClipRange(8)})
            win._timeline_max=8.
            win._update_timeline_marks()
            win._update_timeline_display()
            slider=win.timeline
            start=QPoint(round(slider.width()*.65),round(slider.height()/2))
            QTest.mousePress(slider,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier,start)
            assert win._scrubbing
            assert 0<=slider.value()<=10000
            QTest.mouseRelease(slider,Qt.MouseButton.LeftButton,Qt.KeyboardModifier.NoModifier,start)
            assert not win._scrubbing
            report['precise_scrub_events']=True
            # Focus indicators must update without any video host reparenting.
            win.select_pane(1)
            QTest.qWait(140)
            assert win.panes[1].active_strip._active > .6
            report['active_pane_selection_transition']=True
            win.set_reduced_motion(True)
            assert win.motion.reduced_motion
            win.select_pane(0)
            assert win.panes[0].active_strip._active==1.
            report['reduced_motion']=True
            for count in (1,2,3,4,2):
                win.layout_combo.setCurrentIndex(count-1)
                QTest.qWait(80)
                assert win.visible_count==count
            report['layout_counts']=[1,2,3,4,2]
            win.restore_browser_workspace()
            assert win.browser_dock.isVisible()
            report['browser_recovery']=True
            win.close();QTest.qWait(50)
            report['status']='PASS (Qt chrome only)'
        finally:
            if original is None:os.environ.pop('LOCALAPPDATA',None)
            else:os.environ['LOCALAPPDATA']=original
    destination=ROOT/'docs'/'FLUID_QT_SMOKE_RESULTS.json'
    destination.write_text(json.dumps(report,indent=2),encoding='utf8')
    print(json.dumps(report,indent=2))
    return 0

if __name__=='__main__':raise SystemExit(run())
