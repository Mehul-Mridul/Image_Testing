"""Windows-only live UI + decoder profile smoke, NOT color certification.

Run after RUN_FIRST.bat or after a successful build. Produces a report recording
actual libmpv option acceptance and whether a decoded frame was reported.
No claim of actual HDR swapchain format, monitor output or FastStone parity.
"""
from __future__ import annotations
import argparse
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main(argv=None):
    args=argparse.ArgumentParser()
    args.add_argument('--fixture',default=str(ROOT/'assets'/'synthetic_hdr10_metadata_ffv1.mkv'))
    ns=args.parse_args(argv)
    report={'suite':'Universal Color Windows Qt/runtime smoke',
            'platform':sys.platform,'fixture':Path(ns.fixture).name,
            'status':'NOT TESTED', 'native_hdr_fidelity':'NOT VERIFIED',
            'gpu_swapchain_readback':'NOT IMPLEMENTED',
            'physical_display_calibration':'NOT VERIFIED',
            'dolby_vision_hdr10plus':'DETECTION AND EXPLICIT STATIC/BASE FALLBACK ONLY'}
    if sys.platform!='win32':
        print('Windows/Qt/D3D11 required; no result claimed')
        return 2
    from PySide6.QtTest import QTest
    from PySide6.QtWidgets import QApplication
    from directrgb.vnext_gui import MainWindow
    from directrgb.color_policy_resolver import OutputMode
    from directrgb.display_capabilities import query_displays
    report['displays']=[d.to_dict() for d in query_displays()]
    with tempfile.TemporaryDirectory(prefix='directrgb-color-') as folder:
        old=os.environ.get('LOCALAPPDATA')
        os.environ['LOCALAPPDATA']=folder
        app=QApplication.instance() or QApplication([])
        win=None
        try:
            win=MainWindow()
            win.show();QTest.qWait(100)
            assert win.color_output.count()==4
            assert win._selected_output()==OutputMode.LEGACY_SDR
            report['ui_modes']=[win.color_output.itemData(i) for i in range(win.color_output.count())]
            path=str(Path(ns.fixture).resolve())
            win.load_paths(0,[path])
            for _ in range(150):
                QTest.qWait(80)
                if win.panes[0].metadata and not win._loading:break
            report['legacy_blocked']=(win.panes[0].player is None and
                                       win.panes[0].metadata is not None)
            assert report['legacy_blocked'], 'HDR fixture was unexpectedly loaded in SDR reference mode'
            win.color_output.setCurrentIndex(2) # Explicit converted SDR preview
            for _ in range(210):
                QTest.qWait(100)
                if (win.batch_scheduler.active and win.batch_scheduler.active.complete):break
            p=win.panes[0]
            report['preview_status']=dict(win.batch_scheduler.active.statuses) if win.batch_scheduler.active else None
            report['preview_profile']=p.player.runtime_diagnostics() if p.player else 'FAILED / NOT AVAILABLE'
            if not p.player:
                report['status']='FAIL: converted preview backend rejected profile'
                report['reason']=p.status.text()
            else:
                report['status']='PREVIEW OPTION ACCEPTED, PIXEL VALIDATION NOT VERIFIED'
                win.color_output.setCurrentIndex(3) # Signal inspector only
                for _ in range(150):
                    QTest.qWait(80)
                    if win.batch_scheduler.active and win.batch_scheduler.active.complete:break
                report['signal_mode_no_gpu_player']=win.panes[0].player is None
                report['signal_report_family']=win.panes[0].metadata.color_report['family'] if win.panes[0].metadata else None
                if not report['signal_mode_no_gpu_player']:
                    report['status']='FAIL: signal-only mode retained a GPU player'
            report['native_hdr_attempt']='SKIPPED: opt-in and display-specific certification required'
        except Exception as exc:
            report['status']='FAIL: '+repr(exc)
        finally:
            if win:
                try:win.close();QTest.qWait(70)
                except Exception:pass
            if old is None:os.environ.pop('LOCALAPPDATA',None)
            else:os.environ['LOCALAPPDATA']=old
    destination=ROOT/'docs'/'UNIVERSAL_COLOR_WINDOWS_GUI_REPORT.json'
    destination.write_text(json.dumps(report,indent=2,default=str),encoding='utf-8')
    print(json.dumps(report,indent=2,default=str))
    return 1 if report['status'].startswith('FAIL') else 0

if __name__=='__main__':raise SystemExit(main())
