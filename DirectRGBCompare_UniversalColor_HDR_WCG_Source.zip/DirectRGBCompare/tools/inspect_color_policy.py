"""Read-only source/display/color-policy audit, works without Qt."""
from __future__ import annotations
import argparse, json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from directrgb.probe import probe_file
from directrgb.source_color_metadata import SourceColorReport
from directrgb.display_capabilities import query_displays
from directrgb.color_policy_resolver import OutputMode, resolve,PolicyError


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('media',type=Path)
    ap.add_argument('--experimental',action='store_true',help='Only audits a hypothetical profile; does not actually render')
    ap.add_argument('--static-fallback',action='store_true')
    ns=ap.parse_args()
    media=probe_file(str(ns.media))
    report=SourceColorReport(**media.color_report)
    displays=query_displays()
    results={}
    for mode in OutputMode:
        try:
            policy=resolve(report,mode,displays[0],
                allow_experimental=ns.experimental,
                allow_dynamic_fallback=ns.static_fallback)
            results[mode.value]=policy.to_dict()
        except PolicyError as exc:
            results[mode.value]={'blocked':str(exc)}
    print(json.dumps({'media_basename':ns.media.name, 'source_color':report.to_dict(),
                      'displays':[x.to_dict() for x in displays], 'decisions':results,
                      'actual_renderer_test':'NOT RUN', 'faststone_parity':'NOT VERIFIED'},
                     indent=2,default=str))
if __name__=='__main__':main()
