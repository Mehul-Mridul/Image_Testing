"""Optional pure-Python microbenchmark (NOT a Qt/4K FPS benchmark)."""
from pathlib import Path
from statistics import median
from time import perf_counter
import json,sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from directrgb.adaptive_layout import LayoutRequest,choose_layout,layout_for_manual_drag
from directrgb.motion import Spring

def run():
    req=LayoutRequest(1540,850,(9/16,16/9,9/16,16/9))
    initial=choose_layout(req)
    search=[];direct=[];spring_times=[]
    for _ in range(20):
        t=perf_counter();choose_layout(req,previous=initial,manual={initial.name:initial.ratios})
        search.append((perf_counter()-t)*1000)
        for _ in range(30):
            t=perf_counter();layout_for_manual_drag(req,initial.name,initial.ratios)
            direct.append((perf_counter()-t)*1000)
    for _ in range(30):
        s=Spring();s.retarget(1)
        t=perf_counter()
        for step in range(1000):s.step(.016)
        spring_times.append((perf_counter()-t)*1000)
    result={'benchmark':'pure Python layout/spring CPU microbenchmark',
            'platform':sys.platform,'layout':initial.name,
            'median_ms':{'full_layout_search':round(median(search),5),
                         'drag_manual_layout':round(median(direct),5),
                         '1000_spring_steps':round(median(spring_times),5)},
            'qt_gui_fps':'NOT MEASURED','video_fps':'NOT MEASURED','gpu':'NOT MEASURED'}
    print(json.dumps(result,indent=2))

if __name__=='__main__':run()
