@echo off
setlocal
cd /d "%~dp0"
echo Universal Color Windows UI / D3D11 smoke check
if not exist ".venv\Scripts\python.exe" (
  echo Virtual environment not found. Run RUN_FIRST.bat first.
  exit /b 2
)
".venv\Scripts\python.exe" tools\universal_color_gui_smoke.py %*
set "result=%ERRORLEVEL%"
echo.
echo Report: docs\UNIVERSAL_COLOR_WINDOWS_GUI_REPORT.json
echo Actual display RGB, HDR mastering fidelity and FastStone CMS-OFF matching remain NOT VERIFIED by this smoke test.
exit /b %result%
