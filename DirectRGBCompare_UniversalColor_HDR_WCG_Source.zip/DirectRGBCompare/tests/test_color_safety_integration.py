"""Fail-closed behavior of experimental output profiles; no GUI or HDR claims."""
from pathlib import Path
from directrgb.source_color_metadata import analyze_probe
from directrgb.color_policy_resolver import resolve, OutputMode, PolicyError
from directrgb.signal_inspector import plane_statistics
from directrgb.display_capabilities import DisplayCapabilities


def _dynamic(side):
    return analyze_probe({'streams':[{'codec_type':'video',
        'color_transfer':'smpte2084','color_primaries':'bt2020',
        'color_space':'bt2020nc','side_data_list':[{'side_data_type':side}]}]})


def test_dynamic_hdr_fallback_filter_is_a_mandatory_renderer_option():
    source = _dynamic('HDR Dynamic Metadata SMPTE2094-40')
    converted = resolve(source, OutputMode.SDR_PREVIEW, allow_dynamic_fallback=True)
    assert converted.option_dict()['vf'] == 'format=dolbyvision=no:hdr10plus=no:enhancement-layer=no:convert=no'
    assert 'STRIPPED' in ' '.join(converted.restrictions)
    display=DisplayCapabilities('test', True, True, 10, 0, 'mock', 'simulated', advanced_color_kind='HDR')
    native = resolve(source, OutputMode.NATIVE_HDR, display,
                     allow_experimental=True, allow_dynamic_fallback=True)
    assert native.option_dict()['vf'] == converted.option_dict()['vf']
    assert converted.fingerprint != native.fingerprint


def test_unverified_monitor_cannot_authorize_native_hdr():
    source = _dynamic('Mastering display metadata')
    display=DisplayCapabilities('test', True, None, None, None, 'mock', 'unverified')
    try:
        resolve(source, OutputMode.NATIVE_HDR, display, allow_experimental=True)
    except PolicyError as exc:
        assert 'not confirmed' in str(exc)
    else:
        raise AssertionError('Unverified monitor incorrectly authorized experimental HDR output')


def test_gpu_window_rebinding_and_diagnostic_override_are_isolated_in_ui_source():
    src=(Path(__file__).resolve().parents[1]/'directrgb'/'vnext_gui.py').read_text()
    assert 'if selected==OutputMode.LEGACY_SDR:\n                    pane.player.apply_overrides' in src
    assert 'Nonlegacy profiles may contain a mandatory HDR metadata' in src
    assert 'if self._selected_output()!=OutputMode.LEGACY_SDR:' in src
    assert 'QTimer.singleShot(0,self._color_output_changed)' in src
    assert 'pane._renderer_policy_fingerprint=None' in src


def test_p010_signal_histogram_retrieves_raw_stored_words_not_rgb():
    # One 2x2 p010 frame, Y has four 16-bit left-aligned code values and UV has
    # two 16-bit elements; raw signal mode must not apply a transfer function.
    import numpy as np
    signal=np.array([64<<6,128<<6,512<<6,940<<6,512<<6,512<<6],dtype='<u2')
    out=plane_statistics(signal.tobytes(),'p010le',2,2)
    assert out['planes'][0]['minimum']==64<<6
    assert out['planes'][0]['maximum']==940<<6
    assert out['tone_mapping']=='None'
