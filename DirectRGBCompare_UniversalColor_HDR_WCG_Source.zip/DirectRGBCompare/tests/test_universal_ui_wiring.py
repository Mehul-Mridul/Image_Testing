"""Static source gates on the actual new UI, runnable without PySide6."""
from pathlib import Path
import ast
BASE=Path(__file__).resolve().parents[1]/'directrgb'
UI=(BASE/'vnext_gui.py').read_text(encoding='utf-8')
CORE=(BASE/'mpv_native.py').read_text(encoding='utf-8')


def test_color_selector_and_mode_reload_are_wired():
    assert 'self.color_output.currentIndexChanged.connect(self._color_output_changed)' in UI
    assert 'self._restore_color_mode_state()' in UI
    assert 'ColorProfileMpvPanePlayer(int(pane.host.winId()),policy)' in UI
    assert 'SourceColorReport(**data.color_report)' in UI
    assert 'self.static_dynamic_fallback.isChecked()' in UI


def test_each_display_mode_has_separate_fail_closed_path():
    assert 'if selected==OutputMode.SIGNAL:' in UI
    assert 'except PolicyError as exc:' in UI
    assert 'CONVERTED SDR' in UI
    assert 'EXPERIMENTAL HDR' in UI
    assert 'pane.player.close();pane.player=None' in UI


def test_existing_video_renderer_does_not_change():
    assert 'for key, value in DIRECT_OPTIONS.items():' in CORE
    assert 'd3d11-output-format' not in (BASE/'premium_ui.py').read_text(encoding='utf-8')
    assert 'ColorProfileMpvPanePlayer' not in CORE


def test_signal_and_hdr_core_modules_import_without_qt():
    from directrgb import source_color_metadata, color_policy_resolver
    from directrgb import display_capabilities, color_renderer, signal_inspector
    assert hasattr(source_color_metadata,'analyze_probe')
    assert hasattr(color_policy_resolver,'resolve')
