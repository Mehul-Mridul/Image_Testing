"""Synthetic metadata + numerical reference unit tests; no HDR hardware claims."""
from dataclasses import replace
from unittest.mock import patch
import numpy as np
import pytest
from directrgb.source_color_metadata import analyze_probe
from directrgb.color_policy_resolver import resolve, OutputMode, PolicyError
from directrgb.display_capabilities import DisplayCapabilities, for_screen
from directrgb.hdr_reference_math import (pq_to_nits,nits_to_pq,hlg_to_scene_linear,
    convert_linear_primaries,linear_rgb_to_xyz)
from directrgb.signal_inspector import plane_statistics
from directrgb.policy import DIRECT_OPTIONS


def payload(prim='bt709',trc='bt709',matrix='bt709',side=(),frame=None):
    return {'streams':[{'codec_type':'video','codec_name':'hevc','profile':'Main 10',
                        'pix_fmt':'yuv420p10le','color_primaries':prim,'color_transfer':trc,
                        'color_space':matrix,'side_data_list':list(side)}],
            'frames':[{'media_type':'video', **(frame or {})}], 'format':{}}

HDR_DISPLAY=DisplayCapabilities('\\\\.\\DISPLAY1',True,True,10,0,'synthetic',
    'simulated HDR desktop, not a verified renderer',advanced_color_kind='HDR')
WCG_DISPLAY=DisplayCapabilities('\\\\.\\DISPLAY1',True,True,10,0,'synthetic',
    'simulated WCG-only',advanced_color_kind='WCG')


def test_legacy_sdr_hash_options_identical():
    s=analyze_probe(payload())
    p=resolve(s,OutputMode.LEGACY_SDR)
    assert p.option_dict()==DIRECT_OPTIONS
    assert p.profile=='legacy_sdr_v1'
    assert p.status.startswith('SDR POLICY REQUESTED')
    mixed=resolve(s,OutputMode.SDR_PREVIEW)
    assert mixed.option_dict()==DIRECT_OPTIONS
    assert mixed.transformations==()


def test_pq_and_hlg_detected_and_not_legacy():
    for transfer,family in (('smpte2084','hdr10_pq'),('arib-std-b67','hlg')):
        s=analyze_probe(payload('bt2020',transfer,'bt2020nc'))
        assert s.family==family
        with pytest.raises(PolicyError):resolve(s,OutputMode.LEGACY_SDR)
        with pytest.raises(PolicyError):resolve(s,OutputMode.NATIVE_HDR,HDR_DISPLAY)
        with pytest.raises(PolicyError):resolve(s,OutputMode.NATIVE_HDR,WCG_DISPLAY,allow_experimental=True)
        native=resolve(s,OutputMode.NATIVE_HDR,HDR_DISPLAY,allow_experimental=True)
        assert native.option_dict()['d3d11-output-format']=='rgba16f'
        assert native.status.startswith('EXPERIMENTAL')
        converted=resolve(s,OutputMode.SDR_PREVIEW)
        assert converted.option_dict()['tone-mapping']=='bt.2390'
        assert 'CONVERTED' in converted.status
        assert converted.fingerprint!=native.fingerprint


def test_dynamic_dolby_vision_requires_explicit_fallback():
    s=analyze_probe(payload('bt2020','smpte2084','bt2020nc',
        side=[{'side_data_type':'DOVI configuration record','dv_profile':8,'rpu_present_flag':1}]))
    assert s.family=='dolby_vision'
    assert s.dolby_vision_profile=='8'
    with pytest.raises(PolicyError,match='Opt in'):
        resolve(s,OutputMode.SDR_PREVIEW)
    p=resolve(s,OutputMode.SDR_PREVIEW,allow_dynamic_fallback=True)
    assert any('NOT VERIFIED' in warning for warning in p.restrictions)
    assert 'dolbyvision=no' in p.option_dict()['vf']
    assert 'hdr10plus=no' in p.option_dict()['vf']


def test_dolby_vision_no_compatible_base_is_blocked_even_with_fallback():
    s=analyze_probe(payload('bt2020','unspecified','bt2020nc',
        side=[{'side_data_type':'DOVI configuration record','dv_profile':5}]))
    with pytest.raises(PolicyError):resolve(s,OutputMode.SDR_PREVIEW,allow_dynamic_fallback=True)


def test_hdr10_plus_detected_without_claim_of_dynamic_mapping():
    s=analyze_probe(payload('bt2020','smpte2084','bt2020nc',
        frame={'side_data_list':[{'side_data_type':'HDR Dynamic Metadata SMPTE2094-40'}]}))
    assert s.family=='hdr10_plus'
    assert 'hdr10_plus' in s.dynamic_metadata
    with pytest.raises(PolicyError):resolve(s,OutputMode.NATIVE_HDR,HDR_DISPLAY,allow_experimental=True)


def test_first_frame_conflicting_metadata_rejected():
    s=analyze_probe(payload('bt709','bt709','bt709',frame={'color_transfer':'smpte2084'}))
    assert s.confidence=='conflicting'
    with pytest.raises(PolicyError):resolve(s,OutputMode.SDR_PREVIEW)


def test_p3_sdr_and_bt2020_sdr_not_legacy():
    for prim in ('smpte432','bt2020'):
        s=analyze_probe(payload(prim,'bt709'))
        assert s.family=='wide_gamut_sdr'
        with pytest.raises(PolicyError):resolve(s,OutputMode.LEGACY_SDR)
        assert resolve(s,OutputMode.SDR_PREVIEW).mode==OutputMode.SDR_PREVIEW
        assert resolve(s,OutputMode.NATIVE_HDR,HDR_DISPLAY,allow_experimental=True).mode==OutputMode.NATIVE_HDR
        assert resolve(s,OutputMode.NATIVE_HDR,WCG_DISPLAY,allow_experimental=True).mode==OutputMode.NATIVE_HDR


def test_missing_metadata_legacy_warning_retained():
    s=analyze_probe(payload('unspecified','unspecified','unspecified'))
    p=resolve(s,OutputMode.LEGACY_SDR)
    assert any('Unspecified' in x for x in p.restrictions)
    with pytest.raises(PolicyError):resolve(s,OutputMode.SDR_PREVIEW)


def test_signal_mode_never_selects_a_gpu_output():
    s=analyze_probe(payload('bt2020','smpte2084'))
    p=resolve(s,OutputMode.SIGNAL)
    assert p.option_dict()=={}
    assert 'not color-accurate' in p.status


def test_policy_does_not_mutate_legacy_options():
    original=dict(DIRECT_OPTIONS)
    s=analyze_probe(payload('bt2020','smpte2084','bt2020nc'))
    for m in (OutputMode.NATIVE_HDR,OutputMode.SDR_PREVIEW):
        resolve(s,m,HDR_DISPLAY,allow_experimental=True)
    assert original==DIRECT_OPTIONS


def test_display_unknown_is_fail_closed():
    with patch('directrgb.display_capabilities.sys.platform','linux'):
        d=for_screen('anything')
    assert d.advanced_color_enabled is None
    assert not d.can_attempt_native_hdr


def test_pq_reference_anchors():
    assert np.isclose(pq_to_nits(0),0,atol=1e-7)
    assert np.isclose(pq_to_nits(1),10000,rtol=1e-9)
    assert np.isclose(pq_to_nits(nits_to_pq(1000)),1000,rtol=1e-9)
    x=np.linspace(0,10000,101)
    assert np.allclose(pq_to_nits(nits_to_pq(x)),x,rtol=1e-7,atol=1e-7)


def test_hlg_reference_is_scene_referred_only():
    assert np.isclose(hlg_to_scene_linear(0),0)
    assert np.isclose(hlg_to_scene_linear(.5),1/12)
    assert np.isclose(hlg_to_scene_linear(1),1,atol=1e-7)


def test_linear_bt2020_to_709_keeps_out_of_gamut_components():
    val=convert_linear_primaries(np.array([1.,0.,0.]),'bt2020','bt709')
    assert val[0]>1 and val[1]<0
    assert np.allclose(convert_linear_primaries([.1,.2,.3],'bt709','bt709'),[.1,.2,.3])
    assert np.allclose(linear_rgb_to_xyz([1.,1.,1.],'bt709'),
                       linear_rgb_to_xyz([1.,1.,1.],'bt2020'),atol=1e-9)


def test_raw_yuv_signal_no_color_transform():
    # tiny 2x2 4:2:0: Y=[0,16,235,255], U=128, V=128.
    r=plane_statistics(bytes([0,16,235,255,128,128]),'yuv420p',2,2)
    assert r['planes'][0]['minimum']==0
    assert r['planes'][0]['maximum']==255
    assert r['planes'][1]['mean']==128
    assert r['tone_mapping']=='None'
    with pytest.raises(ValueError):plane_statistics(b'123','unknown_fmt',2,2)
    with pytest.raises(ValueError):plane_statistics(b'1','yuv420p',2,2)


def test_mixed_sdr_hdr_output_policy_per_pane():
    sdr=analyze_probe(payload('bt709','bt709'))
    hdr=analyze_probe(payload('bt2020','smpte2084','bt2020nc'))
    a=resolve(sdr,OutputMode.SDR_PREVIEW)
    b=resolve(hdr,OutputMode.SDR_PREVIEW)
    assert a.option_dict()==DIRECT_OPTIONS
    assert b.option_dict()['tone-mapping']=='bt.2390'
    # One verified HDR desktop supports both source types via scRGB; source
    # interpretation is independently resolved for each video.
    assert resolve(sdr,OutputMode.NATIVE_HDR,HDR_DISPLAY,allow_experimental=True).mode==OutputMode.NATIVE_HDR
    assert resolve(hdr,OutputMode.NATIVE_HDR,HDR_DISPLAY,allow_experimental=True).mode==OutputMode.NATIVE_HDR
