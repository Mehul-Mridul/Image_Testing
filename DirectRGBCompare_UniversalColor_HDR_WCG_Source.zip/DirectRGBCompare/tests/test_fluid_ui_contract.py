"""Offline wiring contract; true Qt behavior is separately tested on Windows."""
from pathlib import Path
from hashlib import sha256
from directrgb.app_settings import AppSettings

ROOT=Path(__file__).resolve().parents[1]

def source(name):return (ROOT/'directrgb'/name).read_text(encoding='utf8')


def test_ui_motion_stays_off_native_rgb_surface():
    s=source('fluid_interactions.py')
    assert 'class MotionSystem' in s
    assert 'class FluidButton' in s
    assert 'class ActivePaneStrip' in s
    assert 'class PanelTransitions' in s
    assert 'videoHost' not in s
    assert 'QGraphicsOpacityEffect' in s
    for name in ('policy.py','mpv_native.py','validation.py','color_math.py'):
        assert (ROOT/'directrgb'/name).is_file()


def test_scrubbing_never_springs_timestamp():
    ui=source('vnext_gui.py')
    timeline=source('timeline_widget.py')
    for method in ('start_scrub','scrub_moved','_preview_scrub','slider_released'):
        assert f'def {method}(self' in ui
    assert 'self._scrub_timer.setInterval(95)' in ui
    assert 'self.sliderReleased' not in ui  # no duplicate Qt connection
    assert 'self.setSliderPosition(self._value_at(event.position().x()))' in timeline
    assert 'self._hover' in timeline


def test_motion_settings_are_versioned(tmp_path):
    settings=AppSettings(path=tmp_path/'settings.json')
    assert settings.data['reduced_motion'] is False
    settings.data['reduced_motion']=True
    settings.save()
    other=AppSettings(path=tmp_path/'settings.json')
    assert other.data['reduced_motion'] is True


def test_previous_rgb_hashes_unchanged():
    from tests.test_renderer_policy_frozen import BASELINE
    for name,digest in BASELINE.items():
        assert sha256((ROOT/'directrgb'/name).read_bytes()).hexdigest()==digest
