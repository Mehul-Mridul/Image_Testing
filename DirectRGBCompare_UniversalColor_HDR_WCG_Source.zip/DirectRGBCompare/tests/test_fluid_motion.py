"""Offline, deterministic motion and workspace tests (no Qt/GPU needed)."""
from math import isfinite
import pytest
from directrgb.motion import Spring
from directrgb.adaptive_layout import (
    LayoutRequest, choose_layout, layout_for_manual_drag, resize_split,
)


def test_critical_spring_has_no_overshoot_and_converges():
    s=Spring()
    s.retarget(1)
    values=[s.step(1/120) for _ in range(180)]
    assert all(0<=x<=1.00001 for x in values)
    assert all(b>=a-1e-10 for a,b in zip(values,values[1:]))
    assert values[-1]==pytest.approx(1,abs=.001)
    assert s.settled


def test_retarget_does_not_restart_or_drop_velocity():
    s=Spring()
    s.retarget(1)
    for _ in range(12):s.step(1/120)
    x,v=s.value,s.velocity
    assert x>0 and v>0
    s.retarget(0)
    assert (s.value,s.velocity)==(x,v)
    s.step(1/120)
    assert s.value>x  # momentum continues briefly; reversal is continuous
    for _ in range(220):s.step(1/120)
    assert s.value==pytest.approx(0,abs=.001)


def test_elapsed_time_invariant_for_critical_spring():
    a,b=Spring(),Spring()
    a.retarget(1);b.retarget(1)
    for _ in range(60):a.step(1/120)
    for _ in range(10):b.step(.05)
    assert a.value==pytest.approx(b.value,abs=1e-9)
    assert a.velocity==pytest.approx(b.velocity,abs=1e-8)


def test_reduced_motion_snaps_and_cancels_velocity():
    s=Spring(value=.2,target=1,velocity=3)
    s.step(.01,reduced_motion=True)
    assert (s.value,s.velocity)==(1,0)
    s.retarget(0,reduced_motion=True)
    assert (s.value,s.velocity)==(0,0)


def test_damping_and_invalid_inputs():
    for z in (.4,1,1.8):
        s=Spring(damping_ratio=z);s.retarget(1)
        for dt in (.016,.032,.18,.5):s.step(dt)
        assert isfinite(s.value) and isfinite(s.velocity)
    with pytest.raises(ValueError):Spring(frequency=0)
    with pytest.raises(ValueError):Spring(damping_ratio=-1)
    with pytest.raises(ValueError):Spring().step(-1)
    with pytest.raises(ValueError):Spring().retarget(float('nan'))


def test_manual_drag_keeps_topology_without_layout_search():
    request=LayoutRequest(1250,770,(.55,.55,.55))
    initial=choose_layout(request)
    key=next(iter(initial.ratios))
    ratios=resize_split(initial,key,.65)
    result=layout_for_manual_drag(request,initial.name,ratios)
    assert result.name==initial.name
    assert result.ratios[key]==.65
    assert len(result.rectangles)==3
    assert result.dividers
    with pytest.raises(ValueError):layout_for_manual_drag(request,'invalid',ratios)
    with pytest.raises(ValueError):layout_for_manual_drag(request,initial.name,{key:float('nan')})
