"""Inspect profile opt-ins and mpv option injection without Windows hardware."""
from pathlib import Path
from unittest.mock import patch
import pytest
from directrgb.color_renderer import ColorProfileMpvPanePlayer
from directrgb.color_policy_resolver import OutputMode,resolve
from directrgb.display_capabilities import DisplayCapabilities
from directrgb.source_color_metadata import analyze_probe
from directrgb.policy import DIRECT_OPTIONS
from directrgb.paths import bundled_tool
from directrgb.probe import probe_file

class DLL:
    def __init__(self):self.options={};self.destroyed=False
    def mpv_create(self):return 123
    def mpv_set_option_string(self,h,k,v):self.options[k.decode()]=v.decode();return 0
    def mpv_initialize(self,h):return 0
    def mpv_terminate_destroy(self,h):self.destroyed=True
    def mpv_error_string(self,c):return b'fake mpv error'


def source():
    return analyze_probe({'streams':[{'codec_type':'video','color_transfer':'smpte2084',
        'color_primaries':'bt2020','color_space':'bt2020nc'}]})


def display():
    return DisplayCapabilities('DISPLAY1',True,True,10,0,'test','synthetic',advanced_color_kind='HDR')


def test_nonlegacy_profile_applies_before_initialize():
    policy=resolve(source(),OutputMode.NATIVE_HDR,display(),allow_experimental=True)
    dll=DLL()
    with patch('directrgb.color_renderer.sys.platform','win32'):
        player=ColorProfileMpvPanePlayer(0x123456789ABC,policy,lib=dll)
        assert dll.options['wid']==str(0x123456789ABC)
        assert dll.options['d3d11-output-format']=='rgba16f'
        assert dll.options['target-trc']=='scrgb'
        assert dll.options['vo']==DIRECT_OPTIONS['vo']
        assert player.color_policy_fingerprint==policy.fingerprint
        player.close()
        assert dll.destroyed


def test_converted_profile_is_labeled():
    policy=resolve(source(),OutputMode.SDR_PREVIEW)
    dll=DLL()
    with patch('directrgb.color_renderer.sys.platform','win32'):
        player=ColorProfileMpvPanePlayer(999,policy,lib=dll)
        assert dll.options['target-trc']=='bt.1886'
        assert dll.options['target-prim']=='bt.709'
        assert dll.options['tone-mapping']=='bt.2390'
        player.close()


def test_no_gpu_player_for_legacy_or_signal():
    for mode in (OutputMode.LEGACY_SDR,OutputMode.SIGNAL):
        # Resolve legacy from an SDR source separately.
        s=source() if mode==OutputMode.SIGNAL else analyze_probe({'streams':[{'codec_type':'video','color_transfer':'bt709','color_primaries':'bt709','color_space':'bt709'}]})
        policy=resolve(s,mode)
        dll=DLL()
        with patch('directrgb.color_renderer.sys.platform','win32'):
            with pytest.raises(Exception,match='only for explicit HDR'):
                ColorProfileMpvPanePlayer(111,policy,lib=dll)
        assert not dll.options


def test_actual_metadata_fixtures_have_correct_tags():
    fixtures=(('synthetic_hdr10_metadata_ffv1.mkv','hdr10_pq'),
              ('synthetic_hlg_metadata_ffv1.mkv','hlg'),
              ('synthetic_p3_sdr_metadata_ffv1.mkv','wide_gamut_sdr'))
    folder=Path(__file__).resolve().parents[1]/'assets'
    for filename,family in fixtures:
        m=probe_file(str(folder/filename))
        assert m.color_report['family']==family
        assert m.color_report['confidence']=='tagged'
        assert m.bit_depth=='10'
        assert not m.eligibility[0]
        assert resolve(analyze_probe({'streams':[{'codec_type':'video','color_transfer':m.transfer,
              'color_primaries':m.primaries,'color_space':m.matrix}]}),OutputMode.SDR_PREVIEW)
