# DirectRGB Compare — Universal Color / HDR / Wide-Gamut source extension

**Status (2026-11-11): SOURCE IMPLEMENTATION + OFFLINE TESTS. NOT A CERTIFIED HDR PLAYER.**

This release **extends the existing Fluid UI** and retains the original SDR color-critical path in a separate legacy profile. It adds source color metadata inspection, separate output policies, read-only Windows Advanced Color detection, an experimental libmpv FP16 scRGB output *request*, an explicit HDR-to-SDR converted-preview request, and a decoded-source-signal inspector. **It does not implement or validate a fully managed Dolby Vision/HDR10+ dynamic metadata output pipeline.**

## Quick start on Windows

1. Extract the **complete source ZIP to a new folder**. Do not overwrite a working build in place; an old EXE does not reflect a newly extracted Python source tree.
2. Run `RUN_FIRST.bat` on Windows x64 to install native dependencies, test, and build. It requires Internet access on first run and produces `dist\DirectRGBCompare\DirectRGBCompare.exe` only after a successful Windows build. No precompiled EXE is included.
3. Open a directory with **Ctrl+Shift+O**, select 2–4 clips, press **Ctrl+L**. File browser **Ctrl+B**; restore browser **Ctrl+Shift+R**.
4. The new **Color output** selector is separate from legacy **Diagnostic RGB** overrides. Choose a profile deliberately:
   - **Direct RGB SDR — FastStone CMS OFF reference:** exact existing SDR policy request, unchanged from Fluid UI. Known tagged HDR/P3/BT.2020 material is blocked in this profile.
   - **Native HDR / Wide Gamut — EXPERIMENTAL:** requires an Advanced Color-capable *active* Windows screen and explicit **Workspace → Color output safeguards → Permit experimental scRGB HDR**. Requests a libmpv GPU-next FP16 scRGB output; **does not verify that a FP16 DXGI swapchain was actually negotiated**. BT.2020 HDR and P3 SDR require different display capabilities. Failure to query or map the current monitor blocks this mode.
   - **HDR → SDR Converted Preview:** explicit request for libmpv GPU-next HDR conversion to BT.709 SDR (BT.2390 tone mapping). This **does change the image for the target display by design**, and is never called native HDR or original HDR appearance. Ordinary SDR in this mixed-mode workspace keeps the frozen SDR policy.
   - **Signal Inspector (source values):** does not instantiate a GPU video player; source metadata is shown, with **Workspace → Inspection → Analyze selected signal** performing bounded, non-color-graded first-frame decoded plane statistics when supported.
5. For HDR10+/Dolby Vision metadata sources: the application **blocks non-signal playback by default**. Only if you explicitly enable **Permit static/base-layer fallback for HDR10+/DV** will it request mpv's format filter to strip dynamic metadata and optionally an enhancement layer. This is an **unverified static/base-layer approximation**, not complete Dolby Vision or HDR10+ playback. Untagged/unsupported Dolby Vision base layers are refused.
6. After setup, run `CHECK_COLOR_MODES_GUI.bat`. The resulting `docs\UNIVERSAL_COLOR_WINDOWS_GUI_REPORT.json` tests **UI wiring and option acceptance**, not physical color fidelity. Run the original RGB test suite separately.

For a read-only file audit without starting the GUI:

```powershell
.venv\Scripts\python.exe tools\inspect_color_policy.py "C:\path\to\sample.mkv"
```

## Current format / capability matrix

| Source type | Metadata recognition | Legacy SDR | Native HDR/WCG | HDR→SDR converted preview | Native output verified? |
|---|---|---|---|---|---|
| BT.601/BT.709 SDR | Stream + sampled first frame | Existing SDR policy | May map SDR into experimental shared scRGB workspace | **No conversion** for SDR panes | No |
| Full/limited, 8/10/12-bit SDR | Tags + pixel format; strict source-dependent validation | Existing SDR decoder output, bit-depth validation outstanding | Experimental if supported screen | No conversion for standard SDR panes | No |
| Display P3 / BT.2020 SDR | Tagged wide-gamut detection | Blocked | Experimental on WCG/HDR Advanced Color display | Explicit conversion to BT.709 | No |
| HDR10/PQ BT.2020 | Transfer/primaries/mastering side-data | Blocked | Experimental on active HDR Advanced Color display | BT.2390/BT.709 converted preview | No |
| HLG BT.2020 | Transfer tags | Blocked | Experimental on active HDR display | Explicit converted preview | No |
| HDR10+ | Dynamic metadata recognized when exposed | Blocked | Blocked without explicit static fallback | Static fallback opt-in only | **Dynamic metadata application NOT implemented** |
| Dolby Vision | Profile/metadata recognized when exposed | Blocked | Blocked without explicit base-layer fallback | Compatible tagged PQ/HLG base-layer opt-in only | **Full Dolby Vision NOT implemented** |
| Camera Log, untagged HDR, conflicting transfer/primaries | Unknown/conflict surfaced | Legacy may still accept missing tags according to previous SDR behavior, with warning | Blocked | Blocked pending validated interpretation | No |
| DRM/encrypted/proprietary source | Not generally decoded | Not guaranteed | Not guaranteed | Not guaranteed | No |

**Notes:** Metadata recognized does not mean the actual dynamic metadata stream is handled. The test `assets/synthetic_*_metadata_ffv1.mkv` fixtures contain *tagged synthetic frames*, **not** physically mastered HDR images. They are for format routing only.

## Architecture

```text
                      SOURCE / FFPROBE
                   probe.py (+ full color_report)
                             |
               source_color_metadata.py
                             |
  Windows DisplayConfig read-only ----- display_capabilities.py
                             |
                   color_policy_resolver.py
                   [immutable fingerprint]
                             |
      +----------------------+---------------------+
      |                      |                     |
 DIRECT_OPTIONS (frozen)  ColorProfileMpvPanePlayer  SIGNAL (no GPU player)
 Existing MpvPanePlayer   (explicit profile options)  signal_inspector.py
      |                      |                     |
   original SDR             GPU-next/D3D11          decoded samples
     pipeline              experimental             only
      +----------------------+---------------------+
                             |
                    premium Qt GUI
                original time and pane model
```

`policy.py`, `mpv_native.py`, `validation.py`, and `color_math.py` are **byte-for-byte preserved** relative to the Fluid UI package. The new modules sit alongside them. The FP16 request is injected before `mpv_initialize` into a separate player constructor. A change of output mode reloads media and attempts to preserve time and offsets; unrelated pane/UI behavior is not deliberately changed.

The UI **disables old diagnostic range/matrix editing in nonlegacy modes**, because this would otherwise risk clearing the mandatory static HDR fallback format filter. A monitor change pauses playback, invalidates capabilities and, for nonlegacy modes, closes the old player before queuing a fresh policy check. A new monitor without the required capabilities blocks the previous HDR output instead of reusing it.

`display_capabilities.py` reads active Windows DisplayConfig state (including INFO_2 when supported), but it cannot infer a private libmpv swapchain format. For Qt screens that cannot be reliably mapped to Windows display paths, experimental native output fails closed. To certify the output, implement a native D3D11/DXGI instrumentation bridge to query effective `IDXGISwapChain` pixel format and color space (not merely requested settings) and perform independent GPU readback/color tests.

## Color intent / preservation

The program **never edits or re-encodes the original video file**. Its legacy Direct RGB path preserves the existing SDR display request. Other modes may perform mathematically necessary conversions: range expansion, YCbCr matrix, transfer-function conversion, primaries adaptation and/or declared tone mapping. `HDR → SDR Converted Preview` is **not source-identical**; the original HDR dynamic range is impossible to reproduce on an SDR display. The source-signal inspector avoids output tonemapping and gives integer sample statistics, **not on-screen RGB**.

`hdr_reference_math.py` is a standalone, high-precision (float64) reference toolbox for ST2084 inverse/forward transfer, HLG inverse OETF and linear-light D65 RGB ↔ XYZ conversion. It is **not** applied to render pixels and doesn't implement full HLG display OOTF, BT.2390, gamut mapping, DCI-P3 white-point adaptation or Dolby Vision metadata processing.

## Windows qualification still required

- Verify current packaged libmpv supports and actually honors the requested format filter and output options; unsupported options must produce a visible load failure.
- Check display enumeration/Win64 struct layouts and `Qt QScreen.name()` mapping on multiple GPUs, multiple screens, mixed WCG/HDR state, HDR toggling, refresh rate and window dragging. Confirm display change stops/revalidates output as intended.
- Confirm actual D3D11 swapchain pixel format, DXGI color space, Windows DWM composition, scRGB reference-white scaling, SDR-in-HDR levels and output primaries.
- Compare **identical decoded frames**, including PTS, through controlled reference paths for HDR10 PQ, HLG, P3, 10-/12-bit SDR, HDR10+/Dolby Vision profiles. For 10-bit/HDR, use linear-light/high-precision references; don't quantify fidelity using 8-bit PNG equality.
- Capture actual GPU output or comparable signal in a controlled manner. For physical luminance/chromaticity fidelity, test a calibrated HDR/WCG display and appropriate measurement equipment.
- Test 1–4 simultaneous clips with 4K portrait HDR, buffer memory, dropped frames, scrubbing/seek, invalid metadata, decoding errors and no console flashes.
- Run original SDR FastStone CMS-OFF frame comparison on unchanged test fixtures. The offline tests prove **policy preservation**, not display-level bit-exact equivalence.
- Measure loading and frame latency on actual Windows hardware. No Windows HDR, D3D11, physical-display or four-stream benchmark is claimed by this package.
- Test license/capability requirements of Dolby Vision and other proprietary codecs; this release **does not** provide a licensed Dolby Vision output implementation.

## Test and source provenance

All `pytest` tests can run on Linux without a GUI. Hardware-specific checks require Windows/PySide6/libmpv and dedicated HDR media. The small synthetic tagged fixtures validate metadata routing, **not** perceptual display quality. See `tests/test_universal_color.py`, `tests/test_color_render_profiles.py`, `tests/test_color_safety_integration.py`, `tests/test_universal_ui_wiring.py` and `tools/universal_color_gui_smoke.py`.

Documentation references:
- Official mpv manual: https://mpv.io/manual/master/
- mpv format filter: https://github.com/mpv-player/mpv/blob/master/DOCS/man/vf.rst
- Windows Advanced Color: https://learn.microsoft.com/windows/win32/direct3darticles/high-dynamic-range

**This is a bounded, fail-closed source extension that makes safe progress toward universal HDR/WCG support; it is not complete format coverage or validated native HDR playback.**
