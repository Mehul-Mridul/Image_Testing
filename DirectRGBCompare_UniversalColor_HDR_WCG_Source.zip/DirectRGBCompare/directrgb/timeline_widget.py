"""Refined video-comparison timeline; paint only UI, never video pixels."""
from PySide6.QtCore import Qt,QRectF,QPointF
from PySide6.QtGui import QColor,QPainter,QPen
from PySide6.QtWidgets import QSlider,QStyle
from .theme import THEMES,DEFAULT_THEME


class PremiumTimeline(QSlider):
    def __init__(self,orientation=Qt.Orientation.Horizontal,parent=None):
        super().__init__(orientation,parent)
        self._end_marks={}
        self._theme=THEMES[DEFAULT_THEME]
        self.setMinimumHeight(28)
        self.setMouseTracking(True)
        self.setToolTip('Master timeline · longer clips continue after shorter clips end')
        self.setAccessibleName('Global comparison timeline')
        self.setFocusPolicy(Qt.FocusPolicy.StrongFocus)
        self.motion=None
        self._hover=0.0

    def bind_motion(self,motion):
        self.motion=motion

    def _hover_value(self,value):
        self._hover=value
        self.update()

    def enterEvent(self,event):
        if self.motion:self.motion.animate(self,self._hover_value,1.0,frequency=4.8)
        else:self._hover_value(1.)
        super().enterEvent(event)

    def leaveEvent(self,event):
        if self.motion:self.motion.animate(self,self._hover_value,0.0,frequency=4.8)
        else:self._hover_value(0.)
        super().leaveEvent(event)

    def set_theme(self,name):
        self._theme=THEMES.get(name,THEMES[DEFAULT_THEME]);self.update()

    def set_end_marks(self,marks):
        """Relative duration markers (pane index -> timeline fraction)."""
        self._end_marks={int(i):max(0.,min(1.,float(f))) for i,f in marks.items()}
        self.update()

    def _value_at(self,x):
        # Leave a margin for the handle so clipping cannot hide endpoints.
        width=max(1.,self.width()-24.)
        fraction=max(0.,min(1.,(x-12.)/width))
        if self.invertedAppearance():fraction=1.-fraction
        return QStyle.sliderValueFromPosition(self.minimum(),self.maximum(),round(fraction*10000),10000)

    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:
            self.setSliderDown(True)
            self.setSliderPosition(self._value_at(event.position().x()))
            event.accept();return
        super().mousePressEvent(event)

    def mouseMoveEvent(self,event):
        if self.isSliderDown():
            self.setSliderPosition(self._value_at(event.position().x()))
            event.accept();return
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton and self.isSliderDown():
            self.setSliderPosition(self._value_at(event.position().x()))
            self.setSliderDown(False)
            event.accept();return
        super().mouseReleaseEvent(event)

    def paintEvent(self,event):
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing,True)
        t=self._theme
        left,right=12.,max(13.,float(self.width()-12))
        center=self.height()/2.
        thickness=4. + 1.6*self._hover + (1.4 if self.isSliderDown() else 0.)
        radius=6.5 + 1.8*self._hover + (1.2 if self.isSliderDown() else 0.)
        p.setPen(Qt.PenStyle.NoPen)
        p.setBrush(QColor(t.border));p.drawRoundedRect(QRectF(left,center-thickness/2,right-left,thickness),thickness/2,thickness/2)
        portion=(self.value()-self.minimum())/max(1,self.maximum()-self.minimum())
        p.setBrush(QColor(t.accent));p.drawRoundedRect(QRectF(left,center-thickness/2,max(0.,(right-left)*portion),thickness),thickness/2,thickness/2)
        colors=(t.accent,t.success,t.warning,'#BD9DE1')
        for i,fraction in self._end_marks.items():
            x=left+(right-left)*fraction
            p.setPen(QPen(QColor(colors[i%len(colors)]),2))
            p.drawLine(round(x),round(center-8),round(x),round(center+8))
        x=left+(right-left)*portion
        p.setPen(QPen(QColor(t.surface),2))
        p.setBrush(QColor('#FFFFFF'));p.drawEllipse(QPointF(x,center),radius,radius)
        p.end()
