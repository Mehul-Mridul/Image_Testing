"""Independent high-precision reference primitives for signal validation.

Not a video rendering or tone-mapping path. Values require explicit primaries,
transfer and display assumptions before colorimetric comparisons.
"""
from __future__ import annotations
import numpy as np

# SMPTE ST 2084 / ITU-R BT.2100, absolute luminance in cd/m².
M1 = 2610/16384
M2 = 2523/4096*128
C1 = 3424/4096
C2 = 2413/4096*32
C3 = 2392/4096*32

# D65 linear-light RGB -> XYZ (columns are R/G/B contributions)
RGB_TO_XYZ_D65 = {
    'bt709': np.array([[0.4123907992659595,0.3575843393838780,0.1804807884018343],
        [0.2126390058715104,0.7151686787677560,0.0721923153607337],
        [0.0193308187155919,0.1191947797946260,0.9505321522496607]]),
    'bt2020': np.array([[0.6369580483012914,0.1446169035862083,0.1688809751641721],
        [0.2627002120112671,0.6779980715188708,0.0593017164698620],
        [0.0,0.0280726930490874,1.0609850577107910]]),
    'display-p3': np.array([[0.4865709486482162,0.2656676931690931,0.1982172852343625],
        [0.2289745640697488,0.6917385218365064,0.0792869140937450],
        [0.0,0.0451133818589026,1.0439443689009760]]),
}


def pq_to_nits(encoded):
    x=np.asarray(encoded,dtype=np.float64)
    if np.any((x<0)|(x>1)):
        raise ValueError('PQ normalized signal outside [0,1]')
    a=np.power(x,1/M2)
    den=C2-C3*a
    return 10000*np.power(np.maximum((a-C1)/den,0),1/M1)


def nits_to_pq(nits):
    x=np.asarray(nits,dtype=np.float64)
    if np.any((x<0)|(x>10000)):
        raise ValueError('PQ luminance outside 0–10000 cd/m²')
    a=np.power(x/10000,M1)
    return np.power((C1+C2*a)/(1+C3*a),M2)


def hlg_to_scene_linear(encoded):
    """HLG inverse OETF, relative scene-linear; NOT display luminance.

    Correct display luminance needs reference white, nominal display peak,
    system gamma, viewing surround and the HLG OOTF.
    """
    x=np.asarray(encoded,dtype=np.float64)
    if np.any((x<0)|(x>1)):
        raise ValueError('HLG normalized signal outside [0,1]')
    a=0.17883277
    b=1-4*a
    c=0.5-a*np.log(4*a)
    return np.where(x<=0.5, (x*x)/3, (np.exp((x-c)/a)+b)/12)


def linear_rgb_to_xyz(rgb, primaries: str):
    if primaries not in RGB_TO_XYZ_D65:
        raise ValueError('Unknown or non-D65 primaries; explicit chromatic adaptation is required')
    x=np.asarray(rgb,dtype=np.float64)
    if x.shape[-1]!=3:
        raise ValueError('RGB must have three components')
    return x @ RGB_TO_XYZ_D65[primaries].T


def xyz_to_linear_rgb(xyz, primaries: str):
    if primaries not in RGB_TO_XYZ_D65:
        raise ValueError('Unknown or non-D65 primaries')
    x=np.asarray(xyz,dtype=np.float64)
    if x.shape[-1]!=3:
        raise ValueError('XYZ must have three components')
    return x @ np.linalg.inv(RGB_TO_XYZ_D65[primaries]).T


def convert_linear_primaries(rgb, source: str, target: str):
    """No clipping/gamut mapping; out-of-gamut negative or >1 values remain visible."""
    return xyz_to_linear_rgb(linear_rgb_to_xyz(rgb,source),target)
