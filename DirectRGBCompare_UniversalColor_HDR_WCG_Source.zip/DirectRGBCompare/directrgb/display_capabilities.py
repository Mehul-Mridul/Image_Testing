"""Read-only Windows display enumeration. Never toggles the Windows HDR switch.

Advanced Color state is NOT proof of the libmpv/DXGI swapchain format or
physical monitor calibration. Do not use it as a native HDR certification.
"""
from __future__ import annotations
import ctypes as C
import sys
from dataclasses import asdict, dataclass


@dataclass(frozen=True)
class DisplayCapabilities:
    screen: str
    advanced_color_supported: bool | None
    advanced_color_enabled: bool | None
    bits_per_channel: int | None
    color_encoding: int | None
    source: str
    diagnostic: str
    swapchain_verified: bool = False
    gamut_verified: bool = False
    advanced_color_kind: str = 'unverified'  # SDR / WCG / HDR / legacy-ambiguous

    def to_dict(self):
        return asdict(self)

    @property
    def can_attempt_native_hdr(self):
        return (self.advanced_color_supported is True
                and self.advanced_color_enabled is True
                and self.advanced_color_kind in ('HDR','legacy-ambiguous'))

    @property
    def can_attempt_native_wcg(self):
        return (self.advanced_color_supported is True
                and self.advanced_color_enabled is True
                and self.advanced_color_kind in ('WCG','HDR','legacy-ambiguous'))


def _unknown(screen, reason):
    return DisplayCapabilities(screen or 'unknown', None, None, None, None,
                               'Not Verified', str(reason))


def query_displays() -> list[DisplayCapabilities]:
    if sys.platform != 'win32':
        return [_unknown('', 'Windows display configuration APIs unavailable on this OS')]
    # Fixed-width types matter on Win64. DISPLAYCONFIG_PATH_INFO is 72 bytes.
    U32 = C.c_uint32
    class LUID(C.Structure):
        _fields_ = [('low', U32), ('high', C.c_int32)]
    class Source(C.Structure):
        _fields_ = [('adapter', LUID), ('id', U32), ('mode', U32), ('status', U32)]
    class Target(C.Structure):
        _fields_ = [('adapter', LUID), ('id', U32), ('mode', U32),
                    ('technology', U32), ('rotation', U32), ('scaling', U32),
                    ('refresh_num', U32), ('refresh_den', U32),
                    ('scanline', U32), ('available', C.c_int32), ('status', U32)]
    class Path(C.Structure):
        _fields_ = [('source', Source), ('target', Target), ('flags', U32)]
    class Mode(C.Structure):
        _fields_ = [('data', C.c_byte * 64)]
    class Header(C.Structure):
        _fields_ = [('type', U32), ('size', U32), ('adapter', LUID), ('id', U32)]
    class Name(C.Structure):
        _fields_ = [('header', Header), ('name', C.c_wchar * 32)]
    # The Windows SDK's anonymous union is 8-byte aligned on x64: 4 bytes
    # padding follow the 20-byte DEVICE_INFO_HEADER. Do not use a 32-byte
    # hand-rolled struct on Win64; it would cause failure or unsafe writes.
    class Color(C.Structure):
        _fields_ = [('header', Header), ('padding', U32),
                    ('flags', C.c_uint64), ('encoding', U32), ('bits', U32)]
    class Color2(C.Structure):
        _fields_ = [('header', Header), ('padding', U32),
                    ('flags', C.c_uint64), ('encoding', U32), ('bits', U32),
                    ('mode', U32), ('end_padding', U32)]
    assert C.sizeof(Path) == 72 and C.sizeof(Mode) == 64 and C.sizeof(Color) == 40 and C.sizeof(Color2) == 48
    try:
        user32 = C.WinDLL('user32', use_last_error=True)
        user32.GetDisplayConfigBufferSizes.argtypes = [U32, C.POINTER(U32), C.POINTER(U32)]
        user32.GetDisplayConfigBufferSizes.restype = C.c_int32
        user32.QueryDisplayConfig.argtypes = [U32, C.POINTER(U32), C.POINTER(Path),
            C.POINTER(U32), C.POINTER(Mode), C.c_void_p]
        user32.QueryDisplayConfig.restype = C.c_int32
        user32.DisplayConfigGetDeviceInfo.argtypes = [C.POINTER(Header)]
        user32.DisplayConfigGetDeviceInfo.restype = C.c_int32
        flags = U32(2)  # QDC_ONLY_ACTIVE_PATHS, read-only
        paths_n, modes_n = U32(), U32()
        err = user32.GetDisplayConfigBufferSizes(flags, C.byref(paths_n), C.byref(modes_n))
        if err:
            return [_unknown('', f'GetDisplayConfigBufferSizes returned {err}')]
        results = []
        # configuration can change between sizing and query; retry on ERROR_INSUFFICIENT_BUFFER.
        for _ in range(3):
            paths = (Path * max(paths_n.value, 1))()
            modes = (Mode * max(modes_n.value, 1))()
            err = user32.QueryDisplayConfig(flags, C.byref(paths_n), paths,
                                            C.byref(modes_n), modes, None)
            if err == 122:
                user32.GetDisplayConfigBufferSizes(flags, C.byref(paths_n), C.byref(modes_n))
                continue
            break
        if err:
            return [_unknown('', f'QueryDisplayConfig returned {err}')]
        for p in paths[:paths_n.value]:
            if not (p.flags & 1):
                continue
            name = Name()
            name.header = Header(1, C.sizeof(Name), p.source.adapter, p.source.id)
            rc_name = user32.DisplayConfigGetDeviceInfo(C.byref(name.header))
            label = str(name.name) if rc_name == 0 else f'Adapter {p.target.adapter.low}, target {p.target.id}'
            # Prefer Windows 11 24H2 INFO_2: explicitly distinguishes SDR,
            # WCG-only and HDR modes. Legacy Advanced Color alone does not.
            info2=Color2()
            info2.header=Header(15, C.sizeof(Color2), p.target.adapter, p.target.id)
            rc2=user32.DisplayConfigGetDeviceInfo(C.byref(info2.header))
            if rc2==0:
                kind={0:'SDR',1:'WCG',2:'HDR'}.get(info2.mode,'unverified')
                results.append(DisplayCapabilities(
                    label,bool(info2.flags & 1),kind in ('WCG','HDR'),
                    int(info2.bits),int(info2.encoding),
                    'Windows DisplayConfigGetDeviceInfo INFO_2',
                    'Actual libmpv/DXGI swapchain and physical monitor NOT VERIFIED',
                    advanced_color_kind=kind))
                continue
            info=Color()
            info.header=Header(9, C.sizeof(Color), p.target.adapter, p.target.id)
            rc=user32.DisplayConfigGetDeviceInfo(C.byref(info.header))
            if rc:
                results.append(_unknown(label,f'Advanced Color query failed: {rc}; INFO_2: {rc2}'))
                continue
            # INFO_1 is ambiguous on some Windows WCG configurations.
            active=bool(info.flags & 2)
            results.append(DisplayCapabilities(
                label,bool(info.flags & 1),active,
                int(info.bits),int(info.encoding),
                'Windows DisplayConfigGetDeviceInfo legacy',
                'Legacy Advanced Color active; HDR versus WCG not independently confirmed. Experimental opt-in only. GPU swapchain UNVERIFIED.',
                advanced_color_kind='legacy-ambiguous' if active else 'SDR'))
        return results or [_unknown('', 'No active Windows display paths reported')]
    except (OSError, AttributeError, ValueError, AssertionError) as exc:
        return [_unknown('', f'Windows display inspection unavailable: {exc}')]


def for_screen(screen_name: str | None) -> DisplayCapabilities:
    """Fail closed if a specific Qt window screen cannot be mapped to a Windows path."""
    records = query_displays()
    name = (screen_name or '').strip().casefold()
    for record in records:
        if name and record.screen.casefold() == name:
            return record
    # On a single-display system, Qt screen name is sometimes empty/different.
    if len(records) == 1 and not name:
        return records[0]
    return _unknown(screen_name or '', 'No verified mapping from current Qt screen to DisplayConfig output')
