"""Source-referred decoded-plane statistics, not a monitor RGB measurement.

Reads one decoded frame in its *declared* planar/interleaved format. Never
passes the result through tone mapping. Unsupported formats return an explicit
reason instead of silently converting to 8-bit RGB.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
import numpy as np
from .paths import bundled_tool
from .process_runner import run_command


@dataclass(frozen=True)
class PlaneStatistics:
    name: str
    count: int
    minimum: int
    maximum: int
    mean: float
    histogram: tuple[int, ...]  # 16 equally spaced signal-code bins, not colorimetric

    def to_dict(self):
        return asdict(self)


def _spec(fmt, w, h):
    full = (w, h)
    if fmt == 'rgb24':
        return [("R", (h,w,3), 0), ('G',(h,w,3),1),('B',(h,w,3),2)], 1, w*h*3
    if fmt == 'bgr24':
        return [("B", (h,w,3), 0), ('G',(h,w,3),1),('R',(h,w,3),2)], 1, w*h*3
    if fmt in ('yuv420p','yuv422p','yuv444p','yuv420p10le','yuv420p12le','yuv444p10le'):
        is16 = '10le' in fmt or '12le' in fmt
        if fmt.startswith('yuv420'):
            cw,ch=(w+1)//2,(h+1)//2
        elif fmt.startswith('yuv422'):
            cw,ch=(w+1)//2,h
        else:
            cw,ch=w,h
        return [('Y',(h,w),None),('U',(ch,cw),None),('V',(ch,cw),None)], (2 if is16 else 1), (w*h+2*cw*ch)*(2 if is16 else 1)
    if fmt=='nv12':
        return [('Y',(h,w),None),('UV',((h+1)//2,((w+1)//2)*2),None)], 1, w*h+((h+1)//2)*((w+1)//2)*2
    if fmt=='p010le':
        return [('Y',(h,w),None),('UV',((h+1)//2,((w+1)//2)*2),None)], 2, (w*h+((h+1)//2)*((w+1)//2)*2)*2
    return None


def plane_statistics(payload: bytes, pix_fmt: str, width: int, height: int) -> dict:
    """Inspect known little-endian planar formats; raise on unsupported/short data."""
    if not 0 < width <= 16384 or not 0 < height <= 16384:
        raise ValueError('Invalid or excessive dimensions')
    fmt = (pix_fmt or '').lower()
    spec = _spec(fmt,width,height)
    if spec is None:
        raise ValueError(f'Raw signal histogram unsupported for pixel format {fmt!r}; no conversion performed')
    planes, bps, needed = spec
    if needed > 160*1024*1024:
        raise ValueError('Frame exceeds bounded raw signal inspection budget')
    if len(payload) != needed:
        raise ValueError(f'Expected {needed} decoded bytes, received {len(payload)}')
    dtype = np.dtype('<u2' if bps==2 else 'u1')
    data = np.frombuffer(payload,dtype=dtype)
    if fmt in ('rgb24','bgr24'):
        view = data.reshape((height,width,3))
        channel_arrays = [(name,view[:,:,index]) for name,_,index in planes]
    else:
        cursor=0
        channel_arrays=[]
        for name,shape,_ in planes:
            count=int(np.prod(shape))
            arr=data[cursor:cursor+count].reshape(shape)
            cursor+=count
            channel_arrays.append((name,arr))
    code_max = 65535 if bps==2 else 255
    if fmt.endswith('10le'): code_max=1023
    if fmt.endswith('12le'): code_max=4095
    if fmt == 'p010le':code_max=65535  # 10-bit samples left-aligned in 16-bit words
    result=[]
    for name,arr in channel_arrays:
        # Histogram is on *stored code values*, no range expansion or transfer applied.
        h,_=np.histogram(arr,bins=16,range=(0,code_max+1))
        result.append(PlaneStatistics(name,int(arr.size),int(arr.min()),int(arr.max()),
                                      round(float(arr.mean()),4),tuple(int(x) for x in h)).to_dict())
    return {'pixel_format':fmt,'width':width,'height':height,
            'expected_bytes':needed,'signal_reference':'Decoded sample code values, not display RGB',
            'range_expansion':'None','tone_mapping':'None','planes':result}


def inspect_first_frame(path: str, pixel_format: str, width: int, height: int,
                        *, timeout=30, cancel_event=None) -> dict:
    spec=_spec(pixel_format.lower(),width,height)
    if spec is None:
        raise ValueError(f'Signal extraction unsupported for {pixel_format}; metadata inspection still available')
    if spec[2]>160*1024*1024:
        raise ValueError('Decoded frame exceeds analysis limit')
    cmd=[bundled_tool('ffmpeg'),'-hide_banner','-nostdin','-loglevel','error',
         '-noautorotate','-i',str(path),'-map','0:v:0','-an','-sn','-dn',
         '-frames:v','1','-pix_fmt',pixel_format,
         '-f','rawvideo','pipe:1']
    response=run_command(cmd,timeout=timeout,cancel_event=cancel_event)
    if response.returncode:
        raise RuntimeError('FFmpeg raw decode failed: '+response.stderr.decode(errors='replace')[-600:])
    report=plane_statistics(response.stdout,pixel_format,width,height)
    report['inspection_method']='FFmpeg rawvideo first decoded frame; output requested in the source pixel format'
    report['backend_format_verification']='Requested pix_fmt only; decoder internal pixel format must be independently checked'
    return report
