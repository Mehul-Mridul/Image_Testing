"""Central Qt style design. Surface/chrome only: avoid styling native HWND video content."""
from .theme import THEMES,DEFAULT_THEME


def make_stylesheet(name: str = DEFAULT_THEME) -> str:
    t=THEMES.get(name,THEMES[DEFAULT_THEME])
    values=vars(t).copy()
    def alpha(hexcode,a):
        return f'rgba({int(hexcode[1:3],16)},{int(hexcode[3:5],16)},{int(hexcode[5:7],16)},{a})'
    values['glass']=alpha(t.surface,242)
    values['glass_lift']=alpha(t.elevated,226)
    return '''
    QMainWindow, QDialog { background: %(background)s; color: %(text)s; }
    QWidget { color: %(text)s; font-family: "Segoe UI Variable", "Segoe UI", sans-serif; font-size: 12px; }
    QToolBar { background: %(glass)s; border: 0; border-bottom: 1px solid %(border)s;
               spacing: 7px; padding: 6px 10px; }
    QToolBar::separator { background: %(border)s; width: 1px; margin: 5px 6px; }
    QToolBar QToolButton, QToolBar QPushButton { background: %(raised)s; border: 1px solid %(border)s;
         border-radius: 9px; padding: 6px 10px; color: %(text)s; }
    QToolBar QToolButton:hover, QToolBar QPushButton:hover { background: %(elevated)s; border-color: %(accent)s; }
    QToolBar QToolButton:pressed, QPushButton:pressed { background: %(accent_soft)s; }
    QPushButton, QToolButton { border: 1px solid %(border)s; background: %(raised)s;
        border-radius: 9px; padding: 6px 10px; }
    QPushButton:hover, QToolButton:hover { background: %(elevated)s; border-color: %(accent)s; }
    QPushButton#primaryAction, QToolButton#primaryAction { background: %(accent_soft)s; border: 1px solid %(accent)s;
        color: %(text)s; font-weight: 600; }
    QLabel#branding { font-size: 14px; font-weight: 700; color: %(text)s; padding: 0 10px 0 0; }
    QLabel#subtitle, QLabel#muted { color: %(muted)s; }
    QFrame#pane { background: %(surface)s; border: 1px solid %(border)s; border-radius: 12px; }
    QFrame#pane[active="true"] { border: 2px solid %(accent)s; }
    /* Do not render any semitransparent styling into videoHost or its native framebuffer. */
    QFrame#videoHost { background: #050608; border: 0px; }
    QLabel#paneStatus { color: %(muted)s; font-size: 10px; }
    QDockWidget { color: %(text)s; font-weight: 600; }
    QDockWidget::title { background: %(glass_lift)s; padding: 8px 12px; border-bottom: 1px solid %(border)s; }
    QDockWidget::close-button, QDockWidget::float-button { background: %(elevated)s; border-radius: 4px; }
    QLineEdit, QDoubleSpinBox, QComboBox, QSpinBox { background: %(raised)s; color: %(text)s;
        selection-background-color: %(accent_soft)s; border: 1px solid %(border)s;
        border-radius: 8px; padding: 5px 8px; }
    QLineEdit:focus, QComboBox:focus { border-color: %(accent)s; }
    QComboBox::drop-down { border: none; width: 16px; }
    QComboBox QAbstractItemView { background: %(raised)s; color: %(text)s; selection-background-color: %(accent_soft)s; }
    QTreeView, QTableWidget, QListView { background: %(surface)s; alternate-background-color: %(raised)s;
       color: %(text)s; border: none; selection-background-color: %(accent_soft)s;
       selection-color: %(text)s; outline: 0; }
    QTreeView::item { padding: 5px; border-radius: 5px; }
    QTreeView::item:hover { background: %(elevated)s; }
    QHeaderView::section { background: %(raised)s; color: %(muted)s;
         border: 0; padding: 5px; }
    QPlainTextEdit { background: %(surface)s; color: %(text)s; border: none;
          font-family: Consolas, monospace; font-size: 11px; }
    QStatusBar { background: %(background)s; color: %(muted)s; border-top: 1px solid %(border)s; }
    QSplitter::handle { background: %(border)s; }
    QMenu { background: %(raised)s; color: %(text)s; border: 1px solid %(border)s;
            border-radius: 9px; padding: 6px; }
    QMenu::item { padding: 6px 23px 6px 13px; border-radius: 5px; }
    QMenu::item:selected { background: %(accent_soft)s; }
    QMenu::separator { height: 1px; background: %(border)s; margin: 5px 8px; }
    QScrollBar:vertical { background: %(surface)s; width: 9px; margin: 1px; }
    QScrollBar::handle:vertical { background: %(border)s; border-radius: 4px; min-height: 22px; }
    QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical { height: 0px; }
    QScrollBar:horizontal { background: %(surface)s; height: 9px; }
    QScrollBar::handle:horizontal { background: %(border)s; border-radius: 4px; min-width: 22px; }
    QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal { width: 0px; }
    QCheckBox::indicator { width: 15px; height: 15px; }
    QToolTip { background: %(elevated)s; color: %(text)s; border: 1px solid %(border)s; }
    ''' % values
