"""Additional, explicitly selected libmpv profiles.

The frozen v5 MpvPanePlayer and its default color options are untouched.
This adapter only activates for non-legacy modes and cannot assert that the
requested GPU format actually became the DXGI swapchain format.
"""
from __future__ import annotations
import sys
from .mpv_native import MpvPanePlayer, MpvError, load_mpv
from .color_policy_resolver import ResolvedColorPolicy, OutputMode


class ColorProfileMpvPanePlayer(MpvPanePlayer):
    def __init__(self, window_id: int, policy: ResolvedColorPolicy, lib=None):
        if policy.mode not in (OutputMode.NATIVE_HDR, OutputMode.SDR_PREVIEW):
            raise MpvError('This adapter is only for explicit HDR or converted-preview profiles')
        if sys.platform != 'win32':
            raise MpvError('Embedded Direct3D 11 backend is Windows-only')
        self.lib = lib or load_mpv()
        self.handle = self.lib.mpv_create()
        if not self.handle:
            raise MpvError('mpv_create failed')
        self._closed = False
        self.effective_options = {}
        self.color_policy = policy
        self.color_policy_fingerprint = policy.fingerprint
        try:
            if window_id <= 0:
                raise MpvError('Qt did not provide a native Win32 window handle')
            self._option('wid', str(window_id))
            for key, value in policy.options:
                self._option(key, value)
            self._check(self.lib.mpv_initialize(self.handle), 'mpv_initialize')
            self._next_userdata = 1
        except Exception:
            self.close()
            raise

    def runtime_diagnostics(self):
        report = super().runtime_diagnostics()
        report['profile'] = self.color_policy.profile
        report['color_policy'] = self.color_policy.to_dict()
        report['native_hdr_certified'] = False
        report['actual_swapchain_validation'] = 'NOT VERIFIED: option acceptance is not a DXGI readback'
        if self.color_policy.profile == 'legacy_sdr_in_mixed_workspace_v1':
            report['color_conversion'] = 'None: legacy SDR options, no tone-mapping'
        elif self.color_policy.mode == OutputMode.SDR_PREVIEW:
            report['color_conversion'] = 'EXPLICIT BT.2390 / BT.709 SDR PREVIEW'
        else:
            report['color_conversion'] = 'Requested linear scRGB; display adaptation and output must be tested'
        return report
