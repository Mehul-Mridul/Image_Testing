"""Qt-independent, deterministic motion mathematics for *chrome only*.

The spring uses the exact solution to a damped second-order system over each
elapsed time step. It retains velocity through retargets, survives variable UI
frame pacing, and never animates media timestamps or RGB presentation values.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import cos, exp, sin, sqrt, cosh, sinh, isfinite


@dataclass
class Spring:
    value: float = 0.0
    target: float = 0.0
    velocity: float = 0.0
    frequency: float = 3.2      # Hz; aesthetic chrome, not interaction tracking
    damping_ratio: float = 1.0  # critically damped default; no bounce
    tolerance: float = 0.001

    def __post_init__(self):
        if not (isfinite(self.frequency) and self.frequency > 0):
            raise ValueError('Spring frequency must be finite and positive')
        if not (isfinite(self.damping_ratio) and self.damping_ratio >= 0):
            raise ValueError('Spring damping ratio must be finite and >=0')
        if not all(isfinite(x) for x in (self.value,self.target,self.velocity)):
            raise ValueError('Spring state must be finite')

    @property
    def settled(self):
        return abs(self.value-self.target) <= self.tolerance and abs(self.velocity) <= self.tolerance*40

    def retarget(self, target: float, *, reduced_motion: bool = False):
        if not isfinite(target): raise ValueError('Non-finite target')
        self.target = float(target)
        if reduced_motion:
            self.value, self.velocity = self.target, 0.0

    def step(self, dt: float, *, reduced_motion: bool = False) -> float:
        if not isfinite(dt) or dt < 0:
            raise ValueError('Expected nonnegative, finite elapsed time')
        if reduced_motion:
            self.value,self.velocity=self.target,0.0
            return self.value
        if dt == 0 or self.settled:
            if self.settled:self.value,self.velocity=self.target,0.0
            return self.value
        # Exact damped oscillator solution, so a dropped frame does not alter
        # the intended motion or create large numerical integration overshoots.
        w = 2*3.141592653589793*self.frequency
        z = self.damping_ratio
        x = self.value-self.target
        v = self.velocity
        if abs(z-1.0) < 1e-8:
            k = v+w*x
            e = exp(-w*dt)
            new_x=(x+k*dt)*e
            new_v=(v-w*k*dt)*e
        elif z < 1.0:
            wd=w*sqrt(1-z*z)
            a=(v+z*w*x)/wd
            c,s=cos(wd*dt),sin(wd*dt)
            e=exp(-z*w*dt)
            new_x=e*(x*c+a*s)
            new_v=e*((-z*w*x+wd*a)*c+(-z*w*a-wd*x)*s)
        else:
            # Overdamped solution via two real eigenvalues avoids hyperbolic
            # overflow for long delays after the UI has lost focus.
            d=sqrt(z*z-1)
            r1=-w*(z-d);r2=-w*(z+d)
            a=(v-r2*x)/(r1-r2)
            b=x-a
            new_x=a*exp(r1*dt)+b*exp(r2*dt)
            new_v=r1*a*exp(r1*dt)+r2*b*exp(r2*dt)
        self.value=self.target+new_x
        self.velocity=new_v
        if self.settled:self.value,self.velocity=self.target,0.0
        return self.value
