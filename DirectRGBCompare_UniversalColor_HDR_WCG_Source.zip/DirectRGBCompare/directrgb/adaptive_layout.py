"""Pure aspect-aware comparison layout solver. No Qt, frames or color processing.

Trees split the workspace horizontally (h: left/right) or vertically (v:
upper/lower). Each leaf is a stable pane index, never a freshly parented HWND.
"""
from __future__ import annotations
from dataclasses import dataclass
from itertools import product
from math import isfinite

GAP = 8
NODE_RATIOS = (.25, .33, .40, .50, .60, .67, .75)


@dataclass(frozen=True)
class Rect:
    x: int
    y: int
    w: int
    h: int


@dataclass(frozen=True)
class LayoutRequest:
    width: int
    height: int
    aspects: tuple[float, ...]
    focused: int | None = None
    preferred: str | None = None
    header_height: int = 28
    minimum_width: int = 135
    minimum_height: int = 115


@dataclass(frozen=True)
class LayoutResult:
    name: str
    rectangles: dict[int, Rect]
    score: float
    ratios: dict[str, float]
    dividers: tuple[tuple[str, str, Rect, Rect], ...]  # id, axis, parent, handle


def orientations(metadata):
    """Calculate displayed width/height from SAR and right-angle rotation."""
    if metadata is None:
        return 16 / 9
    w, h = float(metadata.width), float(metadata.height)
    if w <= 0 or h <= 0:
        return 16 / 9
    try:
        from .view_geometry import parse_sar
        sar = parse_sar(metadata.sar)
        rotation = int(float(metadata.rotation)) if metadata.rotation != 'Unspecified' else 0
    except (ValueError, TypeError, AttributeError):
        sar, rotation = 1.0, 0
    w *= sar
    if rotation % 180:
        w, h = h, w
    return w / h


def _candidates(n):
    if not 1 <= n <= 4:
        raise ValueError('Expected 1-4 comparison panes')
    if n == 1:
        return {'single': 0}
    if n == 2:
        return {'side-by-side': ('h', 0, 1), 'stacked': ('v', 0, 1)}
    if n == 3:
        return {
            'three-columns': ('h', 0, ('h', 1, 2)),
            'three-rows': ('v', 0, ('v', 1, 2)),
            'large-left': ('h', 0, ('v', 1, 2)),
            'large-right': ('h', ('v', 0, 1), 2),
            'large-top': ('v', 0, ('h', 1, 2)),
            'large-bottom': ('v', ('h', 0, 1), 2),
        }
    return {
        'two-by-two': ('v', ('h', 0, 1), ('h', 2, 3)),
        'four-columns': ('h', ('h', 0, 1), ('h', 2, 3)),
        'four-rows': ('v', ('v', 0, 1), ('v', 2, 3)),
        'one-plus-three': ('h', 0, ('v', 1, ('v', 2, 3))),
        'three-plus-one': ('h', ('v', 0, ('v', 1, 2)), 3),
    }


def _split_ids(tree, prefix='root'):
    if isinstance(tree, int):
        return ()
    return (prefix,) + _split_ids(tree[1], prefix + '.a') + _split_ids(tree[2], prefix + '.b')


def _place(tree, rect, ratios, prefix='root'):
    if isinstance(tree, int):
        return {tree: rect}, ()
    axis, a, b = tree
    ratio = ratios.get(prefix, .5)
    if axis == 'h':
        usable = max(0, rect.w - GAP)
        size = max(0, min(usable, round(usable * ratio)))
        first = Rect(rect.x, rect.y, size, rect.h)
        second = Rect(rect.x + size + GAP, rect.y, usable - size, rect.h)
        divider = Rect(rect.x + size, rect.y, GAP, rect.h)
    else:
        usable = max(0, rect.h - GAP)
        size = max(0, min(usable, round(usable * ratio)))
        first = Rect(rect.x, rect.y, rect.w, size)
        second = Rect(rect.x, rect.y + size + GAP, rect.w, usable - size)
        divider = Rect(rect.x, rect.y + size, rect.w, GAP)
    ar, ad = _place(a, first, ratios, prefix + '.a')
    br, bd = _place(b, second, ratios, prefix + '.b')
    return {**ar, **br}, ((prefix, axis, rect, divider),) + ad + bd


def _score(request, rects):
    total = max(1, request.width * request.height)
    values = []
    penalty = 0.0
    for index, aspect in enumerate(request.aspects):
        r = rects[index]
        available_h = max(0, r.h - request.header_height)
        if r.w < request.minimum_width or r.h < request.minimum_height:
            penalty += 0.7
        if not isfinite(aspect) or aspect <= 0:
            aspect = 16 / 9
        display_h = min(available_h, r.w / aspect)
        display_w = display_h * aspect
        values.append((display_w * display_h) / total)
    # Reward actual visible image area; penalize tiny panes and extreme unfairness.
    mean = sum(values) / len(values)
    fairness = sum((v - mean)**2 for v in values) / len(values)
    return 0.55 * sum(values) + 0.45 * len(values) * min(values) - 0.2 * fairness - penalty


def choose_layout(request: LayoutRequest, *, previous: LayoutResult | None = None,
                  manual: dict[str, dict[str, float]] | None = None, hysteresis=.045) -> LayoutResult:
    if request.width < 1 or request.height < 1:
        raise ValueError('Workspace must have positive geometry')
    if not 1 <= len(request.aspects) <= 4:
        raise ValueError('Expected one to four aspect ratios')
    area = Rect(0, 0, request.width, request.height)
    if request.focused is not None:
        if request.focused not in range(len(request.aspects)):
            raise ValueError('Invalid focus pane')
        return LayoutResult('focused', {request.focused: area}, 1., {}, ())
    options = _candidates(len(request.aspects))
    manual = manual or {}
    results = []
    for name, tree in options.items():
        keys = _split_ids(tree)
        saved = manual.get(name)
        values = [saved] if saved else (
            (dict(zip(keys, ratios)) for ratios in product(NODE_RATIOS, repeat=len(keys))))
        best = None
        for weights in values:
            rects, dividers = _place(tree, area, weights)
            score = _score(request, rects)
            if best is None or score > best.score:
                best = LayoutResult(name, rects, score, dict(weights), dividers)
        assert best is not None
        results.append(best)
    results.sort(key=lambda r: r.score, reverse=True)
    winner = results[0]
    if request.preferred and any(r.name == request.preferred for r in results):
        preferred = next(r for r in results if r.name == request.preferred)
        if request.preferred in manual:
            return preferred
    # Prevent layout jitter when resizing near a crossover threshold.
    if previous and previous.name in options:
        old = next(r for r in results if r.name == previous.name)
        if winner.score - old.score <= hysteresis * max(abs(winner.score), .001):
            return old
    return winner


def resize_split(result: LayoutResult, split_id: str, fraction: float) -> dict[str, float]:
    if not 0.10 <= fraction <= 0.90:
        raise ValueError('Split fraction must be between 0.10 and 0.90')
    if split_id not in result.ratios:
        raise KeyError(split_id)
    return {**result.ratios, split_id: fraction}


def layout_for_manual_drag(request: LayoutRequest, name: str, ratios: dict[str,float]) -> LayoutResult:
    """O(number of panes) drag path; never optimize every candidate per pointer move.

    The ordinary choose_layout() solver remains available on video load/window
    resize. While a divider is grabbed, its layout *must not change topology*.
    """
    options=_candidates(len(request.aspects))
    if name not in options:raise ValueError(f'Unknown pane layout {name!r}')
    keys=_split_ids(options[name])
    if any(k not in keys or not isfinite(v) or not .1<=v<=.9 for k,v in ratios.items()):
        raise ValueError('Invalid splitter ratios')
    rectangles,dividers=_place(options[name],Rect(0,0,request.width,request.height),ratios)
    return LayoutResult(name,rectangles,_score(request,rectangles),dict(ratios),dividers)
