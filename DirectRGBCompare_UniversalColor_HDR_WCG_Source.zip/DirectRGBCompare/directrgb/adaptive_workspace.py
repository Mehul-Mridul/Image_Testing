"""Qt workspace adapter. Moves existing HWND hosts geometrically, never reparents
an initialized native video host while choosing orientations/layouts.
"""
from __future__ import annotations
from PySide6.QtCore import Qt, QTimer, QEvent
from PySide6.QtWidgets import QWidget
from PySide6.QtGui import QPainter, QColor
from .adaptive_layout import LayoutRequest, choose_layout, resize_split, orientations, layout_for_manual_drag


class AdaptiveWorkspace(QWidget):
    def __init__(self, panes, parent=None):
        super().__init__(parent)
        self.panes = panes
        self.count = 2
        self.focused = None
        self.previous = None
        self.manual = {}
        self.preferred = None
        self._drag = None
        self._hover_divider = None
        self._timed_resize = QTimer(self)
        self._timed_resize.setSingleShot(True)
        self._timed_resize.setInterval(65)
        self._timed_resize.timeout.connect(self.apply_layout)
        self.setMouseTracking(True)
        self.setObjectName('adaptiveWorkspace')
        for p in panes:
            # Only parent once, before constructing a libmpv HWND.
            p.setParent(self)
            p.setMinimumSize(0, 0)
        self.setMinimumSize(400, 180)

    def configure(self, count):
        self.count = max(1,min(4,int(count)))
        if self.focused is not None and self.focused >= self.count:
            self.focused = None
        self.request_layout()

    def request_layout(self):
        self._timed_resize.start()

    def resizeEvent(self,event):
        super().resizeEvent(event)
        self.request_layout()

    def toggle_focus(self, index):
        self.focused = None if self.focused == index else index
        self.apply_layout()

    def reset_auto(self):
        self.preferred = None
        self.manual.clear()
        self.previous = None
        self.apply_layout()

    def apply_layout(self):
        if self.width() < 1 or self.height() < 1:
            return
        aspects = tuple(orientations(self.panes[i].metadata) for i in range(self.count))
        request = LayoutRequest(self.width(),self.height(),aspects,focused=self.focused,
                                preferred=self.preferred)
        if self._drag and self.previous and self.previous.name in self.manual:
            choice=layout_for_manual_drag(request,self.previous.name,self.manual[self.previous.name])
        else:
            choice=choose_layout(request,previous=self.previous,manual=self.manual)
        self.previous = choice
        for index,pane in enumerate(self.panes):
            rect = choice.rectangles.get(index)
            if rect is None:
                pane.hide()
            else:
                pane.setGeometry(rect.x,rect.y,rect.w,rect.h)
                pane.show()
        self.update()

    def _near_divider(self,x,y):
        if not self.previous or self.focused is not None:
            return None
        for split_id,axis,parent,handle in self.previous.dividers[::-1]:
            if handle.x-3 <= x <= handle.x+handle.w+3 and handle.y-3 <= y <= handle.y+handle.h+3:
                return split_id,axis,parent
        return None

    def mousePressEvent(self,event):
        if event.button() == Qt.MouseButton.LeftButton:
            hit = self._near_divider(event.position().x(),event.position().y())
            if hit:
                self._drag = hit
                self.grabMouse()
                event.accept()
                return
        super().mousePressEvent(event)

    def mouseMoveEvent(self,event):
        x,y = event.position().x(),event.position().y()
        if self._drag and self.previous:
            split_id,axis,parent = self._drag
            length = max(1, (parent.w if axis=='h' else parent.h)-8)
            position = (x-parent.x if axis=='h' else y-parent.y)
            proportion = max(.10,min(.90, position/length))
            self.manual[self.previous.name] = resize_split(self.previous,split_id,proportion)
            self.preferred = self.previous.name
            self.apply_layout()
            event.accept()
            return
        hit = self._near_divider(x,y)
        new_hover=hit[0] if hit else None
        if self._hover_divider!=new_hover:
            self._hover_divider=new_hover
            self.update()
        if hit:
            self.setCursor(Qt.CursorShape.SplitHCursor if hit[1]=='h' else Qt.CursorShape.SplitVCursor)
        else:
            self.unsetCursor()
        super().mouseMoveEvent(event)

    def mouseReleaseEvent(self,event):
        if self._drag:
            self._drag = None
            self.releaseMouse()
            self.update()
            event.accept()
            return
        super().mouseReleaseEvent(event)

    def event(self,event):
        if event.type() in (QEvent.Type.WindowDeactivate,QEvent.Type.Hide) and self._drag:
            self._drag=None
            if QWidget.mouseGrabber() is self:self.releaseMouse()
            self.unsetCursor()
        return super().event(event)

    def leaveEvent(self,event):
        if self._drag is None:
            self._hover_divider=None
            self.update()
        super().leaveEvent(event)

    def paintEvent(self,event):
        # Draw only in parent workspace gaps. Child HWNDs remain fully opaque.
        p=QPainter(self)
        p.fillRect(self.rect(),QColor('#0B0D10'))
        if self.previous:
            p.setPen(Qt.PenStyle.NoPen)
            for split_id,axis,parent,handle in self.previous.dividers:
                if split_id==self._hover_divider or (self._drag and split_id==self._drag[0]):
                    color=QColor('#45586D')
                else:
                    color=QColor('#1B222A')
                p.setBrush(color)
                p.drawRect(handle.x,handle.y,handle.w,handle.h)
        p.end()
