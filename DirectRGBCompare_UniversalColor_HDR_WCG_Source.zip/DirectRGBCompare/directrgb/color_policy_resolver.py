"""Fail-closed, reproducible color policy decisions.

A successful libmpv option request is not evidence of a verified HDR swapchain.
Renderer and physical-display validation require Windows hardware testing.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
from enum import Enum
import hashlib
import json
from typing import Mapping
from .policy import DIRECT_OPTIONS, direct_eligibility
from .source_color_metadata import SourceColorReport
from .display_capabilities import DisplayCapabilities


class OutputMode(str, Enum):
    LEGACY_SDR = 'Direct RGB SDR — FastStone CMS OFF reference'
    NATIVE_HDR = 'Native HDR / Wide Gamut — EXPERIMENTAL'
    SDR_PREVIEW = 'HDR → SDR Converted Preview'
    SIGNAL = 'Signal Inspector (source values)'


class PolicyError(ValueError):
    pass


@dataclass(frozen=True)
class ResolvedColorPolicy:
    mode: OutputMode
    profile: str
    options: tuple[tuple[str, str], ...]
    transformations: tuple[str, ...]
    status: str
    restrictions: tuple[str, ...]
    source_family: str
    fingerprint: str

    def to_dict(self) -> dict:
        obj = asdict(self)
        obj['mode'] = self.mode.value
        obj['options'] = dict(self.options)
        return obj

    def option_dict(self) -> dict[str, str]:
        return dict(self.options)


def _build(mode, profile, opts, changes, status, restrictions, family):
    pair = tuple(sorted((str(k), str(v)) for k,v in opts.items()))
    manifest = (mode.value, profile, pair, tuple(changes), tuple(restrictions), family)
    fp = hashlib.sha256(json.dumps(manifest, separators=(',',':')).encode()).hexdigest()
    return ResolvedColorPolicy(mode, profile, pair, tuple(changes), status,
                               tuple(restrictions), family, fp)


# Explicit experimental output *requests*, not certification.
# The existing DIRECT_OPTIONS mapping is never mutated.
NATIVE_HDR_EXPERIMENTAL = {
    'd3d11-output-format': 'rgba16f',
    'd3d11-output-csp': 'auto',
    'target-trc': 'scrgb',
    'target-colorspace-hint': 'yes',
    'target-colorspace-hint-mode': 'target',
    'target-peak': 'auto',
}
SDR_CONVERTED_PREVIEW = {
    'd3d11-output-format': 'rgba8',
    'd3d11-output-csp': 'srgb',
    'target-prim': 'bt.709',
    'target-trc': 'bt.1886',
    'target-gamut': 'bt.709',
    'target-peak': '203',
    'tone-mapping': 'bt.2390',
    'gamut-mapping-mode': 'perceptual',
}


def resolve(source: SourceColorReport, mode: OutputMode,
            display: DisplayCapabilities | None = None,
            *, allow_experimental: bool = False,
            allow_dynamic_fallback: bool = False) -> ResolvedColorPolicy:
    """Reject unsupported color interpretations rather than silently falling back.

    `allow_experimental` is an explicit UI/user decision. It cannot certify color.
    Dolby Vision profiles are inspected but not currently decoded/validated in full.
    """
    if not isinstance(mode, OutputMode):
        mode = OutputMode(mode)
    family = source.family
    if mode == OutputMode.LEGACY_SDR:
        accepted, message = direct_eligibility(source.transfer, source.primaries)
        if (not accepted or source.is_hdr or source.is_wide or
                source.confidence == 'conflicting' or
                source.dynamic_metadata or
                any(x['kind'] in ('mastering_display','content_light') for x in source.side_data)):
            raise PolicyError(message or 'Source is not established as legacy SDR; use a separate output mode.')
        return _build(mode, 'legacy_sdr_v1', DIRECT_OPTIONS, (),
                      'SDR POLICY REQUESTED — physical FastStone parity NOT VERIFIED',
                      tuple(x for x in (message, 'Unspecified tags: backend inference, NOT verified' if source.confidence == 'missing' else '') if x), family)

    if mode == OutputMode.SIGNAL:
        return _build(mode, 'source_signal_metadata_v1', {},
                      ('No display transform: metadata and optional raw decoder sample inspection',),
                      'SOURCE SIGNAL ONLY — not color-accurate display output',
                      ('No native video renderer is required for signal inspection',), family)

    if source.confidence == 'conflicting':
        raise PolicyError('Conflicting color metadata; inspect source signal before choosing a display transform.')
    if family in ('unknown', 'camera_log'):
        raise PolicyError('Missing transfer/primaries or camera Log source; no safe display interpretation without explicit validated override.')
    if source.dynamic_metadata:
        if not allow_dynamic_fallback:
            raise PolicyError('Dynamic HDR / Dolby Vision found. Full metadata application is NOT VERIFIED. Opt in to an explicitly labelled base/static fallback.')
        # Dolby Vision profile-specific full decode cannot be represented by
        # static HDR fallback; require a compatible tagged PQ/HLG base layer.
        if 'dolby_vision' in source.dynamic_metadata and source.transfer not in ('smpte2084','pq','st2084','hlg','arib-std-b67'):
            raise PolicyError('Dolby Vision base-layer color transfer not tagged/verified; cannot safely convert this file.')

    warnings = []
    fallback_filter={}
    if source.dynamic_metadata:
        # No unsupported assertion of full DV/HDR10+ output. Disable their
        # metadata in an explicit, individually labelled base/static preview.
        # The pinned mpv must accept the filter; otherwise initialization fails.
        fallback_filter={'vf':'format=dolbyvision=no:hdr10plus=no:enhancement-layer=no:convert=no'}
        warnings.append('Dynamic HDR/Dolby Vision metadata deliberately STRIPPED by requested format filter; decoder output/compatibility NOT VERIFIED')
    if mode == OutputMode.NATIVE_HDR:
        permitted=(display is not None and (
            display.can_attempt_native_hdr if source.is_hdr else display.can_attempt_native_wcg))
        if not permitted:
            raise PolicyError('Windows HDR/WCG mode is not confirmed available on this screen; explicit SDR Preview may be used.')
        if not allow_experimental:
            raise PolicyError('Native HDR output is experimental and swapchain unverified; explicit user opt-in required.')
        # SDR BT.709 panes must remain visible next to HDR/P3 panes in one
        # color-managed scRGB workspace. Their encoding is not HDR; adapt each
        # source independently to the shared display target.
        if not source.is_hdr and not source.is_wide and family!='sdr':
            raise PolicyError('Unknown source encoding; native output cannot be inferred.')
        return _build(mode, 'scRGB_fp16_experimental_v1',
                      {**DIRECT_OPTIONS, **NATIVE_HDR_EXPERIMENTAL, **fallback_filter},
                      ('libmpv GPU-next source → target scRGB transform; display dependent',),
                      ('EXPERIMENTAL HDR — FP16 and physical output NOT VERIFIED' if source.is_hdr
                       else 'EXPERIMENTAL WCG/SDR — FP16 and physical output NOT VERIFIED'),
                      (*warnings, 'Windows Advanced Color query ≠ DXGI output verification'), family)

    if mode == OutputMode.SDR_PREVIEW:
        if not source.is_hdr and not source.is_wide:
            if family!='sdr':
                raise PolicyError('SDR preview workspace cannot infer unknown or Log signal interpretation')
            # Shared SDR target: ordinary SDR clips are NOT tone-mapped.
            # This allows source-faithful SDR beside an explicitly converted HDR pane.
            return _build(mode, 'legacy_sdr_in_mixed_workspace_v1', DIRECT_OPTIONS, (),
                          'SDR SOURCE — unchanged Direct RGB SDR policy in converted workspace',
                          ('FastStone parity of the SDR pane still requires measurement',),family)
        return _build(mode, 'bt2390_bt709_sdr_preview_v1',
                      {**DIRECT_OPTIONS, **SDR_CONVERTED_PREVIEW, **fallback_filter},
                      ('Source range and matrix decode', 'Transfer-function conversion',
                       'Gamut mapping to BT.709', 'BT.2390 tone mapping to 203-nit nominal SDR target',
                       'Output encoded as BT.1886 SDR'),
                      'CONVERTED SDR PREVIEW — NOT original native HDR appearance; target display uncalibrated',
                      (*warnings,'Actual swapchain format and DWM output NOT VERIFIED'), family)
    raise PolicyError('Unknown output mode')
