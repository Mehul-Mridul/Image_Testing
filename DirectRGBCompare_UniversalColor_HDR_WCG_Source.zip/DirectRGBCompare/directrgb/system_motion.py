"""Read-only system animation accessibility preference, when available."""
from __future__ import annotations
import sys


def windows_reduced_motion() -> bool:
    """Windows SPI_GETCLIENTAREAANIMATION, fallback to no override on failure.

    No registry changes, no system setting mutations. False on non-Windows.
    """
    if sys.platform!='win32':return False
    try:
        import ctypes
        enabled=ctypes.c_int(1)
        SPI_GETCLIENTAREAANIMATION=0x1042
        ok=ctypes.windll.user32.SystemParametersInfoW(
            SPI_GETCLIENTAREAANIMATION,0,ctypes.byref(enabled),0)
        return bool(ok) and not bool(enabled.value)
    except (AttributeError,OSError,ValueError):
        return False
