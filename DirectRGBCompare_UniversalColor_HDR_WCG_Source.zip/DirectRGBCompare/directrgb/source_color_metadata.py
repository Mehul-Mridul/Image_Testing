"""Read-only, source-referred color evidence from FFprobe stream/frame/side-data.

This module intentionally does NOT infer HDR mastering from a filename/codec,
claim Dolby Vision processing, or make display decisions.
"""
from __future__ import annotations
from dataclasses import asdict, dataclass
from typing import Any, Mapping

UNKNOWN = frozenset(('', 'unspecified', 'unknown', 'n/a', 'none', 'reserved', 'unavailable'))
PQ = frozenset(('smpte2084', 'pq', 'st2084'))
HLG = frozenset(('arib-std-b67', 'hlg'))
P3 = frozenset(('smpte431', 'smpte432', 'display-p3', 'dci-p3'))
BT2020 = frozenset(('bt2020', 'bt.2020'))
LOG = frozenset(('log', 'log_sqrt', 's-log1', 's-log2', 'v-log'))


def norm(value: Any) -> str:
    return str(value or '').strip().lower()


def known(value: Any) -> bool:
    return norm(value) not in UNKNOWN


def _classify_side_type(item: Mapping[str, Any]) -> str:
    t = norm(item.get('side_data_type'))
    if 'dolby vision' in t or 'dovi' in t:
        return 'dolby_vision'
    if 'hdr dynamic metadata smpte2094-40' in t or 'hdr10+' in t or 'st2094-40' in t:
        return 'hdr10_plus'
    if 'mastering display' in t:
        return 'mastering_display'
    if 'content light level' in t:
        return 'content_light'
    if 'hdr dynamic' in t:
        return 'dynamic_hdr_other'
    return ''


@dataclass(frozen=True)
class SourceColorReport:
    family: str
    confidence: str  # tagged | conflicting | missing, NEVER "verified" from mere tags
    primaries: str
    transfer: str
    matrix: str
    range: str
    pixel_format: str
    bit_depth: str
    codec: str
    profile: str
    side_data: tuple[dict, ...]
    dynamic_metadata: tuple[str, ...]
    dolby_vision_profile: str
    issues: tuple[str, ...]
    provenance: dict

    def to_dict(self) -> dict:
        return asdict(self)

    @property
    def is_hdr(self) -> bool:
        return self.family in ('hdr10_pq', 'hlg', 'pq', 'dolby_vision', 'hdr10_plus')

    @property
    def is_wide(self) -> bool:
        return self.primaries in P3 | BT2020

    @property
    def ambiguous(self) -> bool:
        return self.confidence != 'tagged' or self.family in ('unknown', 'camera_log')


def analyze_probe(data: Mapping[str, Any]) -> SourceColorReport:
    streams = [s for s in data.get('streams', ()) if s.get('codec_type') == 'video']
    if not streams:
        raise ValueError('No video stream for color analysis')
    stream = streams[0]
    frames = [f for f in data.get('frames', ()) if f.get('media_type') == 'video']
    frame = frames[0] if frames else {}
    fmt = data.get('format', {})
    issues = []
    evidence = {}
    for field, stream_key, frame_key in (
        ('primaries', 'color_primaries', 'color_primaries'),
        ('transfer', 'color_transfer', 'color_transfer'),
        ('matrix', 'color_space', 'color_space'),
        ('range', 'color_range', 'color_range'),
    ):
        a, b = norm(stream.get(stream_key)), norm(frame.get(frame_key))
        if known(a) and known(b) and a != b:
            issues.append(f'CONFLICT: {field} stream={a} first_frame={b}')
        evidence[field] = {'stream': a or 'unspecified', 'first_frame': b or 'unspecified'}
    def choose(field):
        a, b = evidence[field]['stream'], evidence[field]['first_frame']
        return b if known(b) else a if known(a) else 'unspecified'
    prim, trc, matrix, color_range = (choose(x) for x in ('primaries', 'transfer', 'matrix', 'range'))

    side = []
    dynamic = set()
    dv_profile = 'unknown'
    seen = set()
    for place, records in (
        ('stream', stream.get('side_data_list', ())),
        ('first_frame', frame.get('side_data_list', ())),
    ):
        for record in records or ():
            kind = _classify_side_type(record)
            if not kind:
                continue
            entry = {'location': place, 'kind': kind, 'fields': dict(record)}
            key = (place, kind, str(record))
            if key not in seen:
                side.append(entry); seen.add(key)
            if kind in ('dolby_vision', 'hdr10_plus', 'dynamic_hdr_other'):
                dynamic.add(kind)
            if kind == 'dolby_vision':
                for name in ('dv_profile', 'dv_bl_signal_compatibility_id', 'rpu_present_flag'):
                    if name in record:
                        entry[name] = record[name]
                if 'dv_profile' in record:
                    dv_profile = str(record['dv_profile'])
    # Certain containers put Dolby Vision configuration in stream objects.
    for key in ('dovi', 'dovi_conf', 'dovi_configuration_record'):
        if isinstance(stream.get(key), dict):
            dynamic.add('dolby_vision')
            side.append({'location': 'stream', 'kind': 'dolby_vision', 'fields': dict(stream[key])})
            dv_profile = str(stream[key].get('dv_profile', dv_profile))
    if trc in PQ:
        family = 'hdr10_pq' if prim in BT2020 else 'pq'
    elif trc in HLG:
        family = 'hlg'
    elif trc in LOG:
        family = 'camera_log'
    elif prim in P3 | BT2020:
        family = 'wide_gamut_sdr' if known(trc) else 'unknown'
    elif known(trc):
        family = 'sdr'
    else:
        family = 'unknown'
    if 'hdr10_plus' in dynamic:
        family = 'hdr10_plus'
    if 'dolby_vision' in dynamic:
        family = 'dolby_vision'
    if 'mastering_display' in {x['kind'] for x in side} and family == 'sdr':
        issues.append('HDR mastering data conflicts with apparently SDR transfer')
    if not known(trc):
        issues.append('Transfer characteristics missing or unspecified')
    if not known(prim):
        issues.append('Color primaries missing or unspecified')
    if not known(matrix):
        issues.append('Color matrix missing or unspecified')
    if dynamic:
        issues.append('Dynamic metadata detected; renderer application and passthrough NOT VERIFIED')
    confidence = 'conflicting' if any(x.startswith('CONFLICT:') or 'conflicts' in x for x in issues) else (
        'missing' if not known(trc) or not known(prim) or not known(matrix) else 'tagged')
    tags = fmt.get('tags') or {}
    return SourceColorReport(
        family, confidence, prim, trc, matrix, color_range,
        norm(stream.get('pix_fmt')) or 'unspecified',
        str(stream.get('bits_per_raw_sample') or 'unspecified'),
        norm(stream.get('codec_name')) or 'unspecified',
        norm(stream.get('profile')) or 'unspecified',
        tuple(side), tuple(sorted(dynamic)), dv_profile, tuple(issues),
        {'field_sources': evidence, 'container_tags_present': sorted(tags.keys()),
         'first_frame_sampled': bool(frames), 'sample_count': len(frames),
         'method': 'ffprobe metadata only; no physical color validation'},
    )


def from_video_metadata(meta: Any) -> SourceColorReport:
    """Fallback for old cached metadata or manually created tests; not evidence of first-frame analysis."""
    return analyze_probe({'streams': [{'codec_type': 'video', 'color_primaries': meta.primaries,
        'color_transfer': meta.transfer, 'color_space': meta.matrix, 'color_range': meta.range,
        'pix_fmt': meta.pix_fmt, 'codec_name': meta.codec,
        'side_data_list': list(meta.hdr_side_data)}], 'frames': []})
