"""Qt chrome motion; does not create graphics effects on native video hosts.

UI animation is a strictly visual concern: a single timer drives a set of
elapsed-time springs; retargeting retains the currently integrated velocity.
"""
from __future__ import annotations
from time import monotonic
from PySide6.QtCore import Qt, QTimer, Signal
from PySide6.QtGui import QColor, QPainter, QPen
from PySide6.QtWidgets import QPushButton, QWidget
from .motion import Spring
from .theme import DEFAULT_THEME, THEMES


class MotionSystem(QWidget):
    """Central UI motion driver: tick only while visible chrome is animating."""
    reducedMotionChanged = Signal(bool)

    def __init__(self,parent=None,reduced_motion=False):
        super().__init__(parent)
        self.setVisible(False)
        self.reduced_motion=bool(reduced_motion)
        self._entries={}
        self._timer=QTimer(self)
        self._timer.setInterval(16)
        self._timer.setTimerType(Qt.TimerType.PreciseTimer)
        self._timer.timeout.connect(self._tick)
        self._last=monotonic()

    def animate(self,key,callback,target,frequency=3.2,damping=1.0):
        item=self._entries.get(key)
        if item is None:
            spring=Spring(value=0.,target=0.,frequency=frequency,damping_ratio=damping)
        else:
            spring=item[0]
        spring.retarget(target,reduced_motion=self.reduced_motion)
        callback(spring.value)
        if self.reduced_motion:
            self._entries.pop(key,None)
            return
        self._entries[key]=(spring,callback)
        if not self._timer.isActive():
            self._last=monotonic()
            self._timer.start()

    def remove(self,key):
        self._entries.pop(key,None)
        if not self._entries:self._timer.stop()

    def set_reduced_motion(self,enabled):
        enabled=bool(enabled)
        if self.reduced_motion==enabled:return
        self.reduced_motion=enabled
        if enabled:
            for key,(spring,callback) in tuple(self._entries.items()):
                spring.step(0.,reduced_motion=True)
                callback(spring.value)
            self._entries.clear();self._timer.stop()
        self.reducedMotionChanged.emit(enabled)

    def _tick(self):
        now=monotonic()
        dt=max(0.,now-self._last)
        self._last=now
        for key,(spring,callback) in tuple(self._entries.items()):
            spring.step(dt)
            callback(spring.value)
            if spring.settled:self._entries.pop(key,None)
        if not self._entries:self._timer.stop()


class FluidButton(QPushButton):
    """Play/transport press feedback: instant on press, spring settle on release.

    Extra paint strokes are confined to Qt button chrome, never video pixels.
    """
    def __init__(self,text='',parent=None,motion=None):
        super().__init__(text,parent)
        self.motion=motion
        self._emphasis=0.
        self._theme=THEMES[DEFAULT_THEME]
        self.setCursor(Qt.CursorShape.PointingHandCursor)
        self.setMinimumHeight(31)

    def set_theme(self,name):
        self._theme=THEMES.get(name,THEMES[DEFAULT_THEME]);self.update()

    def _set_emphasis(self,value):
        self._emphasis=float(value)
        self.update()

    def _target(self,value):
        # Press acknowledgment is instant; release/hover can settle naturally.
        if value>=1.:
            self._set_emphasis(1.)
            if self.motion:self.motion.remove(self)
        elif self.motion:
            self.motion.animate(self,self._set_emphasis,value,frequency=4.8)
        else:self._set_emphasis(value)

    def enterEvent(self,event):
        self._target(.38);super().enterEvent(event)

    def leaveEvent(self,event):
        self._target(0.);super().leaveEvent(event)

    def mousePressEvent(self,event):
        if event.button()==Qt.MouseButton.LeftButton:self._target(1.)
        super().mousePressEvent(event)

    def mouseReleaseEvent(self,event):
        super().mouseReleaseEvent(event)
        self._target(.38 if self.rect().contains(event.position().toPoint()) else 0.)

    def paintEvent(self,event):
        super().paintEvent(event)
        if self._emphasis<=.001:return
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing)
        c=QColor(self._theme.accent)
        c.setAlpha(round(100*self._emphasis))
        p.setPen(QPen(c,1.2));p.setBrush(Qt.BrushStyle.NoBrush)
        p.drawRoundedRect(self.rect().adjusted(1,1,-2,-2),8,8)
        p.end()


class ActivePaneStrip(QWidget):
    """Selection transition is drawn outside the protected video viewport."""
    def __init__(self,motion=None,parent=None):
        super().__init__(parent)
        self.motion=motion
        self._active=0.
        self._theme=THEMES[DEFAULT_THEME]
        self.setFixedHeight(3)
        self.setAttribute(Qt.WidgetAttribute.WA_TransparentForMouseEvents,True)

    def set_theme(self,name):
        self._theme=THEMES.get(name,THEMES[DEFAULT_THEME]);self.update()

    def set_active(self,active):
        target=1. if active else 0.
        if self.motion:self.motion.animate(self,self._set_active,target,frequency=3.5)
        else:self._set_active(target)

    def _set_active(self,value):
        self._active=float(value);self.update()

    def paintEvent(self,event):
        if self._active<=.001:return
        p=QPainter(self);p.setRenderHint(QPainter.RenderHint.Antialiasing)
        color=QColor(self._theme.accent);color.setAlpha(round(220*self._active))
        p.setPen(Qt.PenStyle.NoPen);p.setBrush(color)
        p.drawRoundedRect(self.rect().adjusted(4,0,-4,0),2,2)
        p.end()

class PanelTransitions(QWidget):
    """Reversible 180 ms fade for Qt-only dock *content*, never native video.

    Panel width is controlled instantly by Qt's QDockWidget. The fade uses
    Qt property animation (not a spring) because opacity is a simple scalar.
    Existing animations restart at their live presentation value when reversed.
    """
    def __init__(self,motion,parent=None):
        super().__init__(parent)
        from PySide6.QtCore import QPropertyAnimation,QEasingCurve
        from PySide6.QtWidgets import QGraphicsOpacityEffect
        self._animations={}
        self._effects={}
        self.motion=motion
        self.hide()  # Internal animation coordinator; must not cover any controls.

    def set_visible(self,dock,visible):
        from PySide6.QtCore import QPropertyAnimation,QEasingCurve
        from PySide6.QtWidgets import QGraphicsOpacityEffect
        visible=bool(visible)
        if dock not in self._animations and dock.isVisible()==visible:
            return
        prev=self._animations.pop(dock,None)
        if prev is not None:
            prev.stop();prev.deleteLater()
        content=dock.widget()
        if content is None or self.motion.reduced_motion:
            if dock in self._effects:self._effects[dock].setOpacity(1.)
            dock.setVisible(visible)
            return
        effect=self._effects.get(dock)
        if effect is None:
            effect=QGraphicsOpacityEffect(content)
            effect.setOpacity(1. if dock.isVisible() else 0.)
            content.setGraphicsEffect(effect)
            self._effects[dock]=effect
        origin=effect.opacity() if dock.isVisible() else 0.
        if visible:dock.show()
        animation=QPropertyAnimation(effect,b'opacity',self)
        animation.setDuration(170 if visible else 135)
        animation.setStartValue(origin)
        animation.setEndValue(1. if visible else 0.)
        animation.setEasingCurve(QEasingCurve.Type.OutCubic)
        self._animations[dock]=animation
        def finished():
            if self._animations.get(dock) is not animation:return
            self._animations.pop(dock,None)
            if not visible:dock.hide()
            effect.setOpacity(1.)
            animation.deleteLater()
        animation.finished.connect(finished)
        animation.start()

    def stop(self,dock):
        animation=self._animations.pop(dock,None)
        if animation is not None:
            animation.stop();animation.deleteLater()
        effect=self._effects.get(dock)
        if effect is not None:effect.setOpacity(1.)

    def stop_all(self):
        for dock in tuple(self._animations):self.stop(dock)
