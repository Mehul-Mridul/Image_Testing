"""ffprobe metadata without misleading guesses for missing fields."""
from __future__ import annotations
from dataclasses import dataclass, asdict, field
from fractions import Fraction
from pathlib import Path
import json
from dataclasses import replace
from .paths import bundled_tool
from .process_runner import run_command
from .media_cache import CACHE, MetadataCache
from .policy import classify_hdr, direct_eligibility
from .source_color_metadata import analyze_probe


@dataclass(frozen=True)
class VideoMetadata:
    path: str
    codec: str
    width: int
    height: int
    avg_frame_rate: str
    r_frame_rate: str
    pix_fmt: str
    bit_depth: str
    chroma_subsampling: str
    range: str
    primaries: str
    transfer: str
    matrix: str
    chroma_location: str
    duration: float
    start_time: float
    sar: str
    rotation: str
    hdr: str
    hdr_side_data: list
    first_frame_side_data: list
    first_frame_tags: dict
    color_report: dict = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)

    @property
    def fps(self):
        try:
            f = Fraction(self.avg_frame_rate)
            return float(f) if f.denominator and f.numerator else 0.0
        except (ValueError, ZeroDivisionError):
            return 0.0

    @property
    def eligibility(self):
        base = direct_eligibility(self.transfer, self.primaries)
        if not base[0]:
            return base
        frame = self.first_frame_tags
        frame_transfer = frame.get('color_transfer')
        frame_primaries = frame.get('color_primaries')
        if frame_transfer or frame_primaries:
            override = direct_eligibility(str(frame_transfer or self.transfer),
                                          str(frame_primaries or self.primaries))
            if not override[0]:
                return False, 'Frame-level metadata reports HDR/wide-gamut: ' + override[1]
        for item in self.hdr_side_data + self.first_frame_side_data:
            desc = str(item).lower()
            if any(w in desc for w in ('mastering display metadata',
                                        'content light level', 'hdr10+', 'dynamic hdr')):
                return False, 'HDR side data present despite SDR/unknown stream tags. Output blocked.'
        return base


def _field(value):
    if value is None or str(value).lower() in ('', 'n/a', 'unknown', 'unspecified'):
        return 'Unspecified'
    return str(value)


def _num(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def parse_probe(path: str, data: dict) -> VideoMetadata:
    streams = [s for s in data.get('streams', []) if s.get('codec_type') == 'video']
    if not streams:
        raise ValueError('No video stream in file.')
    stream = streams[0]
    fmt = data.get('format', {})
    pix = str(stream.get('pix_fmt', ''))
    digits = ''.join(ch for ch in pix if ch.isdigit())
    bits = stream.get('bits_per_raw_sample')
    if bits is None and pix in ('yuv420p', 'yuv422p', 'yuv444p', 'nv12', 'rgb24', 'bgr24', 'gbrp'):
        bits = 8
    elif bits is None and digits:
        # e.g. yuv420p10le: may have multiple numbers (420 and 10); use suffix.
        import re
        m = re.search(r'p(\d{2})(?:le|be)$', pix)
        if m:
            bits = int(m.group(1))
    chroma = '4:2:0' if ('420' in pix or pix == 'nv12' or 'p010' in pix) else (
        '4:2:2' if '422' in pix else '4:4:4' if ('444' in pix or pix.startswith('gbr')) else 'Unspecified')
    side = stream.get('side_data_list', [])
    mastering = [x for x in side if any(k in str(x).lower() for k in ('mastering', 'light level', 'hdr', 'dolby'))]
    rotation = 'Unspecified'
    for x in side:
        if 'rotation' in x:
            rotation = str(x['rotation'])
    if rotation == 'Unspecified':
        rotation = _field(stream.get('tags', {}).get('rotate'))
    return VideoMetadata(
        path=str(Path(path).resolve()), codec=_field(stream.get('codec_name')),
        width=int(stream.get('width', 0)), height=int(stream.get('height', 0)),
        avg_frame_rate=_field(stream.get('avg_frame_rate')),
        r_frame_rate=_field(stream.get('r_frame_rate')),
        pix_fmt=_field(pix), bit_depth=_field(bits), chroma_subsampling=chroma,
        range=_field(stream.get('color_range')), primaries=_field(stream.get('color_primaries')),
        transfer=_field(stream.get('color_transfer')), matrix=_field(stream.get('color_space')),
        chroma_location=_field(stream.get('chroma_location')),
        duration=_num(stream.get('duration') or fmt.get('duration')),
        start_time=_num(stream.get('start_time')),
        sar=_field(stream.get('sample_aspect_ratio')),
        rotation=rotation,
        hdr=classify_hdr(str(stream.get('color_transfer') or ''), str(stream.get('color_primaries') or '')),
        hdr_side_data=mastering,
        first_frame_side_data=[],
        first_frame_tags={},
        color_report=analyze_probe(data).to_dict(),
    )


def probe_file_with_status(path: str, timeout=25, *, cancel_event=None) -> tuple[VideoMetadata,bool]:
    """Run one bounded FFprobe for stream, container AND first-frame HDR tags.

    The cache stores the FULL validation result; a video is never accepted on
    cached container tags alone. Failed probe results are not cached.
    """
    executable = bundled_tool('ffprobe')
    executable_info = Path(executable).stat()
    probe_version = f'{executable}:{executable_info.st_size}:{executable_info.st_mtime_ns}'
    key = MetadataCache.key(path, probe_version=probe_version + ':color_report_schema_v1')
    previous = CACHE.get(key)
    if previous is not None:
        return previous, True
    cmd = [executable, '-v', 'error', '-select_streams', 'v:0',
           '-read_intervals', '0%+#1', '-show_streams', '-show_format',
           '-show_frames', '-of', 'json', str(path)]
    result = run_command(cmd, timeout=timeout, cancel_event=cancel_event)
    if result.returncode:
        raise RuntimeError(f'ffprobe failed: {result.stderr.decode(errors="replace")[:800]}')
    try:
        data = json.loads(result.stdout)
    except (ValueError, UnicodeError) as exc:
        raise RuntimeError('FFprobe returned invalid JSON') from exc
    meta = parse_probe(path, data)
    frames = [f for f in data.get('frames',[]) if f.get('media_type') == 'video']
    if not frames:
        raise RuntimeError('FFprobe could not inspect a first video frame; SDR eligibility is unverified.')
    f = frames[0]
    keys = ('best_effort_timestamp_time', 'color_range', 'color_space',
            'color_primaries', 'color_transfer', 'chroma_location', 'pict_type')
    meta = replace(meta, first_frame_side_data=f.get('side_data_list', []),
                   first_frame_tags={k:f[k] for k in keys if k in f})
    CACHE.put(key,meta)
    return meta, False


def probe_file(path: str, timeout=25, *, cancel_event=None) -> VideoMetadata:
    return probe_file_with_status(path, timeout, cancel_event=cancel_event)[0]
