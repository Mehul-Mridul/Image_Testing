Adaptive Workspace / Fast Loading source upgrade

1. Extract the entire PATCH ZIP (do not run from archive preview).
2. Run APPLY_ADAPTIVE_UPGRADE.bat. The script locates your existing vNext project,
   or asks for its folder. It verifies the strict RGB baseline, backs up changed
   source files, and copies/validates the new source modules.
3. Rebuild your EXE using your project's build_windows.bat.
4. Run CHECK_ADAPTIVE_GUI.bat and CHECK_WINDOWS_GUI.bat on your Windows PC.

The current compiled EXE is NOT automatically replaced. Python/FFmpeg/libmpv
are not included in this patch; they remain in your original project.

Only offline tests ran in the authoring environment. FastStone color identity,
4K performance, and Windows GUI remain unverified.
