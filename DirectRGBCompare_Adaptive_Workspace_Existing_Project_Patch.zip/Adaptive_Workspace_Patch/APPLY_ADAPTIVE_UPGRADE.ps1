param([string]$ProjectPath = '')
$ErrorActionPreference='Stop'
$repairRoot=(Resolve-Path (Split-Path -Parent $MyInvocation.MyCommand.Path)).Path
$payload=Join-Path $repairRoot 'payload'
if (!(Test-Path -LiteralPath (Join-Path $payload 'directrgb\vnext_gui.py'))) {
    throw 'Incomplete patch ZIP. Extract the entire upgrade folder first.'
}
$downloads=Join-Path $env:USERPROFILE 'Downloads'
$candidates=@()
if ($ProjectPath) {$candidates += $ProjectPath}
$candidates+=@(
    $repairRoot,
    (Join-Path $repairRoot 'DirectRGBCompare'),
    (Join-Path $downloads 'DirectRGBCompare_vNext_Full_Source\DirectRGBCompare'),
    (Join-Path $downloads 'DirectRGBCompare_vNext\DirectRGBCompare'),
    (Join-Path $downloads 'DirectRGBCompare_Windows_Source_v5\DirectRGBCompare')
)
$project=$null
foreach($candidate in $candidates){
    if (!$candidate) {continue}
    if ((Test-Path -LiteralPath (Join-Path $candidate 'run.py')) -and
        (Test-Path -LiteralPath (Join-Path $candidate 'directrgb\vnext_gui.py'))) {
        $project=(Resolve-Path -LiteralPath $candidate).Path
        break
    }
}
if (!$project) {
    $entered=Read-Host 'Project not automatically found. Paste your existing DirectRGBCompare project folder path'
    if ($entered -and (Test-Path -LiteralPath (Join-Path $entered 'directrgb\vnext_gui.py'))) {
        $project=(Resolve-Path -LiteralPath $entered).Path
    } else {throw 'No valid DirectRGBCompare vNext project directory was selected.'}
}
Write-Host "Upgrading project: $project" -ForegroundColor Cyan
$expectedCore=@{
  'policy.py'='aa373c95266e5c45daadd11be620d60be9acda5931ef2eda71c4706825d89c5e'
  'mpv_native.py'='4d2cbe47de440178d38550798fc07ab2a02f000774fdff8c7dee24e8649c8424'
  'validation.py'='b39cc37f1ea8e0a5a9067ac6a1551365a4b56cd923ea71f367a7c7d3e5ffd5da'
  'color_math.py'='ed0904edc1c1989a879e88a450790cf020e71a4d39ddd5c853699166bbc18a3c'
}
foreach ($key in $expectedCore.Keys){
    $file=Join-Path $project (Join-Path 'directrgb' $key)
    if (!(Test-Path -LiteralPath $file)){throw "Missing strict RGB core file: $file"}
    $hash=(Get-FileHash -LiteralPath $file -Algorithm SHA256).Hash.ToLowerInvariant()
    if($hash -ne $expectedCore[$key]){throw "RGB core is not the known baseline ($key). Nothing changed. Use full source package or inspect your modifications."}
}
$baselines=Get-Content -LiteralPath (Join-Path $repairRoot 'BASELINE_HASHES.json') -Raw | ConvertFrom-Json
$sourceFiles=@(Get-ChildItem -LiteralPath $payload -Recurse -File)
$pending=@()
foreach($source in $sourceFiles){
    $rel=$source.FullName.Substring($payload.Length+1)
    $target=Join-Path $project $rel
    if(Test-Path -LiteralPath $target){
        $actual=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
        if($rel.StartsWith('directrgb\') -and ($baselines.PSObject.Properties.Name -contains ($rel.Replace('\','/')))){
            $baseline=$baselines.($rel.Replace('\','/'))
            $patchHash=(Get-FileHash -LiteralPath $source.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
            if($actual -ne $baseline -and $actual -ne $patchHash){
                throw "Unexpected modified source: $rel. Nothing changed. Back up your custom changes or use the full source package."
            }
        }
    }
    $pending+=@([pscustomobject]@{Source=$source.FullName;Relative=$rel;Target=$target})
}
$backup=Join-Path $project ('backup\adaptive-upgrade-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Force -Path $backup | Out-Null
$copied=@()
try {
    foreach($entry in $pending){
        if(Test-Path -LiteralPath $entry.Target){
            $backupPath=Join-Path $backup $entry.Relative
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $backupPath) | Out-Null
            Copy-Item -LiteralPath $entry.Target -Destination $backupPath -Force
        }
    }
    foreach($entry in $pending){
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $entry.Target) | Out-Null
        Copy-Item -LiteralPath $entry.Source -Destination $entry.Target -Force
        $srcHash=(Get-FileHash -LiteralPath $entry.Source -Algorithm SHA256).Hash.ToLowerInvariant()
        $dstHash=(Get-FileHash -LiteralPath $entry.Target -Algorithm SHA256).Hash.ToLowerInvariant()
        if($srcHash -ne $dstHash){throw "Copy verification failed: $($entry.Relative)"}
        $copied+=@($entry)
    }
} catch {
    foreach($entry in $copied){
        $back=Join-Path $backup $entry.Relative
        if(Test-Path -LiteralPath $back){Copy-Item -LiteralPath $back -Destination $entry.Target -Force}
        elseif(Test-Path -LiteralPath $entry.Target){Remove-Item -LiteralPath $entry.Target -Force}
    }
    throw
}
Write-Host ('SUCCESS: Updated '+$pending.Count+' source/test/documentation files.') -ForegroundColor Green
Write-Host "Backup: $backup"
$python=Join-Path $project '.venv\Scripts\python.exe'
if(Test-Path -LiteralPath $python){
    Push-Location $project
    try {
        & $python -m pytest -q tests
        if($LASTEXITCODE -ne 0){Write-Warning 'Tests failed on Windows; examine failures and do not approve this release.'}
    } finally {Pop-Location}
} else {Write-Warning 'No .venv Python found: unit tests and build must run after setup.'}
Write-Host 'Rebuild using build_windows.bat; run CHECK_ADAPTIVE_GUI.bat on Windows.'
Write-Host 'The current EXE is NOT overwritten by this source patch.'
