@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY_ADAPTIVE_UPGRADE.ps1"
if errorlevel 1 (echo Upgrade failed. See output above. & pause & exit /b 1)
echo Source upgrade completed. Run build_windows.bat in the updated project folder.
pause
