# vNext browser recovery after Adaptive Workspace upgrade

## Confirmed source issues

* Previous adaptive package `AppSettings` defaulted `browser_visible` to `False`, and the GUI used this setting to hide the entire folder-browser dock. This made the older vNext file selection interface appear missing.
* The patch upgraded Python source files but did not rebuild the already-compiled executable. Running an old `dist\DirectRGBCompare\DirectRGBCompare.exe` therefore cannot verify new UI features.
* Folder navigation in QFileSystemModel is asynchronous; the browser now updates its root again on `directoryLoaded` when the folder matches the current selection.

## Recovery behavior

* Browser shown once during settings migration; users can subsequently choose to hide it and that preference persists.
* `Ctrl+B`: toggle the file browser. `Ctrl+Shift+R`: unconditionally restore and raise the file browser.
* `Ctrl+Shift+O`: open folder. `Ctrl+L`: load current multi-selection. The original vNext comparison sets, shortcuts, synchronized zoom/pan and Sync Here remain in `vnext_gui.py`.
* `LAUNCH_CURRENT_SOURCE_DEBUG.bat`: launch source directly, print imported module path and errors to distinguish stale EXE from updated source.
* `CHECK_BROWSER_UI.bat`: Windows-only interactive widget smoke test with isolated settings; does not test decoded video or numeric RGB output.

## Qualification

80 offline Python tests passed in the Linux environment. Windows PySide6 GUI, D3D11, full comparison, and FastStone CMS-OFF RGB equivalence remain unverified. No changes to `policy.py`, `mpv_native.py`, `color_math.py` or `validation.py`.
