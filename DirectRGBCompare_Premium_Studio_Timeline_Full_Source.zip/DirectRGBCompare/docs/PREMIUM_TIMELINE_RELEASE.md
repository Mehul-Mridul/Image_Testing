# DirectRGB Compare — Premium Studio / Mixed-Duration Timeline

**Status:** Windows-oriented source implementation; Python 3.12+ offline
unit checks available. This release has **not** been executed with a native
Windows libmpv/D3D11 renderer in the authoring environment.

## User-facing changes

- **Global duration = last visible clip endpoint.** With no synchronization
  offsets this is exactly the length of the longest loaded clip. With manually
  aligned clips, each pane's actual comparison end is `duration - offset`.
  The master chosen for manual Sync Here can be shorter than another pane.
- **Independent monotonic group clock.** The entire comparison does not freeze
  when a shorter *master* video reaches its EOS. Only a paused/stopped global
  timeline or the end of the latest clip stops the overall playback.
- **Shorter videos pause and retain their last available frame best-effort**
  using the frozen libmpv `keep-open=yes` policy; an explicit seek just inside
  the probed end is issued once at the transition to Ended. Exact final-frame
  identity is NOT asserted for VFR sources.
- **Seeking past a short video** clamps its local seek to just inside EOS and
  labels its pane `Ended`. Seeking back restores its Active state.
- **Timeline end ticks:** each pane is represented by a restrained colored end
  marker on the master scrubber. The numeric time is shown in `MM:SS.mmm`.
- **Transport:** a slim dark timeline with a high-contrast play button and
  frame-step actions, alongside the existing Home/End controls.
- **Premium Studio visual shell:** Graphite (default), Obsidian and Midnight
  themes, a new slim command bar, contextual Workspace menu, refined file
  browser, panes, dock panels and status indicators, and restrained translucent
  chrome (faux glass, *not* Windows acrylic compositing across video).
- **No feature regression intended:** Folder browsing, replacement loading,
  comparison sets, shortcuts, manual Sync Here, adaptive sizing, focus, native
  view zoom/pan and diagnostic logging remain accessible.

## Architecture

- `directrgb/timeline_controller.py`: Qt-free, independently unit-tested
  `ComparisonTimeline` (monotonic time, speed, pause, seek, per-clip offsets,
  durations and end flags). Never uses master libmpv `time-pos` to advance the
  global clock.
- `directrgb/theme.py`: pure palette tokens.
- `directrgb/styles.py`: Qt stylesheet generator; styling applies to UI chrome.
- `directrgb/timeline_widget.py`: custom QSlider/QPainter timeline; does not
  render video and is DPI-aware through Qt coordinates.
- `directrgb/premium_ui.py`: Qt toolbar/transport composition and theme actions.
- `directrgb/vnext_gui.py`: integrates the independent clock and premium UI
  while retaining the existing loading, browser, adaptive layout and
  diagnostic architecture.

## Known limits and decisions

1. Independent monotonic clock is not hard genlock. Video PTS differences are
   monitored and corrected with throttled seeking. Neither this nor manual
   Sync Here should be represented as exact synchronized GPU presentation.
2. Probed stream durations, nonzero source start time, VFR final-frame
   boundaries, and metadata inaccuracies need separate real-media Windows tests.
3. Qt stylesheet, faux glass and custom timeline operate on **interface chrome
   only**. The native HWND video-rendering surface must not receive effects.
4. The source package contains no precompiled Windows EXE. `build_windows.bat`
   requires a Windows system and provisioned binaries.
5. HDR and wide-gamut input remains blocked by strict SDR validation.
6. No before/after GPU framebuffer or FastStone comparison was possible in
   the authoring environment; its equivalence is unverified.
7. Qt GUI tests must run under Windows using `CHECK_PREMIUM_GUI.bat`. They
   check shell construction, theme switching, 1–4 pane switching and synthetic
   timeline state, not actual RGB output.

## Manual Windows test matrix — MUST perform before production use

| Test | Status |
|---|---|
| Windows EXE startup / font and glass appearance | NOT VERIFIED |
| File browser, Ctrl+B, Ctrl+L and repeated replacement | NOT VERIFIED |
| Two videos: 2s + 8s; short master, play until 8s | NOT VERIFIED |
| Three videos: 3s + 5s + 9s; seek to 7s | NOT VERIFIED |
| Four 4K/portrait clips of mixed duration | NOT VERIFIED |
| Ended pane retains last displayed frame; rewind resumes | NOT VERIFIED |
| Same-video 2/3/4 pane renderer RGB capture | NOT VERIFIED |
| FastStone CMS OFF numeric comparison | NOT VERIFIED |
| Ctrl+PgDown sets and custom shortcuts | NOT VERIFIED |
| No subprocess CMD flashes | NOT VERIFIED |

## Upgrade procedure

Safest: extract full source to a separate folder, copy verified native runtime
files into `vendor/bin/` as instructed by `RUN_FIRST.bat`, and build on Windows.
Do not overwrite a working EXE before testing. The patch ZIP provides an
optional guarded source-only update and backup.
