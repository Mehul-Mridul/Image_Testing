"""Source/setting invariants. Actual Qt test is Windows-only."""
from pathlib import Path
from directrgb.app_settings import AppSettings

ROOT=Path(__file__).resolve().parents[1]


def test_new_settings_show_browser(tmp_path):
    settings=AppSettings(tmp_path/'settings.json')
    assert settings.data['browser_visible'] is True
    assert settings.data['ui_recovery_applied'] is True
    assert settings.path.is_file()


def test_upgrade_hidden_browser_is_recovered_once(tmp_path):
    import json
    p=tmp_path/'settings.json'
    p.write_text(json.dumps({'schema':1,'browser_visible':False,'last_folder':'',
                             'shortcuts':{},'recursive_scan':False}),encoding='utf8')
    upgraded=AppSettings(p)
    assert upgraded.data['browser_visible'] is True
    upgraded.data['browser_visible']=False
    upgraded.save()
    saved=AppSettings(p)
    assert saved.data['browser_visible'] is False
    assert saved.data['ui_recovery_applied'] is True


def test_ui_source_contains_explicit_browser_restoration():
    gui=(ROOT/'directrgb/vnext_gui.py').read_text(encoding='utf8')
    assert 'def restore_browser_workspace(self):' in gui
    assert "('view.recover_browser','Restore File Browser','Ctrl+Shift+R'" in gui
    assert 'self.browser_dock.setVisible(True)' in gui
    assert 'self.browser_dock.raise_()' in gui
    browser=(ROOT/'directrgb/file_browser.py').read_text(encoding='utf8')
    assert 'self.model.directoryLoaded.connect(self._directory_ready)' in browser
    assert 'self.model.setRootPath(target)' in browser


def test_compatibility_source_main_still_vnext():
    assert 'from directrgb.vnext_gui import run' in (ROOT/'run.py').read_text()
