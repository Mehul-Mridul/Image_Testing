"""Deterministic playback horizon and EOS behavior without any Qt or GPU."""
from dataclasses import dataclass
import pytest
from directrgb.timeline_controller import (ClipRange, ComparisonTimeline,
    duration_horizon, clip_position)


@dataclass
class FakeClock:
    seconds: float = 0.
    def __call__(self):return self.seconds
    def advance(self,t):self.seconds+=t


def test_max_duration_not_selected_master():
    clock=FakeClock()
    timeline=ComparisonTimeline(clock)
    timeline.configure({0:ClipRange(2),1:ClipRange(7),2:ClipRange(4)})
    assert timeline.duration==7
    timeline.play();clock.advance(2.5)
    assert timeline.current()==2.5
    assert timeline.position_for(0).state=='ended'
    assert timeline.position_for(1).state=='active'
    clock.advance(4.5)
    assert timeline.current()==7
    assert timeline.position_for(1).state=='ended'
    assert timeline.end_reached()


def test_paused_clock_and_play_speed_preserved_during_seek():
    clock=FakeClock()
    timeline=ComparisonTimeline(clock)
    timeline.configure({0:ClipRange(4),1:ClipRange(12)})
    timeline.play();clock.advance(1)
    assert timeline.current()==1
    timeline.change_speed(2)
    clock.advance(2)
    assert timeline.current()==5
    timeline.seek(9)
    clock.advance(.5)
    assert timeline.current()==10
    timeline.pause();clock.advance(20)
    assert timeline.current()==10
    timeline.seek(-2)
    assert timeline.current()==0
    timeline.play();clock.advance(.5)
    assert timeline.current()==1


def test_end_markers_and_seek_clamping():
    clips={0:ClipRange(2),1:ClipRange(8),2:ClipRange(3),3:ClipRange(5)}
    timeline=ComparisonTimeline(FakeClock())
    timeline.configure(clips)
    timeline.seek(5)
    assert timeline.position_for(0).state=='ended'
    assert 1.96 <= timeline.position_for(0).target < 2
    assert timeline.position_for(1).state=='active'
    assert timeline.position_for(2).state=='ended'
    assert timeline.position_for(3).state=='ended'
    timeline.seek(800)
    assert timeline.current()==8
    for i in clips:assert timeline.position_for(i).state=='ended'
    timeline.seek(1)
    assert all(timeline.position_for(i).state=='active' for i in clips)


def test_signed_offsets_expand_effective_global_horizon():
    clips={0:ClipRange(7,0),1:ClipRange(4,-3),2:ClipRange(2,1)}
    assert duration_horizon(clips)==7
    assert clip_position(1,clips[1]).state=='before'
    assert clip_position(3,clips[1]).state=='active'
    assert clip_position(7,clips[1]).state=='ended'
    assert clip_position(0,clips[2]).target==1
    assert duration_horizon({0:ClipRange(3,-4)})==7


def test_zero_and_invalid_durations_fail_closed():
    timeline=ComparisonTimeline(FakeClock())
    timeline.configure({0:ClipRange(0),1:ClipRange(float('nan')),2:ClipRange(float('inf'))})
    assert timeline.duration==0
    assert timeline.position_for(0).state=='unavailable'
    timeline.play()
    assert not timeline.playing
    with pytest.raises(ValueError):timeline.seek(float('nan'))
    with pytest.raises(ValueError):timeline.change_speed(-1)


def test_rewind_from_end_reenters_active_range():
    clock=FakeClock()
    timeline=ComparisonTimeline(clock)
    timeline.configure({0:ClipRange(1),1:ClipRange(5)})
    timeline.play();clock.advance(5)
    assert timeline.end_reached()
    timeline.pause()
    timeline.seek(.25)
    assert timeline.position_for(0).state=='active'
    timeline.play();clock.advance(.5)
    assert timeline.current()==pytest.approx(.75)


def test_reconfiguration_preserves_global_position_until_new_horizon():
    clock=FakeClock()
    timeline=ComparisonTimeline(clock)
    timeline.configure({0:ClipRange(2),1:ClipRange(7)})
    timeline.seek(6)
    timeline.configure({0:ClipRange(3),1:ClipRange(8)})
    assert timeline.current()==6
    timeline.configure({0:ClipRange(2)})
    assert timeline.current()==2


def test_unknown_duration_does_not_hide_valid_clips():
    assert duration_horizon({0:ClipRange(float('nan')),1:ClipRange(9)})==9
    assert clip_position(5,ClipRange(-1)).state=='unavailable'


def test_active_offset_edit_changes_horizon_without_clock_jump():
    clock=FakeClock()
    t=ComparisonTimeline(clock)
    t.configure({0:ClipRange(2),1:ClipRange(6)})
    t.play();clock.advance(1.75)
    before=t.current()
    t.configure({0:ClipRange(2,-2),1:ClipRange(6,0)})
    assert t.current()==pytest.approx(before)
    assert t.duration==6
    t.configure({0:ClipRange(2,-6),1:ClipRange(6,0)})
    assert t.duration==8
    clock.advance(1)
    assert t.current()==pytest.approx(before+1)
