"""Offline source checks. Actual UI must run on Windows before certification."""
from pathlib import Path
import ast
import hashlib
import zipfile
import pytest

ROOT=Path(__file__).resolve().parents[1]
UI=(ROOT/'directrgb/vnext_gui.py').read_text(encoding='utf8')
SHELL=(ROOT/'directrgb/premium_ui.py').read_text(encoding='utf8')
STYLE=(ROOT/'directrgb/styles.py').read_text(encoding='utf8')


def test_no_inherited_master_video_tick():
    tree=ast.parse(UI)
    window=next(x for x in tree.body if isinstance(x,ast.ClassDef) and x.name=='MainWindow')
    methods={x.name:x for x in window.body if isinstance(x,(ast.FunctionDef,ast.AsyncFunctionDef))}
    assert 'comparison_timeline' in UI
    assert '_refresh_timeline_model' in methods
    assert '_tick' in methods
    tick=ast.get_source_segment(UI,methods['_tick'])
    assert 'super()._tick()' not in tick
    assert 'comparison_timeline.current()' in tick
    assert 'end_reached()' in tick
    assert 'self._last_sync_seek' in UI


def test_shorter_media_end_hold_and_seek():
    assert 'last frame held (best effort)' in UI
    assert 'seek clamped at video end' in UI
    assert "self.timeline.set_end_marks(marks)" in UI
    assert 'self._end_states.clear()' in UI


def test_file_browser_and_recovered_shortcuts_preserved():
    for command in ('file.open_folder','file.load_selected','set.next','set.previous',
                    'view.recover_browser','view.pane_tools','sync.here','diag.toggle'):
        assert f"'{command}'" in UI
    assert "self.browser_dock.setVisible" in UI
    assert 'self.navigator' in UI


def test_qt_chrome_styles_are_separate_from_render_pipeline():
    assert "window.setStyleSheet(make_stylesheet(name))" in SHELL
    assert 'set_theme' in SHELL
    assert 'QFrame#videoHost' in STYLE
    assert 'QGraphicsBlurEffect' not in SHELL
    assert 'QGraphicsOpacityEffect' not in SHELL
    assert 'QGraphicsDropShadowEffect' not in SHELL
    for f in ('policy.py','mpv_native.py','color_math.py','validation.py'):
        assert (ROOT/'directrgb'/f).is_file()


def test_palette_options_and_timeline_are_bundled():
    from directrgb.theme import THEMES,DEFAULT_THEME
    from directrgb.styles import make_stylesheet
    assert set(THEMES)=={'Graphite','Obsidian','Midnight'}
    assert DEFAULT_THEME in THEMES
    for name in THEMES:
        s=make_stylesheet(name)
        assert 'QFrame#pane' in s
        assert 'QToolBar' in s
        assert 'QDockWidget' in s
