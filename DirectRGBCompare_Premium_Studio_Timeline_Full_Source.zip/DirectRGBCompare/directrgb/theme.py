"""Premium SDR inspection UI tokens. Only GUI chrome uses these colors.

Never put the Qt stylesheet on the native video host renderer itself.
"""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class Theme:
    name: str
    background: str
    surface: str
    raised: str
    elevated: str
    border: str
    text: str
    muted: str
    accent: str
    accent_soft: str
    success: str = '#65C6A5'
    warning: str = '#E7B46B'
    danger: str = '#E78C92'


THEMES = {
    'Graphite': Theme('Graphite','#0C0E12','#151A21','#1D242D','#27313D','#354151','#E9EEF4','#A0AFBE','#78B7E6','#183548'),
    'Obsidian': Theme('Obsidian','#090A0D','#121316','#1A1D23','#292E37','#363B45','#F0F0F2','#A4A8B0','#A3B7D6','#273442'),
    'Midnight': Theme('Midnight','#0A101A','#101B2A','#18253A','#24344E','#314866','#E8F1FA','#A1B5D0','#8BAFF8','#1B345D'),
}
DEFAULT_THEME = 'Graphite'
