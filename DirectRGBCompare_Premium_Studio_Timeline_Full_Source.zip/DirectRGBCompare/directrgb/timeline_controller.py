"""Global monotonic comparison timeline independent of any particular mpv pane.

Times are seconds on a *comparison* axis. Local clip time = global time +
its signed sync offset. The visible horizon is the latest local clip endpoint
transformed to that axis. Unknown/invalid durations never extend the horizon.
"""
from __future__ import annotations
from dataclasses import dataclass
from math import isfinite
from time import monotonic
from typing import Callable


@dataclass(frozen=True)
class ClipRange:
    duration: float
    offset: float = 0.0
    fps: float = 0.0


@dataclass(frozen=True)
class ClipPosition:
    target: float
    state: str  # before, active, ended, unavailable
    last_frame_target: float


def duration_horizon(clips: dict[int, ClipRange]) -> float:
    ends = [(c.duration - c.offset) for c in clips.values()
            if isfinite(c.duration) and c.duration > 0 and isfinite(c.offset)]
    return max([0.0, *ends])


def clip_position(global_time: float, clip: ClipRange) -> ClipPosition:
    if not isfinite(clip.duration) or clip.duration <= 0 or not isfinite(clip.offset):
        return ClipPosition(0., 'unavailable', 0.)
    # Seek slightly *inside* the source duration at EOS. Exact duration can be
    # past the last decoded frame, particularly for VFR and nonzero start PTS.
    # This is a best-effort hold, not a claim of exact last-frame seeking.
    margin = min(0.04, 0.25/clip.fps) if clip.fps > 0 and isfinite(clip.fps) else 0.02
    last = max(0., clip.duration - margin)
    local = global_time + clip.offset
    if local < 0:
        return ClipPosition(0., 'before', last)
    if local >= clip.duration - 1e-7:
        return ClipPosition(last, 'ended', last)
    return ClipPosition(max(0., local), 'active', last)


class ComparisonTimeline:
    """Seek, play and pause with a single monotonic global authority.

    Never advances using an individual media file's ``time-pos`` because the
    selected master may be shorter than other panes. Caller owns mpv commands.
    """
    def __init__(self, clock: Callable[[], float] = monotonic):
        self.clock = clock
        self.clips: dict[int, ClipRange] = {}
        self.position = 0.0
        self.duration = 0.0
        self.speed = 1.0
        self.playing = False
        self._base_position = 0.0
        self._base_tick = clock()

    def configure(self, clips: dict[int, ClipRange]):
        now = self.current()
        self.clips = dict(clips)
        self.duration = duration_horizon(clips)
        self.seek(min(now, self.duration))

    def current(self) -> float:
        if not self.playing:
            return self.position
        return min(self.duration, max(0., self._base_position +
                          (self.clock() - self._base_tick)*self.speed))

    def seek(self, t: float) -> float:
        if not isfinite(t):
            raise ValueError('Non-finite comparison position')
        self.position = min(self.duration, max(0., float(t)))
        self._base_position = self.position
        self._base_tick = self.clock()
        return self.position

    def pause(self) -> float:
        self.position = self.current()
        self.playing = False
        return self.position

    def play(self) -> float:
        if not self.clips or self.duration <= 0:
            return self.position
        if self.current() >= self.duration:
            self.seek(0.)
        self._base_position = self.current()
        self._base_tick = self.clock()
        self.playing = True
        return self.current()

    def change_speed(self, speed: float):
        if not isfinite(speed) or speed <= 0:
            raise ValueError('Playback speed must be finite and positive')
        self.seek(self.current())
        self.speed = float(speed)

    def position_for(self, idx: int, at: float | None = None) -> ClipPosition:
        return clip_position(self.current() if at is None else at, self.clips[idx])

    def end_reached(self) -> bool:
        return bool(self.clips) and self.current() >= self.duration
