"""Original dark creative-workspace shell. Only widget chrome is styled.

Avoid Qt graphics effects or transparent native surfaces over the HWND video
viewport; DWM/material effects are never allowed to interfere with RGB checks.
"""
from __future__ import annotations
from PySide6.QtCore import Qt
from PySide6.QtWidgets import (QToolBar,QLabel,QToolButton,QComboBox,QMenu,QWidget,
    QHBoxLayout,QPushButton)
from .theme import THEMES,DEFAULT_THEME
from .styles import make_stylesheet
from .timeline_widget import PremiumTimeline


def create_premium_toolbar(window):
    """Retire old utility toolbars but retain their controls for legacy APIs."""
    for bar in window.findChildren(QToolBar):
        if bar.windowTitle()=='Comparison controls':
            bar.hide()
    toolbar=window.addToolBar('DirectRGB Studio')
    toolbar.setObjectName('premiumToolbar')
    toolbar.setMovable(False)
    brand=QLabel('◈  DirectRGB',toolbar)
    brand.setObjectName('branding')
    brand.setToolTip('SDR Inspection · Direct RGB mode (not FastStone-certified)')
    toolbar.addWidget(brand)
    toolbar.addAction(window.actions.actions['file.open_folder'])
    toolbar.addAction(window.actions.actions['file.load_selected'])
    load_action=window.actions.actions['file.load_selected']
    # Actions can appear as QToolButtons in the toolbar; give one clear CTA.
    for b in toolbar.findChildren(QToolButton):
        if b.defaultAction() is load_action:b.setObjectName('primaryAction')
    toolbar.addAction(window.actions.actions['view.browser'])
    toolbar.addSeparator()
    toolbar.addAction(window.actions.actions['set.previous'])
    window.set_label=QLabel('Set: none')
    window.set_label.setObjectName('muted')
    toolbar.addWidget(window.set_label)
    toolbar.addAction(window.actions.actions['set.next'])
    toolbar.addSeparator()
    pane_count=QComboBox(toolbar)
    pane_count.setToolTip('Number of visible comparison panes')
    pane_count.addItems(['1 pane','2 panes','3 panes','4 panes'])
    pane_count.setCurrentIndex(window.layout_combo.currentIndex())
    pane_count.currentIndexChanged.connect(window.layout_combo.setCurrentIndex)
    window.layout_combo.currentIndexChanged.connect(pane_count.setCurrentIndex)
    window.premium_pane_count=pane_count
    toolbar.addWidget(pane_count)
    toolbar.addAction(window.actions.actions['sync.here'])
    window.sync_status_label=QLabel('Sync: not anchored')
    window.sync_status_label.setObjectName('muted')
    window.sync_status_label.setToolTip('A time-pos-based alignment is provisional; verify actual frame correspondence')
    toolbar.addWidget(window.sync_status_label)
    toolbar.addSeparator()

    # Group lower-frequency controls into one accessible menu, no loss of features.
    menu=QMenu('Workspace',window)
    file_menu=menu.addMenu('Files and sets')
    file_menu.addAction(window.actions.actions['file.open_videos'])
    file_menu.addAction(window.actions.actions['file.append_selected'])
    file_menu.addSeparator()
    file_menu.addAction('Create sequential sets',window.group_sequential)
    file_menu.addAction('Group by filename…',window.group_pattern)
    view_menu=menu.addMenu('View')
    for key in ('view.recover_browser','view.focus','view.auto_layout','view.pane_tools',
                'view.advanced','view.fullscreen','view.fit','view.native','view.200','view.reset'):
        view_menu.addAction(window.actions.actions[key])
    diag_menu=menu.addMenu('Inspection')
    diag_menu.addAction(window.actions.actions['diag.toggle'])
    diag_menu.addAction('Export diagnostics…',window.export_diagnostics)
    diag_menu.addAction(window.actions.actions['commands.help'])
    themes_menu=menu.addMenu('Appearance')
    for name in THEMES:
        action=themes_menu.addAction(name)
        action.triggered.connect(lambda checked=False,n=name: apply_theme(window,n))
    trigger=QToolButton(toolbar)
    trigger.setText('Workspace  ▾')
    trigger.setToolTip('Layout, sets, diagnostics, themes and shortcuts')
    trigger.setPopupMode(QToolButton.ToolButtonPopupMode.InstantPopup)
    trigger.setMenu(menu)
    toolbar.addWidget(trigger)
    window.premium_workspace_menu=menu
    return toolbar


def install_premium_ui(window):
    # The original top toolbar is hidden, not deleted, to preserve the
    # references used by legacy methods and their existing actions.
    old=next((b for b in window.findChildren(QToolBar)
              if b.windowTitle()=='Comparison controls'),None)
    if old:old.hide()
    if window.advanced_toolbar:window.advanced_toolbar.hide()
    # Replace QSlider widget only; do NOT change mpv or the native video host.
    previous=window.timeline
    parent=previous.parentWidget()
    layout=parent.layout()
    position=layout.indexOf(previous)
    if position>=0:
        layout.removeWidget(previous)
        previous.hide()
        previous.deleteLater()
        slider=PremiumTimeline(Qt.Orientation.Horizontal,parent)
        slider.setRange(0,10000)
        slider.sliderPressed.connect(lambda:setattr(window,'_scrubbing',True))
        slider.sliderReleased.connect(window.slider_released)
        layout.insertWidget(position,slider,1)
        window.timeline=slider
    # Create an explicit transport in the bottom bar. Never rely on hidden
    # toolbar buttons to perform the primary Play action.
    play=QPushButton('▶  Play / Pause',parent)
    play.setObjectName('primaryAction')
    play.setToolTip('Play/Pause · Space')
    play.clicked.connect(window.toggle_play)
    layout.insertWidget(0,play)
    frame_prev=QToolButton(parent);frame_prev.setText('◁')
    frame_prev.setToolTip('Previous frame · ,')
    frame_prev.clicked.connect(lambda:window.step(-1))
    layout.insertWidget(1,frame_prev)
    frame_next=QToolButton(parent);frame_next.setText('▷')
    frame_next.setToolTip('Next frame · .')
    frame_next.clicked.connect(lambda:window.step(1))
    layout.insertWidget(2,frame_next)
    window.premium_play_button=play
    for pane in window.panes:
        pane.name.setObjectName('paneTitle')
        pane.status.setObjectName('paneStatus')
        pane.layout().setContentsMargins(4,4,4,4)
        pane.layout().setSpacing(3)
        pane.name.setMaximumHeight(20)
        pane.status.setMaximumHeight(18)
        # The HWND host is kept opaque. No QGraphicsEffect is applied to it.
    window.browser.setMinimumWidth(250)
    window.browser_dock.setMinimumWidth(255)
    window.diagnostics_dock.setMinimumWidth(260)
    window.setMinimumSize(720,460)
    # Keep loading-time metadata visible through the browser and diagnostics.
    name=window.settings.data.get('theme',DEFAULT_THEME)
    apply_theme(window,name,save=False)


def apply_theme(window,name,save=True):
    if name not in THEMES:name=DEFAULT_THEME
    window.setStyleSheet(make_stylesheet(name))
    if hasattr(window.timeline,'set_theme'):window.timeline.set_theme(name)
    if save:
        window.settings.data['theme']=name
        window.settings.save()
