@echo off
setlocal
cd /d "%~dp0"
echo ========================================================
echo DirectRGB Compare - Launch CURRENT vNext source (diagnostic)
echo ========================================================
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Python environment is missing. Run RUN_FIRST.bat.
  pause
  exit /b 1
)
echo This starts run.py from: %CD%
echo This does NOT launch a potentially outdated EXE in dist.
".venv\Scripts\python.exe" -c "from directrgb import vnext_gui; print('UI module:',vnext_gui.__file__); print('Browser restore:',hasattr(vnext_gui.MainWindow,'restore_browser_workspace'))"
if errorlevel 1 (pause & exit /b 1)
".venv\Scripts\python.exe" run.py
if errorlevel 1 echo ERROR: Startup failed - see Python traceback above.
pause
