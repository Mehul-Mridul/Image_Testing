"""Windows native UI smoke: executes actual Qt code (not SDR pixel validation).

Run using CHECK_PREMIUM_GUI.bat after provisioning .venv and native runtime.
"""
from __future__ import annotations
import json
import sys
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from PySide6.QtWidgets import QApplication,QToolBar,QDockWidget
from directrgb.vnext_gui import MainWindow
from directrgb.timeline_widget import PremiumTimeline
from directrgb.premium_ui import apply_theme
from directrgb.theme import THEMES
from directrgb.timeline_controller import ClipRange


def run():
    app=QApplication.instance() or QApplication([])
    window=MainWindow()
    window.show()
    app.processEvents()
    assert isinstance(window.timeline,PremiumTimeline),type(window.timeline)
    assert window.premium_pane_count is not None
    assert window.browser_dock is not None and window.browser is not None
    assert len(window.panes)==4
    assert window.premium_workspace_menu is not None
    for name in THEMES:
        apply_theme(window,name,save=False)
        app.processEvents()
    apply_theme(window,'Graphite',save=False)
    for count in (1,2,3,4,2):
        window.layout_combo.setCurrentIndex(count-1)
        app.processEvents()
        assert window.visible_count==count,(count,window.visible_count)
    # Exercise the actual window slider/transport using synthetic timeline
    # metadata. Does NOT claim the actual libmpv renderer displayed a frame.
    window.comparison_timeline.configure({0:ClipRange(2),1:ClipRange(8),2:ClipRange(4)})
    window._timeline_max=window.comparison_timeline.duration
    window._update_timeline_marks()
    window._update_timeline_display()
    assert window._timeline_max==8
    assert len(window.timeline._end_marks)==3
    assert window.actions.actions['file.open_folder'] is not None
    assert window.actions.actions['file.load_selected'] is not None
    report={
        'suite':'Premium Timeline UI Smoke',
        'platform':sys.platform,
        'Qt_window_constructed':True,
        'timeline_type':type(window.timeline).__name__,
        'tested_visible_counts':[1,2,3,4,2],
        'tested_themes':list(THEMES),
        'browser_present':True,
        'global_timeline_example_seconds':8,
        'not_verified':['D3D11 RGB framebuffer','FFmpeg codec playback','FastStone CMS-OFF equality',
                        'full display frame synchronization','real 4K performance']
    }
    print(json.dumps(report,indent=2))
    window.close()
    app.processEvents()
    app.quit()
    return 0

if __name__=='__main__':raise SystemExit(run())
