"""Windows browser UI regression check; intentionally not a GPU/RGB proof."""
from __future__ import annotations
from pathlib import Path
import sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    if sys.platform!='win32':
        print('NOT VERIFIED: Windows Qt UI is required')
        return 2
    from tempfile import TemporaryDirectory
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QTimer
    from directrgb.vnext_gui import MainWindow
    app=QApplication.instance() or QApplication([])
    import os
    with TemporaryDirectory() as folder:
        # Run the smoke test with isolated settings; do not alter the user's
        # browser-visibility preference or stored session.
        old_local=os.environ.get('LOCALAPPDATA')
        os.environ['LOCALAPPDATA']=folder
        Path(folder,'Test_1.mp4').write_bytes(b'placeholder; browser only')
        window=MainWindow()
        window.show()
        result=[]

        def check():
            try:
                assert window.browser_dock.isVisible(), 'File browser is not initially visible'
                assert window.browser.set_folder(folder), 'Folder could not be selected'
                assert window.browser.model.rootPath()==str(Path(folder).resolve())
                window.browser_dock.hide()
                window.restore_browser_workspace()
                assert window.browser_dock.isVisible(), 'Restore Browser did not show the dock'
                assert window.actions.map.sequence('file.open_folder')
                assert window.actions.map.sequence('file.load_selected')
                assert window.actions.map.sequence('view.browser')
                assert window.actions.map.sequence('view.recover_browser')
                assert 'DirectRGBFileBrowserDock'==window.browser_dock.objectName()
                assert len(window.panes)==4
                print('PASS: Browser startup, folder navigation, restore action, vNext shortcuts')
                result.append(True)
            except Exception as exc:
                print('FAIL:',repr(exc));result.append(False)
            finally:
                window.close();app.quit()

        QTimer.singleShot(1400,check)
        app.exec()
        if old_local is None:
            os.environ.pop('LOCALAPPDATA',None)
        else:
            os.environ['LOCALAPPDATA']=old_local
        return 0 if result==[True] else 1


if __name__=='__main__':
    raise SystemExit(main())
