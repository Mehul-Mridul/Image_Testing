@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo ERROR: Missing .venv - run RUN_FIRST.bat.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" tools\browser_recovery_smoke.py
if errorlevel 1 (echo Browser UI smoke FAILED. & pause & exit /b 1)
echo Browser UI smoke PASSED. Full FastStone color equivalence remains unverified.
pause
