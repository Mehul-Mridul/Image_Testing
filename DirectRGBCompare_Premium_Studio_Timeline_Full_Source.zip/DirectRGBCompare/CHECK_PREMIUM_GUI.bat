@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Missing .venv\Scripts\python.exe. Run RUN_FIRST.bat on Windows to provision dependencies.
  pause
  exit /b 2
)
echo Running the premium UI Qt smoke test on Windows...
".venv\Scripts\python.exe" tools\premium_gui_smoke.py
set "RESULT=%ERRORLEVEL%"
if not "%RESULT%"=="0" (
  echo Premium GUI smoke FAILED. Capture the error above; do not certify this build.
) else (
  echo Premium UI shell test PASSED. Actual RGB and 4K playback STILL require independent tests.
)
pause
exit /b %RESULT%
