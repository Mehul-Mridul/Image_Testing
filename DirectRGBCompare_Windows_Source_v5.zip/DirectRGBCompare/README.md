# DirectRGB Compare — Windows x64 video comparison application

This repository includes a Windows desktop application, native GPU playback integration, a multi-video comparison UI, reference RGB tooling, regression tests, and a **one-click Windows runtime downloader + portable EXE builder**.

## Start here — no manual Python / FFmpeg / DLL installation

1. **Extract the ZIP into its own folder** (e.g. `C:\DirectRGBCompare`), not on top of the old prototype.
2. On **Windows 10/11 x64**, double-click **`RUN_FIRST.bat`** with internet access. It downloads the selected upstream runtimes, creates a private Python environment, runs regression tests, checks libmpv compatibility, attempts a D3D11 smoke test, builds `dist\DirectRGBCompare\DirectRGBCompare.exe`, and starts it.
3. After setup, launch `dist\DirectRGBCompare\DirectRGBCompare.exe` directly or double-click `launch.bat`. To distribute the application after a successful build, **copy the complete `dist\DirectRGBCompare` folder**, not just the EXE.

The setup uses the original vendors' HTTPS distribution locations: Astral `uv` (to manage Python), FFmpeg's listed Windows distributor gyan.dev, the mpv-listed Windows libmpv builder shinchiro, and 7-Zip for archive extraction. SHA-256 checks are applied to downloaded archives. Downloads can be large, and the first setup needs internet connectivity. No administrator access is intended to be necessary. See `docs/WINDOWS_SETUP.md`.

**The supplied ZIP is source + one-click build automation; it does NOT include a precompiled Windows EXE or Windows DLLs.** The authoring environment cannot run Windows D3D11/Qt GUI or FastStone. The EXE is produced on your Windows PC. If a runtime is missing from an already-built package, build again with `RUN_FIRST.bat`; the app now reports the missing component on startup instead of waiting for a video to be opened.

## 7-Zip 26.04/26.05 installer mismatch fix (2026-11-07)

Version 4 requested `https://www.7-zip.org/a/7zr.exe`, which returned 26.04 while the installer expected 26.05, failing SHA256. This version requests a **versioned official 26.05 release**, checks the pinned publisher SHA256, and accepts a previously installed 26.04 file only if it matches its own official SHA256. Unknown local executables are quarantined. Existing downloaded FFmpeg, uv and libmpv packages are retained.

## Download repair for interrupted FFmpeg transfers (2026-11-07)

The older installer downloaded Gyan's ~109 MB ZIP through `Invoke-WebRequest`; Windows reported "An existing connection was forcibly closed by the remote host." The new installer downloads a smaller, immutable **FFmpeg 9.0.2 essentials 7z (~34 MB)**, prefers Gyan's GitHub release mirror with Gyan itself as fallback, and uses Windows `curl.exe` with retry and resuming `.part` downloads. The publisher SHA256 is pinned, **never bypassed**. The earlier PowerShell `uv --version` and checksum parsing defects are also fixed. If the new installer has an ongoing interruption, rerun `RUN_FIRST.bat`; partial archive data may be resumed. Offline tests do not prove your Windows networking, libmpv runtime, or FastStone color matching.

## Features present in source

- One to four independent panes, drag/drop, load/replace/remove, reordering, resizing, fullscreen.
- Timestamp-based master play/pause, seek, stepping, speed, looping, per-pane offsets, drift estimates. The controller periodically re-seeks when drift is large. This does **not** guarantee frame-perfect synchronization between dissimilar encodes.
- Fit, native scaling, 2x zoom, synced pan/zoom. Windows DPI and 100%-scale equivalence still require manual verification.
- Per-video FFprobe metadata and live libmpv state in the diagnostics dock.
- Direct SDR RGB requested policy: no app-level monitor ICC, no embedded ICC, no automatic SDR gamma correction, no optional tone mapping/grade/sharpening. Normal YCbCr -> RGB reconstruction is **not** bypassed. libmpv/libplacebo may still perform unavoidable or automatic display-related conversions; see `docs/ARCHITECTURE.md`.
- Diagnostic range and matrix overrides; HDR/wide-gamut tagging is blocked from this unvalidated SDR mode.
- Independent FFmpeg `zscale` video-frame export, known-code-value PNG chart, per-channel numeric PNG comparisons and heatmaps.
- No OpenCV -> QLabel real-time pipeline; rendering is delegated to native libmpv/D3D11.

## How to verify the exact problem reported

After `RUN_FIRST.bat`, check these files exist:

```
DirectRGBCompare/
  vendor/bin/ffprobe.exe
  vendor/bin/ffmpeg.exe
  vendor/bin/libmpv-2.dll  (or mpv-2.dll)
  dist/DirectRGBCompare/DirectRGBCompare.exe
  dist/DirectRGBCompare/_internal/bin/ffprobe.exe
  dist/DirectRGBCompare/_internal/bin/ffmpeg.exe
```

Some PyInstaller versions use a different internal layout; check the packaged folder recursively. The `paths.py` resolver supports both the source and PyInstaller layouts.

**Do not run an old EXE** from the previous prototype. It was created without required runtime binaries. Run the new `RUN_FIRST.bat`, then launch the new `dist` EXE.

## Validation

Run `CHECK_WINDOWS_GUI.bat` (on Windows after setup) for a native HWND + libmpv decoding smoke test. For numeric validation run:

```bat
.venv\Scripts\python.exe -m directrgb.validation extract assets\test_yuv420_bt709_limited.mkv reference.png --at 0
.venv\Scripts\python.exe -m directrgb.validation compare reference.png actual_capture.png --heatmap differences.png
.venv\Scripts\python.exe -m pytest -q tests
```

The screenshot or capture must show the exact frame at the exact same native pixel size, with display chrome cropped away. libmpv screenshots can reflect the chosen render path, not necessarily raw pre-DWM RGB. Follow `docs/VALIDATION.md` and record Windows HDR mode, monitor, color profile, scaling, renderer state, and crop alignment.

**Verification statement (2026-11-07):** 34 offline tests passed on Linux (including 4 checks specific to the 7-Zip bootstrap correction); the independently decoded, lossless RGB reference roundtrip had 0 max absolute difference in the previous baseline. The current GUI and one-click PowerShell workflow are *not* tested on Windows in this environment; a completed, independent FastStone CMS-OFF equivalence test does not yet exist. Do not treat this as a certified colorimeter-grade or FastStone-bit-exact product. See `docs/TEST_RESULTS.json`.

## License and responsible redistribution

The source invokes or packages third-party FFmpeg, mpv/libmpv, libplacebo, PySide6, uv, 7-Zip, and their dependencies. Their license terms vary by build choices. The runtime loader downloads recognized upstream distributions rather than bundling third-party binaries in this source archive. **For redistribution of the created EXE folder**, inspect the actual third-party build licenses and obligations, including any corresponding-source requirements. See `vendor/README.md` and `docs/THIRD_PARTY.md`.
