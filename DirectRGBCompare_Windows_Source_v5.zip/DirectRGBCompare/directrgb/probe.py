"""ffprobe metadata without misleading guesses for missing fields."""
from __future__ import annotations
from dataclasses import dataclass, asdict
from fractions import Fraction
from pathlib import Path
import json
import subprocess
from .paths import bundled_tool
from .policy import classify_hdr, direct_eligibility


@dataclass(frozen=True)
class VideoMetadata:
    path: str
    codec: str
    width: int
    height: int
    avg_frame_rate: str
    r_frame_rate: str
    pix_fmt: str
    bit_depth: str
    chroma_subsampling: str
    range: str
    primaries: str
    transfer: str
    matrix: str
    chroma_location: str
    duration: float
    start_time: float
    sar: str
    rotation: str
    hdr: str
    hdr_side_data: list
    first_frame_side_data: list
    first_frame_tags: dict

    def to_dict(self):
        return asdict(self)

    @property
    def fps(self):
        try:
            f = Fraction(self.avg_frame_rate)
            return float(f) if f.denominator and f.numerator else 0.0
        except (ValueError, ZeroDivisionError):
            return 0.0

    @property
    def eligibility(self):
        base = direct_eligibility(self.transfer, self.primaries)
        if not base[0]:
            return base
        frame = self.first_frame_tags
        frame_transfer = frame.get('color_transfer')
        frame_primaries = frame.get('color_primaries')
        if frame_transfer or frame_primaries:
            override = direct_eligibility(str(frame_transfer or self.transfer),
                                          str(frame_primaries or self.primaries))
            if not override[0]:
                return False, 'Frame-level metadata reports HDR/wide-gamut: ' + override[1]
        for item in self.hdr_side_data + self.first_frame_side_data:
            desc = str(item).lower()
            if any(w in desc for w in ('mastering display metadata',
                                        'content light level', 'hdr10+', 'dynamic hdr')):
                return False, 'HDR side data present despite SDR/unknown stream tags. Output blocked.'
        return base


def _field(value):
    if value is None or str(value).lower() in ('', 'n/a', 'unknown', 'unspecified'):
        return 'Unspecified'
    return str(value)


def _num(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def parse_probe(path: str, data: dict) -> VideoMetadata:
    streams = [s for s in data.get('streams', []) if s.get('codec_type') == 'video']
    if not streams:
        raise ValueError('No video stream in file.')
    stream = streams[0]
    fmt = data.get('format', {})
    pix = str(stream.get('pix_fmt', ''))
    digits = ''.join(ch for ch in pix if ch.isdigit())
    bits = stream.get('bits_per_raw_sample')
    if bits is None and pix in ('yuv420p', 'yuv422p', 'yuv444p', 'nv12', 'rgb24', 'bgr24', 'gbrp'):
        bits = 8
    elif bits is None and digits:
        # e.g. yuv420p10le: may have multiple numbers (420 and 10); use suffix.
        import re
        m = re.search(r'p(\d{2})(?:le|be)$', pix)
        if m:
            bits = int(m.group(1))
    chroma = '4:2:0' if ('420' in pix or pix == 'nv12' or 'p010' in pix) else (
        '4:2:2' if '422' in pix else '4:4:4' if ('444' in pix or pix.startswith('gbr')) else 'Unspecified')
    side = stream.get('side_data_list', [])
    mastering = [x for x in side if any(k in str(x).lower() for k in ('mastering', 'light level', 'hdr', 'dolby'))]
    rotation = 'Unspecified'
    for x in side:
        if 'rotation' in x:
            rotation = str(x['rotation'])
    if rotation == 'Unspecified':
        rotation = _field(stream.get('tags', {}).get('rotate'))
    return VideoMetadata(
        path=str(Path(path).resolve()), codec=_field(stream.get('codec_name')),
        width=int(stream.get('width', 0)), height=int(stream.get('height', 0)),
        avg_frame_rate=_field(stream.get('avg_frame_rate')),
        r_frame_rate=_field(stream.get('r_frame_rate')),
        pix_fmt=_field(pix), bit_depth=_field(bits), chroma_subsampling=chroma,
        range=_field(stream.get('color_range')), primaries=_field(stream.get('color_primaries')),
        transfer=_field(stream.get('color_transfer')), matrix=_field(stream.get('color_space')),
        chroma_location=_field(stream.get('chroma_location')),
        duration=_num(stream.get('duration') or fmt.get('duration')),
        start_time=_num(stream.get('start_time')),
        sar=_field(stream.get('sample_aspect_ratio')),
        rotation=rotation,
        hdr=classify_hdr(str(stream.get('color_transfer') or ''), str(stream.get('color_primaries') or '')),
        hdr_side_data=mastering,
        first_frame_side_data=[],
        first_frame_tags={},
    )


def probe_file(path: str, timeout=25) -> VideoMetadata:
    cmd = [bundled_tool('ffprobe'), '-v', 'error', '-show_streams', '-show_format', '-of', 'json', path]
    result = subprocess.run(cmd, capture_output=True, text=True, timeout=timeout, check=False)
    if result.returncode:
        raise RuntimeError(f'ffprobe failed: {result.stderr.strip()[:800]}')
    meta = parse_probe(path, json.loads(result.stdout))
    # Optional short frame-level check: FFprobe may surface per-frame HDR/crop/color
    # changes not present in container-level tags. Kept bounded to one frame.
    from dataclasses import replace
    frame_cmd = [bundled_tool('ffprobe'), '-v', 'error', '-select_streams', 'v:0',
                 '-read_intervals', '0%+#1', '-show_frames', '-of', 'json', path]
    try:
        frames = subprocess.run(frame_cmd, capture_output=True, text=True,
                                timeout=min(timeout, 15), check=False)
        if frames.returncode == 0:
            items = json.loads(frames.stdout).get('frames', [])
            if items:
                f = items[0]
                keys = ('best_effort_timestamp_time', 'color_range', 'color_space',
                        'color_primaries', 'color_transfer', 'chroma_location', 'pict_type')
                meta = replace(meta,
                               first_frame_side_data=f.get('side_data_list', []),
                               first_frame_tags={k:f[k] for k in keys if k in f})
    except (subprocess.TimeoutExpired, ValueError, OSError):
        # Blank tags are not interpreted as proof that frame-level tags are absent.
        pass
    return meta
