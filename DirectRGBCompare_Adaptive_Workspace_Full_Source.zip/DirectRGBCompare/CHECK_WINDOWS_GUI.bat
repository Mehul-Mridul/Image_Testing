@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
   echo Run RUN_FIRST.bat first.
   pause
   exit /b 1
)
".venv\Scripts\python.exe" tools\windows_smoke.py
if errorlevel 1 (
    echo Direct3D playback smoke test FAILED. See the output above.
    pause
    exit /b 1
)
echo Windows D3D11 smoke test passed, but this is not a numerical color-match test.
pause
