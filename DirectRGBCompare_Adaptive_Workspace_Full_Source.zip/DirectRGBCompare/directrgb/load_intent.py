"""Deterministic user intent to pane assignment, independent of widgets/decoding."""
from __future__ import annotations
from dataclasses import dataclass


@dataclass(frozen=True)
class LoadIntent:
    mode: str
    slots: tuple[str | None, ...]
    visible_count: int
    target_panes: tuple[int, ...]


def plan_load(paths, *, active_pane=0, existing=(), mode='replace') -> LoadIntent:
    paths = tuple(str(p) for p in paths)
    if not 1 <= len(paths) <= 4:
        raise ValueError('Select one to four files')
    if not 0 <= active_pane < 4:
        raise ValueError('Invalid active pane')
    if mode not in ('replace', 'append'):
        raise ValueError('Unknown load mode')
    current = tuple(existing)[:4] + (None,) * max(0, 4-len(existing))
    if mode == 'append':
        free = [i for i, name in enumerate(current) if not name]
        if len(free) < len(paths):
            raise ValueError('Not enough empty panes; use Replace Current Comparison')
        result = list(current)
        for i, path in zip(free, paths):
            result[i] = path
        slots = tuple(result)
        return LoadIntent(mode, slots, max(i+1 for i,v in enumerate(slots) if v), tuple(free[:len(paths)]))
    if len(paths) == 1:
        result = list(current)
        result[active_pane] = paths[0]
        return LoadIntent(mode, tuple(result), max(active_pane+1, max((i+1 for i,v in enumerate(current) if v), default=1)), (active_pane,))
    return LoadIntent(mode, paths + (None,) * (4-len(paths)), len(paths), tuple(range(len(paths))))
