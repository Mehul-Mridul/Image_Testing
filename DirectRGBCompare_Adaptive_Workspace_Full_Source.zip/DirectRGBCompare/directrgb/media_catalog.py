"""Filesystem catalogue. No codec probing or video decode occurs during listing."""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import os
import re
from typing import Iterable

VIDEO_EXTENSIONS = frozenset({'.mp4','.mov','.mkv','.avi','.m4v','.webm','.ts','.mxf','.wmv','.mpg','.mpeg','.mts','.m2ts'})


def is_video(path: str | Path) -> bool:
    return Path(path).suffix.lower() in VIDEO_EXTENSIONS


def natural_key(value: str):
    return tuple((1, int(piece)) if piece.isdigit() else (0, piece.casefold())
                 for piece in re.split(r'(\d+)', value))


@dataclass(frozen=True)
class MediaEntry:
    path: str
    name: str
    size: int
    mtime_ns: int


def scan_folder(folder: str | Path, *, recursive: bool=False, max_files: int=100000) -> list[MediaEntry]:
    """Scan lazily in a worker; sorted, deterministic and symlinks are not followed."""
    root = Path(folder)
    if not root.is_dir():
        raise NotADirectoryError(str(root))
    matches: list[MediaEntry] = []
    if recursive:
        for base_name, directories, files in os.walk(root, followlinks=False):
            directories.sort(key=natural_key)
            files.sort(key=natural_key)
            base = Path(base_name)
            for filename in files:
                p=base/filename
                if is_video(p):
                    try:
                        st=p.stat()
                    except OSError:
                        continue
                    matches.append(MediaEntry(str(p.resolve()),p.name,st.st_size,st.st_mtime_ns))
                    if len(matches)>=max_files:
                        return sorted(matches,key=lambda m: natural_key(str(Path(m.path).relative_to(root))))
    else:
        with os.scandir(root) as iterator:
            for item in iterator:
                try:
                    if item.is_file(follow_symlinks=False) and is_video(item.name):
                        st=item.stat(follow_symlinks=False)
                        matches.append(MediaEntry(str(Path(item.path).resolve()),item.name,st.st_size,st.st_mtime_ns))
                except OSError:
                    continue
                if len(matches)>=max_files:
                    break
    return sorted(matches,key=lambda m: natural_key(str(Path(m.path).relative_to(root))))


def sort_entries(entries: Iterable[MediaEntry], mode='name') -> list[MediaEntry]:
    data=list(entries)
    if mode=='date': return sorted(data,key=lambda m:(-m.mtime_ns,natural_key(m.path)))
    if mode=='size': return sorted(data,key=lambda m:(-m.size,natural_key(m.path)))
    if mode=='type': return sorted(data,key=lambda m:(Path(m.name).suffix.casefold(),natural_key(m.path)))
    return sorted(data,key=lambda m:natural_key(m.path))
