"""Generation IDs make asynchronous probe completions harmless after replacement."""
from dataclasses import dataclass

@dataclass(frozen=True)
class LoadRequest:
    pane: int
    token: int
    path: str
    set_generation: int

class PaneLoadCoordinator:
    def __init__(self,count=4):
        self.tokens=[0]*count
        self.pending:dict[int,LoadRequest]={}

    def begin(self,pane,path,set_generation=0):
        self.tokens[pane]+=1
        req=LoadRequest(pane,self.tokens[pane],str(path),set_generation)
        self.pending[pane]=req
        return req

    def cancel(self,pane):
        self.tokens[pane]+=1
        self.pending.pop(pane,None)

    def active(self,pane,token,set_generation):
        req=self.pending.get(pane)
        return req is not None and req.token==token and req.set_generation==set_generation and req.token==self.tokens[pane]

    def complete(self,pane,token,set_generation):
        if not self.active(pane,token,set_generation):return False
        self.pending.pop(pane,None)
        return True
