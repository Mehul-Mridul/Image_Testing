"""Pure, testable Qt-logical-pixel geometry, no image/color processing."""
from __future__ import annotations
from dataclasses import dataclass,replace
from math import isfinite,log2
from fractions import Fraction


def clamp(v,a,b): return max(a,min(b,v))

@dataclass(frozen=True)
class Geometry:
    source_width: float
    source_height: float
    viewport_width: float    # Qt logical px
    viewport_height: float   # Qt logical px
    dpr: float = 1.0         # physical px / Qt logical px
    sample_aspect: float = 1.0
    rotation: int = 0

    def __post_init__(self):
        for v in (self.source_width,self.source_height,self.viewport_width,self.viewport_height,self.dpr,self.sample_aspect):
            if not isfinite(v) or v<=0: raise ValueError('All dimensions must be positive finite values')
        if self.rotation%90!=0: raise ValueError('Only right-angle rotation supported')

    @property
    def display_size(self):
        w=self.source_width*self.sample_aspect
        h=self.source_height
        if self.rotation%180:
            w,h=h,w
        return w,h

    @property
    def fit_scale(self):
        w,h=self.display_size
        return min(self.viewport_width/w,self.viewport_height/h)

    def scale(self,state):
        # Content *display* pixels to Qt logical pixels. Native physical
        # display-pixel ratio 1:1 is logical 1/dpr, subject to Windows validation.
        return (self.fit_scale if state.mode=='fit' else (1/self.dpr)) * state.magnification

    def display_extent(self,state):
        scale=self.scale(state); w,h=self.display_size
        return w*scale,h*scale

    def screen_to_uv(self,x,y,state):
        w,h=self.display_extent(state)
        return (state.cx+(x-self.viewport_width/2)/w,
                state.cy+(y-self.viewport_height/2)/h)

    def uv_to_screen(self,u,v,state):
        w,h=self.display_extent(state)
        return (self.viewport_width/2+(u-state.cx)*w,
                self.viewport_height/2+(v-state.cy)*h)

    def anchored_zoom(self,state,x,y,factor):
        if factor<=0: raise ValueError('Zoom factor must be positive')
        u,v=self.screen_to_uv(x,y,state)
        new=replace(state,magnification=clamp(state.magnification*factor,.0625,32))
        w,h=self.display_extent(new)
        return replace(new,cx=clamp(u-(x-self.viewport_width/2)/w,0,1),
                       cy=clamp(v-(y-self.viewport_height/2)/h,0,1))

    def drag_pan(self,state,delta_x,delta_y):
        w,h=self.display_extent(state)
        return replace(state,cx=clamp(state.cx-delta_x/w,0,1),
                       cy=clamp(state.cy-delta_y/h,0,1))

    def to_mpv(self,state):
        """Adapter to mpv's documented zoom log2, pan fractions-of-video.

        Important: actual D3D11 and Qt HWND DPI behavior must be compared on
        Windows. Rotation, SAR and native scale can expose backend differences.
        """
        zoom=state.magnification if state.mode=='fit' else state.magnification*(1/self.dpr)/self.fit_scale
        return {'video-unscaled':'no', 'video-zoom':f'{log2(zoom):.9f}',
                'video-pan-x':f'{(0.5-state.cx):.9f}',
                'video-pan-y':f'{(0.5-state.cy):.9f}'}


@dataclass(frozen=True)
class ViewState:
    mode: str = 'fit'     # fit | native
    magnification: float = 1.0
    cx: float = .5       # normalized centre of displayed source coordinates
    cy: float = .5


def parse_sar(sar: str) -> float:
    if not sar or sar=='Unspecified':return 1.
    try:
        s=sar.replace(':','/')
        f=float(Fraction(s))
        return f if f>0 else 1.
    except (ValueError, ZeroDivisionError):return 1.
