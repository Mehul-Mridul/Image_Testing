"""Per-request wall-clock stages; metrics never claim visible pixels were measured."""
from __future__ import annotations
from dataclasses import dataclass,field
from time import monotonic


@dataclass
class LoadingMetrics:
    started: float = field(default_factory=monotonic)
    timestamps: dict[str,float] = field(default_factory=dict)
    probe_cache_hit: bool = False
    reused_renderer: bool = False

    def mark(self,stage,at=None):
        self.timestamps[stage] = (monotonic() if at is None else at) - self.started

    def snapshot(self):
        return {'milliseconds': {k: round(v*1000,2) for k,v in self.timestamps.items()},
                'probe_cache_hit': self.probe_cache_hit,
                'reused_renderer': self.reused_renderer,
                'actual_visible_frame': 'UNVERIFIED: capture or presentation instrumentation required'}
