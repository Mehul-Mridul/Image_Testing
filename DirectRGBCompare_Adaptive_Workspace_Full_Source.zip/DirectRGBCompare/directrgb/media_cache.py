"""Process-local bounded metadata cache keyed by file identity and probe schema."""
from __future__ import annotations
from collections import OrderedDict
from pathlib import Path
from threading import RLock

SCHEMA = 2


class MetadataCache:
    def __init__(self,capacity=128):
        self.capacity = max(1,int(capacity))
        self.data = OrderedDict()
        self.lock = RLock()
        self.hits = 0
        self.misses = 0

    @staticmethod
    def key(path, *, probe_version='ffprobe-current'):
        p = Path(path).resolve()
        stat = p.stat()
        return (str(p),stat.st_size,stat.st_mtime_ns,SCHEMA,probe_version)

    def get(self,key):
        with self.lock:
            if key not in self.data:
                self.misses += 1
                return None
            self.data.move_to_end(key)
            self.hits += 1
            return self.data[key]

    def put(self,key, metadata):
        with self.lock:
            self.data[key] = metadata
            self.data.move_to_end(key)
            while len(self.data) > self.capacity:
                self.data.popitem(last=False)


CACHE = MetadataCache()
