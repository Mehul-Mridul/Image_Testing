"""Pure numerical Y'CbCr->R'G'B' reference for 8-bit *4:4:4* triplets.

This is NOT the live rendering shader. Subsampled chroma requires spatial
reconstruction (siting/filter), done by FFmpeg zscale in validation.py.
"""
import numpy as np

KR_KB = {
    'bt601': (0.2990, 0.1140),
    'bt709': (0.2126, 0.0722),
    'bt2020nc': (0.2627, 0.0593),
}


def ycbcr_to_rgb_444(ycbcr, *, matrix='bt709', range='limited'):
    arr = np.asarray(ycbcr, dtype=np.float64)
    if arr.shape[-1] != 3:
        raise ValueError('Last dimension must be (Y,Cb,Cr)')
    if matrix not in KR_KB:
        raise ValueError(f'Unsupported matrix {matrix}')
    if range not in ('limited', 'full'):
        raise ValueError(f'Invalid range {range}')
    kr, kb = KR_KB[matrix]
    kg = 1.0 - kr - kb
    y, cb, cr = np.moveaxis(arr, -1, 0)
    if range == 'limited':
        # 8-bit studio Y 16..235, Cb/Cr 16..240; excursion 219/224.
        Y = (y - 16.0) * (255.0/219.0)
        Cb = (cb - 128.0) * (255.0/224.0)
        Cr = (cr - 128.0) * (255.0/224.0)
    else:
        Y, Cb, Cr = y, cb - 128.0, cr - 128.0
    R = Y + 2.0*(1-kr)*Cr
    B = Y + 2.0*(1-kb)*Cb
    G = (Y - kr*R - kb*B)/kg
    return np.stack([R,G,B],axis=-1)


def quantize_rgb_8bit(arr):
    # Reference quantization only: zscale/libplacebo GPU rounding may differ.
    return np.clip(np.rint(np.asarray(arr)),0,255).astype(np.uint8)
