"""Deliberately conservative SDR policy, NOT an assertion of bit-identical output."""
from dataclasses import dataclass
from enum import Enum
from typing import Mapping

class DisplayMode(str, Enum):
    DIRECT = 'Direct RGB — FastStone CMS OFF reference'
    DIAGNOSTIC = 'Diagnostic RGB (overrides visible)'

# Every option is checked for support by mpv_set_option_string; initialization fails
# if an expected option is unavailable, rather than silently applying another policy.
DIRECT_OPTIONS: Mapping[str, str] = {
    'config': 'no',                 # Don't inherit user mpv.conf or scripts.
    'load-scripts': 'no',
    'input-default-bindings': 'no',
    'input-vo-keyboard': 'no',
    'osc': 'no',
    'osd-level': '0',
    'audio': 'no',
    'pause': 'yes',
    'idle': 'yes',
    'keep-open': 'yes',
    'vo': 'gpu-next',
    'gpu-context': 'd3d11',
    'gpu-api': 'd3d11',
    'auto-window-resize': 'no',
    'hwdec': 'auto-safe',
    'd3d11-output-format': 'rgba8',   # Hint, not guarantee for gpu-next.
    'd3d11-output-csp': 'srgb',       # SDR swapchain request, actual needs verification.
    'video-output-levels': 'full',
    'icc-profile-auto': 'no',
    'use-embedded-icc-profile': 'no',
    'interpolation': 'no',
    'deband': 'no',
    'sigmoid-upscaling': 'no',
    'correct-downscaling': 'no',
    'sdr-adjust-gamma': 'no',
    'target-prim': 'auto',            # Still adapts atypical primaries! See docs.
    'target-trc': 'auto',             # Still adapts HDR/atypical transfer! Reject HDR.
    'video-sync': 'audio',
    'hr-seek': 'yes',
    'hr-seek-framedrop': 'no',
    'keepaspect': 'yes',
    'video-unscaled': 'no',
    'scale': 'bilinear',
    'cscale': 'bilinear',
    'dscale': 'bilinear',
    'dither-depth': '8',
    'temporal-dither': 'no',
    'dither': 'no',
    'demuxer-max-bytes': '32MiB',
    'demuxer-max-back-bytes': '8MiB',
    'vd-queue-max-bytes': '64MiB',
    'vd-queue-max-samples': '6',
    'screenshot-format': 'png',
    'screenshot-sw': 'no',
}

MATRIX_MPV = {'bt709': 'bt.709', 'smpte170m': 'bt.601', 'bt470bg': 'bt.601',
              'bt2020nc': 'bt.2020-ncl'}

@dataclass(frozen=True)
class Overrides:
    range: str = 'auto'          # auto | limited | full
    matrix: str = 'auto'         # auto | bt709 | smpte170m | bt2020nc

    def normalized(self):
        if self.range not in ('auto', 'limited', 'full'):
            raise ValueError(f'Unsupported range override: {self.range}')
        if self.matrix not in ('auto', *MATRIX_MPV):
            raise ValueError(f'Unsupported matrix override: {self.matrix}')
        return self

    def combined_mpv_override(self):
        self.normalized()
        parts = []
        if self.range != 'auto':
            parts.append(f'colorlevels={self.range}')
        if self.matrix != 'auto':
            parts.append(f'colormatrix={MATRIX_MPV[self.matrix]}')
        return 'format=' + ':'.join(parts) + ':convert=no' if parts else ''


def classify_hdr(transfer: str, primaries: str = '') -> str:
    t = (transfer or '').lower()
    if t in ('smpte2084', 'pq'):
        return 'HDR (PQ / HDR10 family)'
    if t in ('arib-std-b67', 'hlg'):
        return 'HDR (HLG)'
    if (primaries or '').lower() in ('bt2020', 'bt.2020'):
        return 'Wide-gamut BT.2020 (HDR status not established)'
    if not t or t in ('unknown', 'unspecified'):
        return 'Unspecified transfer (SDR not confirmed)'
    return 'SDR (metadata indicates non-HDR transfer)'


def direct_eligibility(transfer: str, primaries: str) -> tuple[bool, str]:
    """Fail closed: no claim of unmanaged RGB for unvalidated HDR/wide gamut."""
    if (transfer or '').lower() in ('smpte2084', 'arib-std-b67', 'pq', 'hlg'):
        return False, 'HDR detected: this SDR build disables direct-mode playback rather than silently tone-map.'
    if (primaries or '').lower() in ('bt2020', 'bt.2020', 'smpte432', 'smpte431'):
        return False, 'Wide-gamut color detected: source primaries adaptation is not verified as direct RGB.'
    if not transfer or transfer.lower() in ('unknown', 'unspecified'):
        return True, 'Transfer metadata unspecified: decode uses backend inference; verify against PNG.'
    return True, ''
