"""Batch-level generations and cancellable probe state (pure Python)."""
from __future__ import annotations
from dataclasses import dataclass
from time import monotonic


@dataclass
class LoadBatch:
    generation: int
    assignments: dict[int, str | None]
    statuses: dict[int, str]
    started: float

    @property
    def complete(self):
        return all(status in ('ready', 'failed', 'cancelled', 'empty') for status in self.statuses.values())

    @property
    def valid(self):
        return self.complete and all(status in ('ready', 'empty') for status in self.statuses.values())


class LoadScheduler:
    def __init__(self):
        self.generation = 0
        self.active: LoadBatch | None = None

    def begin(self, assignments):
        self.generation += 1
        data = dict(assignments)
        self.active = LoadBatch(self.generation, data,
                                {i: 'queued' if path else 'empty' for i,path in data.items()},
                                monotonic())
        return self.active

    def current(self, generation):
        return bool(self.active and self.active.generation == generation)

    def update(self, generation, pane, status):
        if not self.current(generation) or pane not in self.active.statuses:
            return False
        self.active.statuses[pane] = status
        return True

    def cancel(self):
        self.generation += 1
        if self.active:
            for i, status in self.active.statuses.items():
                if status not in ('ready', 'failed', 'empty'):
                    self.active.statuses[i] = 'cancelled'
        self.active = None
