"""Runtime discovery. Installed binaries are shipped inside the portable EXE folder.

An explicit DIRECTRGB_RUNTIME_DIR is useful for diagnostics and tests; it does not
silently download code while a user loads a video.
"""
from __future__ import annotations
import os
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parent.parent
RUNTIME = Path(getattr(sys, '_MEIPASS', ROOT))


def runtime_directories():
    """Most-specific to least-specific. PyInstaller _MEIPASS resolves _internal."""
    if os.environ.get('DIRECTRGB_RUNTIME_DIR'):
        yield Path(os.environ['DIRECTRGB_RUNTIME_DIR'])
    yield RUNTIME / 'bin'
    yield ROOT / 'vendor' / 'bin'
    if getattr(sys, 'frozen', False):
        yield Path(sys.executable).resolve().parent / 'bin'


def bundled_tool(name: str) -> str:
    suffix = '.exe' if sys.platform == 'win32' else ''
    for directory in runtime_directories():
        candidate = directory / (name + suffix)
        if candidate.is_file():
            return str(candidate)
    path = shutil.which(name + suffix) or shutil.which(name)
    if path:
        return path
    raise FileNotFoundError(
        f'{name}{suffix} is unavailable. Run RUN_FIRST.bat to install and bundle '
        f'the application runtimes automatically. Expected vendor/bin/{name}{suffix}. '
        'Do not download executables from DLL mirror websites.'
    )


def mpv_library_candidates():
    override = os.environ.get('DIRECTRGB_MPV_DLL')
    if override:
        yield override
    for directory in [*runtime_directories(), ROOT]:
        for filename in ('libmpv-2.dll', 'mpv-2.dll', 'libmpv.dll', 'libmpv.so.2', 'libmpv.so'):
            yield str(directory / filename)
    from ctypes.util import find_library
    for name in ('mpv-2', 'mpv'):
        result = find_library(name)
        if result:
            yield result


def missing_runtime_files():
    """Executable distribution preflight; usable without importing Qt."""
    missing = []
    for cmd in ('ffprobe', 'ffmpeg'):
        try:
            bundled_tool(cmd)
        except FileNotFoundError:
            missing.append(cmd + ('.exe' if sys.platform == 'win32' else ''))
    if sys.platform == 'win32':
        if not any(Path(p).is_file() for p in mpv_library_candidates() if os.path.isabs(p)):
            # This is a best-effort file check; actual DLL imports are checked on load.
            missing.append('libmpv-2.dll or mpv-2.dll')
    return missing
