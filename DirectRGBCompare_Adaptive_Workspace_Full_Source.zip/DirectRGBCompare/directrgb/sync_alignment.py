"""Visual anchor time synchronization, independent of renderer implementation."""
from dataclasses import dataclass
from math import isfinite


@dataclass(frozen=True)
class SyncAnchor:
    master: int
    observed_pts: dict[int,float]
    offsets: dict[int,float]


def align_here(master: int, presented_pts: dict[int,float | None]) -> SyncAnchor:
    if master not in presented_pts:
        raise ValueError('Master pane missing')
    for idx,pts in presented_pts.items():
        if pts is None or not isfinite(pts) or pts<0:
            raise ValueError(f'Pane {idx+1} has no valid presented PTS; pause and wait for frame.')
    m=float(presented_pts[master])
    points={i:float(pts) for i,pts in presented_pts.items()}
    return SyncAnchor(master,points,{i:t-m for i,t in points.items()})


def target_pts(master_time: float, offset: float, duration: float | None = None):
    requested=master_time+offset
    if requested<0 or (duration is not None and duration>0 and requested>duration):
        return None
    return requested


def drift_ms(observed: float | None, target: float | None):
    if observed is None or target is None: return None
    return (observed-target)*1000


def select_timestamp(video_pts:float|None,playback_time:float|None):
    """Do not pass estimated time-pos off as actual displayed-frame PTS."""
    if video_pts is not None and isfinite(video_pts) and video_pts>=0:
        return video_pts,'video-pts'
    if playback_time is not None and isfinite(playback_time) and playback_time>=0:
        return playback_time,'time-pos (estimated playback position; NOT measured frame PTS)'
    return None,'unavailable'
