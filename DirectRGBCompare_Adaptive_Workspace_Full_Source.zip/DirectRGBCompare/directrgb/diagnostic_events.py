"""Bounded events; file paths redacted by default in shared diagnostic output."""
from collections import deque
from dataclasses import dataclass,asdict
from datetime import datetime,timezone
import hashlib
import json
import re
from pathlib import Path

@dataclass(frozen=True)
class Event:
    at: str
    category: str
    message: str
    info: dict

class EventLog:
    def __init__(self,limit=500):
        self.events=deque(maxlen=limit)

    def record(self,category,message,**info):
        safe={}
        for k,v in info.items():
            if 'path' in k.lower() or 'file' in k.lower():
                safe[k+'_sha256_12']=hashlib.sha256(str(v).encode()).hexdigest()[:12]
            elif isinstance(v,str):
                # Errors from ffprobe/libmpv can contain private absolute paths.
                # Retain the diagnostic description but strip Windows locations.
                cleaned=re.sub(r'(?i)(?:[A-Z]:\\|\\\\)[^\r\n\"<>|]+', '[path redacted]', v)
                safe[k]=cleaned
            elif isinstance(v,(int,float,bool)) or v is None:
                safe[k]=v
        self.events.append(Event(datetime.now(timezone.utc).isoformat(),category,message,safe))

    def dump(self):
        return [asdict(e) for e in self.events]
