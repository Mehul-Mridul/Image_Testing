"""Deterministic sequential/pattern sets. Incomplete pattern slots remain empty."""
from dataclasses import dataclass
from pathlib import Path
import re
from typing import Sequence

from .media_catalog import natural_key


@dataclass(frozen=True)
class ComparisonSet:
    key: str
    slots: tuple[str | None, ...]


@dataclass(frozen=True)
class PatternRule:
    """A compiled regex must provide named `key` and `variant` captures.

    Example: `(?P<key>.+?)_(?P<variant>Original|ISP|HDR|Denoised)$`
    Matches filename STEM (not extension), ignores case.
    """
    expression: str
    variants: tuple[str, ...]

    def __post_init__(self):
        if not 1 <= len(self.variants) <= 4:
            raise ValueError('Pattern requires one to four ordered variants')
        if len({v.casefold() for v in self.variants}) != len(self.variants):
            raise ValueError('Variant names must be unique')
        regex = re.compile(self.expression,re.IGNORECASE)
        if not {'key','variant'}.issubset(regex.groupindex):
            raise ValueError('Pattern must contain named groups key and variant')

    def parse(self, path: str):
        match=re.fullmatch(self.expression,Path(path).stem,re.IGNORECASE)
        if not match:
            return None
        variant=match.group('variant')
        for i,v in enumerate(self.variants):
            if v.casefold()==variant.casefold():
                return (match.group('key'),i)
        return None


def sequential_sets(paths: Sequence[str], pane_count: int, *, preserve_order: bool=False) -> list[ComparisonSet]:
    if not 1<=pane_count<=4: raise ValueError('pane_count must be 1-4')
    paths=(list(dict.fromkeys(map(str,paths))) if preserve_order else
           sorted(set(map(str,paths)),key=lambda p:natural_key(Path(p).name)))
    return [ComparisonSet(f'Set {i//pane_count+1}',tuple(paths[i:i+pane_count]) +
                          (None,)*(pane_count-len(paths[i:i+pane_count])))
            for i in range(0,len(paths),pane_count)]


def pattern_sets(paths: Sequence[str], rule: PatternRule) -> tuple[list[ComparisonSet],list[str]]:
    groups: dict[str,list[str | None]]={}
    labels: dict[str,str]={}
    invalid=[]
    for path in sorted(set(map(str,paths)),key=natural_key):
        parsed=rule.parse(path)
        if not parsed:
            invalid.append(path)
            continue
        key,slot=parsed
        normalized=key.casefold()
        labels.setdefault(normalized,key)
        group=groups.setdefault(normalized,[None]*len(rule.variants))
        if group[slot] is not None:
            invalid.append(path) # Collision; do not silently overwrite a variant
            continue
        group[slot]=path
    return ([ComparisonSet(labels[k],tuple(groups[k])) for k in sorted(groups,key=lambda k:natural_key(labels[k]))], invalid)


class SetNavigator:
    def __init__(self):
        self.sets: list[ComparisonSet]=[]
        self.index=0
        self.generation=0

    def configure(self, sets: Sequence[ComparisonSet]):
        self.sets=list(sets)
        self.index=0
        self.generation+=1
        return self.current

    @property
    def current(self) -> ComparisonSet | None:
        return self.sets[self.index] if self.sets else None

    def move(self, steps: int) -> ComparisonSet | None:
        if not self.sets: return None
        self.index=max(0,min(len(self.sets)-1,self.index+steps))
        self.generation+=1
        return self.current
