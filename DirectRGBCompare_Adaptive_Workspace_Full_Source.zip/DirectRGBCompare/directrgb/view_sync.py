"""Shared view controller applying normalized pan and zoom across panes."""
from dataclasses import replace
from .view_geometry import Geometry,ViewState,clamp

class ViewCoordinator:
    def __init__(self,count=4):
        self.states={i:ViewState() for i in range(count)}
        self.zoom_sync=True
        self.pan_sync=True

    def reset(self, mode='fit', indexes=None):
        for i in self._keys(indexes): self.states[i]=ViewState(mode=mode)

    def _keys(self,indexes=None):
        return list(self.states) if indexes is None else list(indexes)

    def zoom(self,index,geometry: Geometry,x,y,factor,other_geometries):
        old=self.states[index]
        fresh=geometry.anchored_zoom(old,x,y,factor)
        self.states[index]=fresh
        for j,other_geo in other_geometries.items():
            if j==index:continue
            new=self.states[j]
            if self.zoom_sync:
                new=replace(new,mode=fresh.mode,magnification=fresh.magnification)
            if self.pan_sync:
                new=replace(new,cx=fresh.cx,cy=fresh.cy)
            self.states[j]=new
        return fresh

    def pan(self,index,geometry:Geometry,dx,dy,others):
        fresh=geometry.drag_pan(self.states[index],dx,dy)
        self.states[index]=fresh
        if self.pan_sync:
            for j in others:
                if j!=index:
                    self.states[j]=replace(self.states[j],cx=fresh.cx,cy=fresh.cy)
        return fresh
