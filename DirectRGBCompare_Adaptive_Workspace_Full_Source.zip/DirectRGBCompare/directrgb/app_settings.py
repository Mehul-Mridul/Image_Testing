"""Versioned, atomic JSON settings, stored in user config rather than the source tree."""
from __future__ import annotations
import json
import os
from pathlib import Path
import tempfile

VERSION=1


def default_settings_path() -> Path:
    root=os.environ.get('LOCALAPPDATA') or os.environ.get('XDG_CONFIG_HOME') or str(Path.home()/'.config')
    return Path(root)/'DirectRGBCompare'/'settings.json'


class AppSettings:
    def __init__(self,path=None):
        self.path=Path(path) if path else default_settings_path()
        self.data={'schema':VERSION,'last_folder':'','shortcuts':{},'recursive_scan':False,
                   'browser_visible':False,'diagnostics_visible':False,'advanced_visible':False,
                   'pane_tools_visible':False,'layout_mode':'auto',
                   'manual_layouts':{},'preferred_layout':''}
        self.load()

    def load(self):
        if not self.path.is_file(): return
        try:
            val=json.loads(self.path.read_text(encoding='utf8'))
            if isinstance(val,dict) and val.get('schema')==VERSION:
                for key in self.data:
                    if key in val and isinstance(val[key],type(self.data[key])):
                        self.data[key]=val[key]
        except (OSError,ValueError):
            pass # Preserve usable defaults; don't crash media inspection.

    def save(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        fd,temp=tempfile.mkstemp(prefix='.settings-',suffix='.json',dir=self.path.parent)
        try:
            with os.fdopen(fd,'w',encoding='utf8') as fp:
                json.dump(self.data,fp,indent=2)
                fp.flush();os.fsync(fp.fileno())
            os.replace(temp,self.path)
        finally:
            if os.path.exists(temp):os.unlink(temp)
