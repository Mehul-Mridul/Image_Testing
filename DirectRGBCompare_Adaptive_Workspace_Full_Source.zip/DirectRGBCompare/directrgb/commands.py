"""Validated shortcut mapping (pure state) and Qt QAction integration."""
from dataclasses import dataclass

@dataclass(frozen=True)
class Command:
    command_id: str
    label: str
    default: str
    category: str = 'General'

class ShortcutMap:
    def __init__(self):
        self.definitions:dict[str,Command]={}
        self.custom:dict[str,str]={}

    def register(self,command:Command):
        if command.command_id in self.definitions:
            raise ValueError(f'Duplicate command ID: {command.command_id}')
        self.definitions[command.command_id]=command

    def sequence(self,command_id):
        return self.custom.get(command_id,self.definitions[command_id].default)

    def assign(self,command_id,sequence):
        if command_id not in self.definitions:raise KeyError(command_id)
        normalize=lambda s:s.replace(' ','').casefold()
        if sequence:
            for other in self.definitions:
                if other!=command_id and normalize(self.sequence(other))==normalize(sequence):
                    raise ValueError(f'Shortcut already assigned to {self.definitions[other].label}')
        self.custom[command_id]=sequence

    def reset(self,command_id=None):
        if command_id is None:self.custom.clear()
        else:self.custom.pop(command_id,None)


class QtCommandRegistry:
    """QAction wrapper; install Qt input focus guard in application GUI."""
    def __init__(self,parent,settings):
        from PySide6.QtGui import QAction, QKeySequence
        from PySide6.QtCore import Qt
        self.parent=parent
        self.settings=settings
        self.map=ShortcutMap()
        self.actions={}
        self.QAction=QAction
        self.QKeySequence=QKeySequence
        self.Qt=Qt

    def register(self,command_id,label,default,callback,action=None,category='General'):
        self.map.register(Command(command_id,label,default,category))
        if action is None:
            action=self.QAction(label,self.parent)
            self.parent.addAction(action)
        action.setShortcutContext(self.Qt.ShortcutContext.ApplicationShortcut)
        if callback is not None:
            action.triggered.connect(lambda *_: callback())
        self.actions[command_id]=action
        override=self.settings.data.get('shortcuts',{}).get(command_id)
        if override is not None:
            try:self.map.assign(command_id,override)
            except ValueError:pass
        self._update()
        return action

    def _update(self):
        for cid,action in self.actions.items():
            action.setShortcut(self.QKeySequence(self.map.sequence(cid)))

    def change(self,command_id,sequence):
        if sequence and self.QKeySequence(sequence).isEmpty():
            raise ValueError('Invalid key sequence')
        self.map.assign(command_id,sequence)
        self.settings.data['shortcuts']=dict(self.map.custom)
        self.settings.save()
        self._update()

    def reset_all(self):
        self.map.reset()
        self.settings.data['shortcuts']={}
        self.settings.save()
        self._update()
