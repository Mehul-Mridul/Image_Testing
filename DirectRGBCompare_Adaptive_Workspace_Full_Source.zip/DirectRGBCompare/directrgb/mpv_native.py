"""Minimal ctypes libmpv binding. Each pane has a native child HWND on Windows.

libmpv owns decoding/rendering threads; Python never copies frame arrays into QLabel.
This is a practical embedded-player prototype, NOT a demonstrated bit-exact renderer.
"""
from __future__ import annotations
import ctypes as C
import os
import sys
from typing import Optional
from .paths import mpv_library_candidates
from .policy import DIRECT_OPTIONS, Overrides

MPV_FORMAT_STRING = 1
MPV_FORMAT_FLAG = 3
MPV_FORMAT_INT64 = 4
MPV_FORMAT_DOUBLE = 5

class MpvError(RuntimeError):
    pass


def load_mpv():
    errors = []
    for candidate in mpv_library_candidates():
        try:
            if os.path.isabs(candidate) and not os.path.isfile(candidate):
                continue
            if sys.platform == 'win32':
                # Adds directory of DLL and dependent DLLs to Windows DLL search path.
                dirname = os.path.dirname(candidate)
                if dirname and hasattr(os, 'add_dll_directory'):
                    # Keep search cookie alive for lifetime of process.
                    _dll_cookies.append(os.add_dll_directory(os.path.abspath(dirname)))
                dll = C.CDLL(candidate)
            else:
                dll = C.CDLL(candidate)
            _configure(dll)
            return dll
        except (OSError, AttributeError) as exc:
            errors.append(f'{candidate}: {exc}')
    raise MpvError('libmpv not found. Place libmpv-2.dll and dependent DLLs in vendor/bin. ' + '; '.join(errors[-3:]))

_dll_cookies = []

def _configure(lib):
    lib.mpv_create.argtypes = []
    lib.mpv_create.restype = C.c_void_p
    lib.mpv_client_api_version.argtypes = []
    lib.mpv_client_api_version.restype = C.c_ulong
    lib.mpv_initialize.argtypes = [C.c_void_p]
    lib.mpv_initialize.restype = C.c_int
    lib.mpv_set_option_string.argtypes = [C.c_void_p, C.c_char_p, C.c_char_p]
    lib.mpv_set_option_string.restype = C.c_int
    lib.mpv_set_property_string.argtypes = [C.c_void_p, C.c_char_p, C.c_char_p]
    lib.mpv_set_property_string.restype = C.c_int
    lib.mpv_get_property.argtypes = [C.c_void_p, C.c_char_p, C.c_int, C.c_void_p]
    lib.mpv_get_property.restype = C.c_int
    lib.mpv_command.argtypes = [C.c_void_p, C.POINTER(C.c_char_p)]
    lib.mpv_command.restype = C.c_int
    lib.mpv_command_async.argtypes = [C.c_void_p, C.c_uint64, C.POINTER(C.c_char_p)]
    lib.mpv_command_async.restype = C.c_int
    lib.mpv_error_string.argtypes = [C.c_int]
    lib.mpv_error_string.restype = C.c_char_p
    lib.mpv_free.argtypes = [C.c_void_p]
    lib.mpv_free.restype = None
    lib.mpv_terminate_destroy.argtypes = [C.c_void_p]
    lib.mpv_terminate_destroy.restype = None
    lib.mpv_wait_event.argtypes = [C.c_void_p, C.c_double]
    lib.mpv_wait_event.restype = C.c_void_p


class MpvPanePlayer:
    def __init__(self, window_id: int, lib=None):
        if sys.platform != 'win32':
            raise MpvError('Embedded Direct3D 11 backend is Windows-only.')
        self.lib = lib or load_mpv()
        self.handle = self.lib.mpv_create()
        if not self.handle:
            raise MpvError('mpv_create failed')
        self._closed = False
        self.effective_options = {}
        try:
            # An HWND is pointer-sized: truncating to 32 bits breaks x64 embedding.
            if window_id <= 0:
                raise MpvError("Qt did not provide a native Win32 window handle")
            self._option('wid', str(window_id))
            for key, value in DIRECT_OPTIONS.items():
                self._option(key, value)
            self._check(self.lib.mpv_initialize(self.handle), 'mpv_initialize')
            self._next_userdata = 1
        except Exception:
            self.close()
            raise

    def _check(self, code: int, where: str):
        if code < 0:
            message = self.lib.mpv_error_string(code)
            raise MpvError(f'{where}: {message.decode(errors="replace") if message else code}')

    def _option(self, name: str, value: str):
        self._check(self.lib.mpv_set_option_string(self.handle, name.encode(), str(value).encode()), f'mpv option {name}={value}')
        self.effective_options[name] = str(value)  # Accepted request, NOT measured output!

    def command(self, *args: str):
        array = (C.c_char_p * (len(args) + 1))(*(str(a).encode('utf-8') for a in args), None)
        self._check(self.lib.mpv_command(self.handle, array), 'mpv command ' + str(args[0]))

    def command_async(self, *args: str):
        """Queue potentially slow loads/seeks instead of running them in Qt UI thread."""
        array = (C.c_char_p * (len(args) + 1))(*(str(a).encode('utf-8') for a in args), None)
        req = self._next_userdata
        self._next_userdata += 1
        self._check(self.lib.mpv_command_async(self.handle, req, array),
                    'queue mpv command ' + str(args[0]))
        return req

    def set(self, name: str, value):
        self._check(self.lib.mpv_set_property_string(self.handle, name.encode(), str(value).encode()), f'set {name}')

    def get_str(self, name: str) -> Optional[str]:
        value = C.c_char_p()
        rc = self.lib.mpv_get_property(self.handle, name.encode(), MPV_FORMAT_STRING, C.byref(value))
        if rc < 0 or not value:
            return None
        try:
            return C.string_at(value).decode('utf-8', errors='replace')
        finally:
            self.lib.mpv_free(C.cast(value, C.c_void_p))

    def get_double(self, name: str) -> Optional[float]:
        val = C.c_double()
        if self.lib.mpv_get_property(self.handle, name.encode(), MPV_FORMAT_DOUBLE, C.byref(val)) < 0:
            return None
        return val.value

    def get_int(self, name: str) -> Optional[int]:
        val = C.c_int64()
        if self.lib.mpv_get_property(self.handle, name.encode(), MPV_FORMAT_INT64, C.byref(val)) < 0:
            return None
        return val.value

    def get_bool(self, name: str) -> Optional[bool]:
        val = C.c_int()
        if self.lib.mpv_get_property(self.handle, name.encode(), MPV_FORMAT_FLAG, C.byref(val)) < 0:
            return None
        return bool(val.value)

    def load(self, path: str):
        self.command_async('loadfile', path, 'replace')
        self.set('pause', 'yes')

    def pause(self, paused: bool):
        self.set('pause', 'yes' if paused else 'no')

    def seek(self, t: float):
        self.command_async('seek', f'{max(0, t):.6f}', 'absolute+exact')

    def apply_overrides(self, overrides: Overrides):
        value = overrides.combined_mpv_override()
        # Changing input interpretation can require decoder reinit; explicit mode only.
        self.set('vf', value)

    def clear(self):
        self.command('stop')

    def drain_events(self):
        """Consume completion errors and load state without accessing stale mpv memory."""
        events = []
        class Event(C.Structure):
            _fields_ = [('event_id', C.c_int), ('error', C.c_int),
                        ('reply_userdata', C.c_uint64), ('data', C.c_void_p)]
        for _ in range(64):
            raw = self.lib.mpv_wait_event(self.handle, 0)
            if not raw:
                break
            event = C.cast(raw, C.POINTER(Event)).contents
            if event.event_id == 0:
                break
            if event.error < 0 or event.event_id in (7, 8):
                message = self.lib.mpv_error_string(event.error)
                events.append({'event': int(event.event_id), 'error': int(event.error),
                               'message': message.decode('utf-8', errors='replace') if message else ''})
        return events

    def runtime_diagnostics(self):
        keys = (
            'mpv-version', 'libmpv-version', 'current-vo', 'current-gpu-context', 'hwdec-current',
            'hwdec-interop', 'video-params/pixelformat',
            'video-params/colormatrix', 'video-params/colorlevels',
            'video-params/primaries', 'video-params/gamma',
            'video-dec-params/colormatrix', 'video-dec-params/colorlevels',
            'video-target-params/colormatrix', 'video-target-params/colorlevels',
            'video-target-params/primaries', 'video-target-params/gamma',
        )
        result = {k: self.get_str(k) or 'Unavailable' for k in keys}
        result.update({k: self.get_int(k) for k in ('frame-drop-count', 'vo-drop-frame-count')})
        result['video-pts'] = self.get_double('video-pts')
        result['libmpv_client_api_version'] = hex(self.lib.mpv_client_api_version())
        result['vo_configured'] = self.get_bool('vo-configured')
        result['swapchain_actual_format'] = 'UNVERIFIED: gpu-next treats rgba8 as a hint'
        result['swapchain_actual_color_space'] = 'UNVERIFIED: DXGI inspection required'
        result['actual_tone_mapping_active'] = 'UNVERIFIED: inspect live GPU pipeline; HDR sources blocked'
        result['requested_options'] = dict(self.effective_options)
        result['observed_options'] = {
            k: self.get_str('options/' + k) for k in DIRECT_OPTIONS
        }
        return result

    def close(self):
        if not self._closed:
            self._closed = True
            if self.handle:
                self.lib.mpv_terminate_destroy(self.handle)
                self.handle = None
