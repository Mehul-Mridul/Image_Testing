"""Independent (non-mpv) FFmpeg zscale decode and numerical image comparison.

This validates reference extraction and reported differences. It does NOT prove
that Windows DWM emitted those bytes to the monitor. See docs/VALIDATION.md.
"""
from __future__ import annotations
import argparse
from collections import Counter
import json
import re
from pathlib import Path
import subprocess
import tempfile
import numpy as np
from PIL import Image
from .paths import bundled_tool
from .probe import probe_file, VideoMetadata

MATRICES = {'bt709': '709', 'smpte170m': '170m', 'bt470bg': '470bg',
            'bt2020nc': '2020_ncl', 'smpte240m': '240m', 'fcc': 'fcc'}
RANGES = {'tv': 'limited', 'mpeg': 'limited', 'pc': 'full', 'jpeg': 'full',
          'limited': 'limited', 'full': 'full'}


def reference_png(src: str, dst: str, seconds: float = 0, *,
                  range_override: str = 'auto', matrix_override: str = 'auto') -> dict:
    """Select first frame with presentation time >= requested seconds.

    zscale reconstructs RGB using explicit matrix and range; source transfer and
    primaries are preserved, not converted to another display color space.
    Chroma interpolation/rounding may legitimately differ from mpv/libplacebo.
    """
    meta = probe_file(src)
    if seconds < 0:
        raise ValueError('Timestamp must be nonnegative')
    matrix = matrix_override if matrix_override != 'auto' else meta.matrix
    rg = range_override if range_override != 'auto' else meta.range
    if meta.pix_fmt.lower().startswith(('rgb', 'bgr', 'gbr', 'rgba', 'bgra')):
        vf = f'select=gte(t\\,{seconds:.6f}),showinfo,format=rgb24'
        conversion = 'Direct RGB pixel format (format repack if needed)'
    else:
        if matrix not in MATRICES or rg not in RANGES:
            raise ValueError('Cannot establish numeric RGB reference: missing/unsupported matrix or range. '
                             f'matrix={matrix!r}, range={rg!r}. Specify diagnostic overrides explicitly.')
        # matrix=gbr selects RGB output, range=full selects 0..255 RGB encoding.
        # `format=gbrp` before `format=rgb24` prevents another YUV matrix conversion.
        vf = (f'select=gte(t\\,{seconds:.6f}),showinfo,'
              f'zscale=matrixin={MATRICES[matrix]}:rangein={RANGES[rg]}:'
              'matrix=gbr:range=full:filter=bilinear,format=gbrp,format=rgb24')
        conversion = f'zscale {matrix} {rg} -> full-range RGB, bilinear chroma reconstruction'
    out = Path(dst)
    out.parent.mkdir(parents=True, exist_ok=True)
    cmd = [bundled_tool('ffmpeg'), '-hide_banner', '-nostdin', '-loglevel', 'info', '-y',
           '-i', str(src), '-map', '0:v:0', '-an', '-vf', vf,
           '-fps_mode', 'vfr', '-frames:v', '1', '-threads:v', '1', str(out)]
    completed = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    if completed.returncode or not out.is_file():
        raise RuntimeError('Reference decode failed: ' + completed.stderr[-2000:])
    match = re.search(r'\bpts_time:([-+0-9.]+)', completed.stderr)
    observed_pts = float(match.group(1)) if match else None
    report = {'source': str(Path(src).resolve()), 'png': str(out.resolve()),
              'actual_selected_pts_seconds': observed_pts,
              'requested_seconds': seconds, 'selection': 'first decoded frame with PTS >= requested timestamp',
              'matrix_selected': matrix, 'range_selected': rg, 'conversion': conversion,
              'filter': vf, 'decoder': 'FFmpeg zscale (independent from mpv GPU pipeline)',
              'ffmpeg_command': cmd}
    out.with_suffix('.json').write_text(json.dumps(report, indent=2), encoding='utf-8')
    return report


def make_chart(path: str, width=1280, height=720):
    """Unprofiled SDR RGB PNG; known swatches, skin approximations, gradients."""
    if width < 480 or height < 300:
        raise ValueError('Reference chart requires >=480x300')
    rgb = np.zeros((height, width, 3), dtype=np.uint8)
    swatches = [
        ('red', (255, 0, 0)), ('green', (0, 255, 0)), ('blue', (0, 0, 255)),
        ('white', (255, 255, 255)), ('black', (0, 0, 0)), ('gray128', (128, 128, 128)),
        ('skin_light_approx', (224, 172, 143)), ('skin_mid_approx', (169, 111, 82)),
        ('skin_dark_approx', (96, 57, 39)), ('shadow4', (4, 4, 4)),
        ('highlight250', (250, 250, 250)), ('gray32', (32, 32, 32)),
    ]
    strip_height = height // 3
    col_width = width // len(swatches)
    labels = {}
    for idx, (name, triplet) in enumerate(swatches):
        x0, x1 = idx*col_width, (idx+1)*col_width if idx<len(swatches)-1 else width
        rgb[:strip_height, x0:x1] = triplet
        labels[name] = {'rgb': list(triplet), 'sample_xy': [(x0+x1)//2, strip_height//2]}
    x = np.linspace(0, 255, width, dtype=np.float32).round().astype(np.uint8)
    for c in range(3):
        rgb[strip_height:2*strip_height, :, c] = x[None, :]
    rgb[2*strip_height:, :, 0] = x[None, :]
    rgb[2*strip_height:, :, 1] = x[::-1][None, :]
    rgb[2*strip_height:, :, 2] = np.roll(x, width//4)[None, :]
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    Image.fromarray(rgb, 'RGB').save(path)
    return {'png': str(path.resolve()), 'width': width, 'height': height,
            'profile': 'No ICC profile embedded', 'swatches': labels}


def compare_png(reference: str, actual: str, diff_path: str | None = None):
    a = np.asarray(Image.open(reference).convert('RGB'), dtype=np.uint8)
    b = np.asarray(Image.open(actual).convert('RGB'), dtype=np.uint8)
    if a.shape != b.shape:
        raise ValueError(f'Image dimensions mismatch: {a.shape} vs {b.shape}. '
                         'Crop/align video rectangle and use true 100% scaling before comparison.')
    diff = np.abs(a.astype(np.int16) - b.astype(np.int16)).astype(np.uint8)
    per_pixel_max = diff.max(axis=2)
    per_channel = {}
    for i, ch in enumerate('RGB'):
        d = diff[:, :, i]
        counts = np.bincount(d.ravel(), minlength=256)
        per_channel[ch] = {'max': int(d.max()), 'mae': float(d.mean()),
                           'histogram': {str(k): int(v) for k, v in enumerate(counts) if v}}
    result = {
        'reference': str(Path(reference).resolve()), 'actual': str(Path(actual).resolve()),
        'shape': list(a.shape), 'max_absolute_rgb_difference': int(diff.max()),
        'mean_absolute_rgb_difference': float(diff.mean()),
        'exact_pixel_match_pct': float(np.mean(per_pixel_max == 0) * 100),
        'pixels_with_all_channels_diff_le_1_pct': float(np.mean(per_pixel_max <= 1) * 100),
        'pixels_with_exactly_one_max_code_difference_pct': float(np.mean(per_pixel_max == 1) * 100),
        'per_channel': per_channel,
        'limitations': 'This compares supplied images, not a verified pre-DWM or physical display capture.',
    }
    if diff_path:
        vis = np.clip(diff.astype(np.int16)*8, 0, 255).astype(np.uint8)
        Image.fromarray(vis, 'RGB').save(diff_path)
        result['difference_heatmap_8x'] = str(Path(diff_path).resolve())
    return result


def main():
    parser = argparse.ArgumentParser(prog='python -m directrgb.validation')
    sub = parser.add_subparsers(dest='command', required=True)
    chart = sub.add_parser('chart'); chart.add_argument('output')
    extract = sub.add_parser('extract'); extract.add_argument('video'); extract.add_argument('output')
    extract.add_argument('--at', type=float, default=0)
    extract.add_argument('--range', choices=['auto', 'limited', 'full'], default='auto')
    extract.add_argument('--matrix', choices=['auto', *MATRICES], default='auto')
    comp = sub.add_parser('compare'); comp.add_argument('reference'); comp.add_argument('actual')
    comp.add_argument('--heatmap')
    args = parser.parse_args()
    if args.command == 'chart':
        result = make_chart(args.output)
    elif args.command == 'extract':
        result = reference_png(args.video, args.output, args.at,
                               range_override=args.range, matrix_override=args.matrix)
    else:
        result = compare_png(args.reference, args.actual, args.heatmap)
    print(json.dumps(result, indent=2))

if __name__ == '__main__':
    main()
