"""One subprocess runner for desktop runtime operations, never a shell/cmd wrapper.

Windows FFmpeg/FFprobe processes use CREATE_NO_WINDOW even if launched from a
windowed PyInstaller EXE. stdout/stderr are captured for diagnostics.
"""
from __future__ import annotations
import subprocess
import sys
from time import monotonic


def process_options(platform=None):
    platform = platform or sys.platform
    if platform != 'win32':
        return {}
    # Windows Python defines CREATE_NO_WINDOW. Literal value makes policy
    # unit-testable on Linux without calling Win32-only STARTUPINFO.
    return {'creationflags': getattr(subprocess, 'CREATE_NO_WINDOW', 0x08000000)}


class CancelledProcess(RuntimeError):
    """A superseded metadata request canceled its external utility."""


def run_command(argv, *, timeout=25, max_output_bytes=5_000_000, cancel_event=None):
    if isinstance(argv, str) or not argv:
        raise ValueError('Runtime commands require a nonempty argument list, never shell text')
    if timeout <= 0:
        raise ValueError('A bounded timeout is required')
    if cancel_event is not None and cancel_event.is_set():
        raise CancelledProcess('Probe cancelled before start')
    # Qt probes use a cancellation-aware child process, not a blocking
    # subprocess.run that holds a worker after its comparison set was replaced.
    if cancel_event is None:
        completed = subprocess.run(list(map(str, argv)), shell=False,
                                   capture_output=True, timeout=timeout, check=False,
                                   **process_options())
    else:
        proc = subprocess.Popen(list(map(str, argv)),shell=False,
                                stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                                **process_options())
        started=monotonic()
        try:
            while True:
                if cancel_event.is_set():
                    raise CancelledProcess('Probe replaced by a newer load request')
                remaining=timeout-(monotonic()-started)
                if remaining<=0:
                    raise subprocess.TimeoutExpired(argv, timeout)
                try:
                    out,err=proc.communicate(timeout=min(.15,remaining))
                    break
                except subprocess.TimeoutExpired:
                    pass
        except (CancelledProcess,subprocess.TimeoutExpired):
            proc.kill()
            proc.communicate()
            raise
        completed = subprocess.CompletedProcess(argv,proc.returncode,out,err)
    if len(completed.stdout) > max_output_bytes or len(completed.stderr) > max_output_bytes:
        raise RuntimeError('External utility output exceeded maximum accepted size')
    return completed
