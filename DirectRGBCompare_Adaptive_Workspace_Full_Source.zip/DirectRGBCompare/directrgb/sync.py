"""Presentation-time synchronization policies, separately unit-testable."""
from dataclasses import dataclass
from math import isfinite

@dataclass
class Clock:
    master_position: float = 0.0
    paused: bool = True
    speed: float = 1.0
    loop: bool = False

    @staticmethod
    def local_time(master: float, offset: float, start: float = 0.0) -> float:
        # A positive offset means local footage starts later than comparison master.
        return max(0.0, master + offset + start)

    @staticmethod
    def error_ms(actual_pts: float | None, target_pts: float) -> float | None:
        if actual_pts is None or not isfinite(actual_pts):
            return None
        return (actual_pts - target_pts) * 1000.0

    @staticmethod
    def tolerance_seconds(fps: float) -> float:
        # Seeking corrections are costly for 4K streams. This is a threshold for
        # re-seeking during PLAY, not a claim of exact frame alignment.
        return max(0.100, 2.0 / fps) if fps > 0 else 0.100

    @staticmethod
    def nearest_frame_time(target: float, timestamps: list[float]):
        if not timestamps:
            return None
        return min(timestamps, key=lambda t: (abs(t-target), t))
