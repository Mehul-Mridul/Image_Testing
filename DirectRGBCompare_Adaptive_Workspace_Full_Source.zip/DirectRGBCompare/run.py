from directrgb.vnext_gui import run

if __name__ == '__main__':
    raise SystemExit(run())
