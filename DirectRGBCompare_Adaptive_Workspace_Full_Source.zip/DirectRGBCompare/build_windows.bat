@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Install-And-Build.ps1"
if errorlevel 1 (pause & exit /b 1)
echo EXE built. Open dist\DirectRGBCompare\DirectRGBCompare.exe
pause
