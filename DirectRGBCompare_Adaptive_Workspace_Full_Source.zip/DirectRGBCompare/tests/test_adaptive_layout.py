import pytest
from directrgb.adaptive_layout import (LayoutRequest,choose_layout,resize_split,
                                        Rect,orientations)
from directrgb.probe import VideoMetadata
from dataclasses import replace


@pytest.mark.parametrize('aspects,expected',[
    ((16/9,), 'single'),
    ((16/9,16/9),'side-by-side'),
    ((9/16,9/16),'side-by-side'),
    ((9/16,)*3,'three-columns'),
    ((16/9,)*4,'two-by-two'),
    ((9/16,)*4,'four-columns'),
])
def test_adaptive_choices_and_geometry(aspects,expected):
    result=choose_layout(LayoutRequest(1300,760,aspects))
    assert result.name==expected
    assert set(result.rectangles)==set(range(len(aspects)))
    for r in result.rectangles.values():
        assert r.w>=135 and r.h>=115
        assert 0<=r.x and 0<=r.y
        assert r.x+r.w<=1300 and r.y+r.h<=760
    rectangles=list(result.rectangles.values())
    for i,a in enumerate(rectangles):
        for b in rectangles[i+1:]:
            assert min(a.x+a.w,b.x+b.w)<=max(a.x,b.x) or min(a.y+a.h,b.y+b.h)<=max(a.y,b.y)


def test_mixed_layout_valid_and_focus():
    aspects=(16/9,9/16,16/9,9/16)
    res=choose_layout(LayoutRequest(1300,760,aspects))
    assert len(res.rectangles)==4
    focused=choose_layout(LayoutRequest(1300,760,aspects,focused=2))
    assert focused.rectangles=={2: Rect(0,0,1300,760)}


def test_hysteresis_and_manual_split_are_stable():
    req=LayoutRequest(1300,760,(16/9,16/9))
    first=choose_layout(req)
    assert first.dividers
    split=first.dividers[0][0]
    edited=resize_split(first,split,.36)
    modified=choose_layout(LayoutRequest(1300,760,req.aspects,preferred=first.name),
                           manual={first.name:edited})
    assert modified.ratios[split]==.36
    assert modified.name==first.name
    assert choose_layout(req,previous=first).name==first.name
    with pytest.raises(ValueError):resize_split(first,split,1.2)


def test_orientation_rotation_and_sar():
    base=VideoMetadata(path='a',codec='x',width=1920,height=1080,
        avg_frame_rate='30/1',r_frame_rate='30/1',pix_fmt='yuv420p',bit_depth='8',
        chroma_subsampling='4:2:0',range='tv',primaries='bt709',transfer='bt709',
        matrix='bt709',chroma_location='left',duration=2,start_time=0,sar='1:1',
        rotation='0',hdr='SDR',hdr_side_data=[],first_frame_side_data=[],first_frame_tags={})
    assert orientations(base)==pytest.approx(16/9)
    assert orientations(replace(base,rotation='90'))==pytest.approx(9/16)
    assert orientations(replace(base,sar='2:1'))==pytest.approx(32/9)
    assert orientations(None)==pytest.approx(16/9)


def test_bad_dimensions_and_count_fail_closed():
    with pytest.raises(ValueError):choose_layout(LayoutRequest(0,200,(16/9,)))
    with pytest.raises(ValueError):choose_layout(LayoutRequest(200,200,()))
    with pytest.raises(ValueError):choose_layout(LayoutRequest(200,200,(1,)*5))
