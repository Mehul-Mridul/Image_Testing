from dataclasses import replace
from pathlib import Path
from directrgb.probe import probe_file


TEST = Path(__file__).resolve().parents[1] / 'assets' / 'test_yuv420_bt709_limited.mkv'


def test_hdr_tags_do_not_fall_through():
    meta = probe_file(str(TEST))
    assert meta.eligibility[0]
    inconsistent = replace(meta, first_frame_tags={'color_transfer': 'smpte2084'})
    assert not inconsistent.eligibility[0]


def test_hdr_side_data_do_not_fall_through():
    meta = probe_file(str(TEST))
    inconsistent = replace(meta, hdr_side_data=[{'side_data_type': 'Mastering display metadata'}])
    assert not inconsistent.eligibility[0]
