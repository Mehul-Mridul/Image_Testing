import sys
import threading
import time
from pathlib import Path
import pytest
from directrgb.process_runner import run_command, CancelledProcess


def test_cancel_before_process_spawn():
    event=threading.Event();event.set()
    with pytest.raises(CancelledProcess):
        run_command([sys.executable,'-c','print(1)'],cancel_event=event)


def test_cancel_running_process_under_a_second():
    event=threading.Event()
    thread=threading.Timer(.12,event.set)
    started=time.monotonic()
    thread.start()
    with pytest.raises(CancelledProcess):
        run_command([sys.executable,'-c','import time;time.sleep(15)'],cancel_event=event,timeout=20)
    thread.join()
    assert time.monotonic()-started<2


def test_console_creation_flags_and_no_shell():
    import inspect
    import directrgb.process_runner as runner
    source=inspect.getsource(runner.run_command)
    assert 'shell=False' in source
    assert 'creationflags' in inspect.getsource(runner.process_options)
    assert "'CREATE_NO_WINDOW'" in inspect.getsource(runner.process_options)


def test_new_ui_modules_never_import_color_policy_into_geometry():
    root=Path(__file__).resolve().parents[1]/'directrgb'
    text=(root/'adaptive_layout.py').read_text()
    assert 'libmpv' not in text and 'color_math' not in text and 'DIRECT_OPTIONS' not in text


def test_ui_wiring_includes_automatic_replacement_and_video_first_canvas():
    root=Path(__file__).resolve().parents[1]/'directrgb'
    vnext=(root/'vnext_gui.py').read_text()
    assert "plan_load(paths,active_pane=start" in vnext
    assert "self.canvas=AdaptiveWorkspace(self.panes,self)" in vnext
    assert "self.setCentralWidget(self.canvas)" in vnext
    assert "('view.browser','Toggle File Browser','Ctrl+B'" in vnext
    assert "('file.load_selected','Load Selected','Ctrl+L'" in vnext
    assert 'Replace video?' not in vnext
    assert 'self._probe_tasks.clear()' in vnext
