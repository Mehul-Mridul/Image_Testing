"""External FFmpeg integration tests; fail if required bundled tools are missing."""
from pathlib import Path
import json
import subprocess
import numpy as np
import pytest
from PIL import Image
from directrgb.paths import bundled_tool
from directrgb.probe import probe_file
from directrgb.validation import make_chart, reference_png, compare_png


def test_lossless_rgb_ffv1_roundtrip(tmp_path):
    chart = tmp_path/'chart.png'; make_chart(chart,480,300)
    mkv = tmp_path/'rgb.mkv'
    cmd = [bundled_tool('ffmpeg'),'-v','error','-y','-loop','1','-framerate','1',
           '-i',str(chart),'-frames:v','1','-c:v','ffv1','-pix_fmt','gbrp',str(mkv)]
    subprocess.run(cmd, check=True, capture_output=True)
    out = tmp_path/'extracted.png'
    report = reference_png(str(mkv),str(out))
    result = compare_png(chart,out)
    assert result['max_absolute_rgb_difference'] == 0
    assert 'Direct RGB' in report['conversion']


def test_tagged_bt709_limited_reference_path(tmp_path):
    chart = tmp_path/'chart.png'; make_chart(chart,480,300)
    video = tmp_path/'limited.mkv'
    cmd = [bundled_tool('ffmpeg'),'-v','error','-y','-loop','1','-framerate','1','-i',str(chart),
           '-frames:v','1','-vf','format=yuv420p','-c:v','ffv1',
           '-color_range','tv','-colorspace','bt709','-color_primaries','bt709',
           '-color_trc','bt709',str(video)]
    subprocess.run(cmd,check=True,capture_output=True)
    meta = probe_file(video)
    assert meta.matrix == 'bt709'
    assert meta.range == 'tv'
    out = tmp_path/'ref.png'
    report = reference_png(str(video),str(out))
    assert out.is_file()
    assert report['matrix_selected'] == 'bt709'
