from dataclasses import replace
from pathlib import Path
import pytest
from directrgb.media_catalog import scan_folder,is_video,natural_key
from directrgb.comparison_sets import sequential_sets,pattern_sets,PatternRule,SetNavigator
from directrgb.pane_load import PaneLoadCoordinator
from directrgb.sync_alignment import align_here,target_pts,drift_ms
from directrgb.commands import ShortcutMap,Command
from directrgb.app_settings import AppSettings
from directrgb.diagnostic_events import EventLog


def test_file_scan_does_not_probe_or_decode(tmp_path):
    (tmp_path/'x.mp4').write_bytes(b'not a video')
    (tmp_path/'x.txt').write_text('txt')
    sub=tmp_path/'sub';sub.mkdir()
    (sub/'z.MKV').write_bytes(b'not a video')
    assert [x.name for x in scan_folder(tmp_path)]==['x.mp4']
    assert {x.name for x in scan_folder(tmp_path,recursive=True)}=={'x.mp4','z.MKV'}
    assert scan_folder(tmp_path/'sub',recursive=False)[0].name=='z.MKV'
    assert not is_video('bad.exe')


def test_natural_sort_and_group_padding():
    items=['A10.mp4','A2.mp4','A1.mp4','A3.mp4','A4.mp4']
    g=sequential_sets(items,4)
    assert g[0].slots==('A1.mp4','A2.mp4','A3.mp4','A4.mp4')
    assert g[1].slots==('A10.mp4',None,None,None)


def test_pattern_slots_stable_and_unmatched_reported():
    rule=PatternRule(r'(?P<key>.+?)_(?P<variant>Original|ISP|HDR|Denoised)',('Original','ISP','HDR','Denoised'))
    sets,unmatched=pattern_sets(['Test_2_HDR.mov','Test_1_ISP.mp4','Test_1_Original.MP4','Test_2_Original.mp4','README.txt'],rule)
    assert len(sets)==2
    assert sets[0].key=='Test_1'
    assert sets[0].slots[0]=='Test_1_Original.MP4'
    assert sets[0].slots[2] is None
    assert sets[1].slots[2]=='Test_2_HDR.mov'
    assert unmatched==['README.txt']


def test_pattern_duplicates_not_silently_overwritten():
    rule=PatternRule(r'(?P<key>.+?)_(?P<variant>Original|ISP)',('Original','ISP'))
    groups,unmatched=pattern_sets(['a_Original.mov','a_Original.mp4'],rule)
    assert len(groups)==1 and len(unmatched)==1


def test_set_generation_increments():
    n=SetNavigator();n.configure(sequential_sets(['1.mp4','2.mp4','3.mp4'],2))
    initial=n.generation
    assert n.current.slots[0]=='1.mp4'
    n.move(1)
    assert n.generation==initial+1


def test_load_generation_discards_superseded_responses():
    loads=PaneLoadCoordinator()
    old=loads.begin(0,'old.mp4',0)
    new=loads.begin(0,'new.mp4',1)
    assert not loads.active(0,old.token,old.set_generation)
    assert loads.complete(0,new.token,new.set_generation)
    assert not loads.active(0,new.token,new.set_generation)
    waiting=loads.begin(1,'third.mkv',2)
    loads.cancel(1)
    assert not loads.active(1,waiting.token,2)


def test_sync_offsets_preserve_frame_pts():
    s=align_here(0,{0:1.5,1:2.125,2:0.75})
    assert s.offsets=={0:0.0,1:0.625,2:-0.75}
    assert target_pts(3,s.offsets[2])==2.25
    assert target_pts(0,s.offsets[2]) is None
    assert target_pts(12,0,10) is None
    assert drift_ms(2.25,2.24)==pytest.approx(10.0)
    with pytest.raises(ValueError): align_here(0,{0:None,1:0.25})


def test_shortcuts_reject_conflicts_and_persist(tmp_path):
    reg=ShortcutMap()
    reg.register(Command('a','Open folder','Ctrl+Shift+O'))
    reg.register(Command('b','Add videos','Ctrl+O'))
    with pytest.raises(ValueError,match='already assigned'):reg.assign('b','Ctrl+Shift+O')
    reg.assign('a','Ctrl+J')
    assert reg.sequence('a')=='Ctrl+J'
    settings=AppSettings(tmp_path/'settings.json')
    settings.data['shortcuts']=dict(reg.custom)
    settings.save()
    assert AppSettings(settings.path).data['shortcuts']['a']=='Ctrl+J'
    reg.reset('a')
    assert reg.sequence('a')=='Ctrl+Shift+O'


def test_event_logs_redact_file_paths():
    log=EventLog(2)
    log.record('load','start',path=r'C:\Users\someone\private.mp4',pane=0)
    entry=log.dump()[0]
    assert 'private.mp4' not in str(entry)
    assert 'path_sha256_12' in entry['info']
    log.record('load','end');log.record('load','end')
    assert len(log.dump())==2


def test_timestamp_provenance_never_claims_unobserved_pts():
    from directrgb.sync_alignment import select_timestamp
    assert select_timestamp(1.2,1.22)==(1.2,'video-pts')
    t,kind=select_timestamp(None,1.22)
    assert t==1.22 and 'NOT measured frame PTS' in kind
    assert select_timestamp(None,None)==(None,'unavailable')


def test_explicit_catalog_sort_preserved_by_sequential_groups():
    paths=['newer.mp4','older.mp4','first.mp4']
    sets=sequential_sets(paths,2,preserve_order=True)
    assert sets[0].slots==('newer.mp4','older.mp4')
