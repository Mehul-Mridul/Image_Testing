"""Regression checks for 7zr.exe pinned-version mismatch (Windows report 2026-11-07).

These are source-level checks only; actual PowerShell/Windows curl execution
must be validated on Windows.
"""
from pathlib import Path

SRC=(Path(__file__).resolve().parents[1]/'scripts'/'Install-And-Build.ps1').read_text(encoding='utf-8')
BOOT=SRC.split('# 7-Zip standalone extractor:',1)[1].split('# FFmpeg release essentials',1)[0]

def test_pinned_immutable_7zip_source_and_expected_digest():
    assert 'https://github.com/ip7z/7zip/releases/download/26.05/7zr.exe' in BOOT
    assert 'https://sourceforge.net/projects/sevenzip/files/7-Zip/26.05/7zr.exe/download' in BOOT
    assert 'https://www.7-zip.org/a/7zr.exe' not in BOOT
    assert '9bf582b894dfa665f852d7e9112b02290a1c303c2d95a21fcdc41ffcb03143b7' in BOOT

def test_correctly_recognizes_previous_publisher_verified_2604_binary():
    assert '256feca8e274e5da655e2a284fabafd9f554365eb164862089dacd4e8276d282' in BOOT
    assert "$actualExtractorHash -eq $sevenZipHash2604" in BOOT
    assert '$extractorVerified = $true' in BOOT

def test_unknown_existing_binary_is_quarantined_not_executed():
    assert 'Move-Item -LiteralPath $extractor -Destination $quarantine -Force' in BOOT
    assert 'if (!$extractorVerified)' in BOOT
    assert 'Download-Pinned -Urls @(' in BOOT

def test_downloader_requires_archive_checksum():
    assert '-Path $extractor -Minimum 200000 -Hash $sevenZipHash2605' in BOOT
    assert 'Assert-Sha256 $Path $Hash' in SRC
