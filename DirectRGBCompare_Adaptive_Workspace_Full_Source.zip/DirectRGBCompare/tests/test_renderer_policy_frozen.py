"""Prevent accidental renderer/decoder-policy changes in the convenience release.

If the rendering pipeline is intentionally modified later, update this
baseline only after completing an independent RGB capture qualification.
"""
from pathlib import Path
from hashlib import sha256

BASELINE={
    'policy.py':'aa373c95266e5c45daadd11be620d60be9acda5931ef2eda71c4706825d89c5e',
    'mpv_native.py':'4d2cbe47de440178d38550798fc07ab2a02f000774fdff8c7dee24e8649c8424',
    'validation.py':'b39cc37f1ea8e0a5a9067ac6a1551365a4b56cd923ea71f367a7c7d3e5ffd5da',
    'color_math.py':'ed0904edc1c1989a879e88a450790cf020e71a4d39ddd5c853699166bbc18a3c',
}
ROOT=Path(__file__).resolve().parents[1] / 'directrgb'

def test_color_core_unchanged_from_v5_baseline():
    for name,digest in BASELINE.items():
        assert sha256((ROOT/name).read_bytes()).hexdigest()==digest, name
