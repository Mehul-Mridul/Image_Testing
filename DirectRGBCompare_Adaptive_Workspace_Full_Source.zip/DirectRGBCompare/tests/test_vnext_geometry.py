from dataclasses import replace
import pytest
from directrgb.view_geometry import Geometry,ViewState,parse_sar
from directrgb.view_sync import ViewCoordinator


def test_fit_aspect_with_letterbox():
    g=Geometry(1920,1080,800,600)
    assert g.fit_scale==pytest.approx(800/1920)
    assert g.display_extent(ViewState())==(800,450)
    assert g.uv_to_screen(.5,.5,ViewState())==(400,300)


def test_zoom_anchor_preserved_inside_bounds():
    g=Geometry(2160,3840,1080,1920)
    s=ViewState(mode='fit',magnification=2)
    pos=(700,1200)
    uv=g.screen_to_uv(*pos,s)
    after=g.anchored_zoom(s,*pos,1.4)
    assert g.screen_to_uv(*pos,after)==pytest.approx(uv,abs=1e-9)
    assert 0<=after.cx<=1 and 0<=after.cy<=1


def test_native_dpi_scale():
    g=Geometry(1920,1080,1000,700,dpr=1.25)
    s=ViewState(mode='native')
    assert g.scale(s)==pytest.approx(0.8)
    out=g.to_mpv(s)
    assert out['video-unscaled']=='no'
    assert float(out['video-zoom'])==pytest.approx(__import__('math').log2(.8/g.fit_scale))


def test_rotation_and_sar():
    g=Geometry(1920,1080,600,900,sample_aspect=4/3,rotation=90)
    assert g.display_size==(1080,2560)
    assert parse_sar('4:3')==pytest.approx(4/3)
    assert parse_sar('Unspecified')==1


def test_normalized_pan_across_mixed_resolutions():
    views=ViewCoordinator(2)
    a=Geometry(1920,1080,800,500)
    b=Geometry(2160,3840,600,900)
    views.pan(0,a,-50,0,[0,1])
    assert views.states[0].cx==pytest.approx(views.states[1].cx)
    views.zoom(0,a,600,260,1.4,{1:b})
    assert views.states[0].magnification==views.states[1].magnification
    assert views.states[0].cx==views.states[1].cx


def test_stable_roundtrip():
    g=Geometry(3840,2160,960,540,dpr=1.5)
    s=ViewState('fit',2.2,.4,.6)
    x,y=g.uv_to_screen(.31,.77,s)
    assert g.screen_to_uv(x,y,s)==pytest.approx((.31,.77))
