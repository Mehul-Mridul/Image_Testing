"""Tests Windows ABI and pending-command contract without a real Windows DLL."""
from unittest.mock import patch
from directrgb import mpv_native


class FakeDll:
    def __init__(self):
        self.options = {}
        self.commands = []
        self.destroyed = False

    def mpv_create(self):
        return 123

    def mpv_set_option_string(self, handle, key, value):
        self.options[key.decode()] = value.decode()
        return 0

    def mpv_initialize(self, handle):
        return 0

    def mpv_command_async(self, handle, request, argv):
        from ctypes import string_at
        self.commands.append((request, [string_at(argv[i]).decode() for i in range(4) if argv[i]]))
        return 0

    def mpv_set_property_string(self, handle, key, value):
        return 0

    def mpv_terminate_destroy(self, handle):
        self.destroyed = True


def test_window_handle_is_not_truncated_and_load_is_async():
    fake = FakeDll()
    hwnd = 0x1234_5678_9ABC  # wider than 32 bits
    with patch.object(mpv_native.sys, 'platform', 'win32'):
        pane = mpv_native.MpvPanePlayer(hwnd, lib=fake)
        assert fake.options['wid'] == str(hwnd)
        pane.load('C:/Media/source video.mp4')
        assert fake.commands[0][1] == ['loadfile', 'C:/Media/source video.mp4', 'replace']
        pane.seek(1.25)
        assert fake.commands[1][1][:2] == ['seek', '1.250000']
        assert fake.commands[1][0] > fake.commands[0][0]
        pane.close()
        assert fake.destroyed


def test_zero_hwnd_rejected():
    fake = FakeDll()
    with patch.object(mpv_native.sys, 'platform', 'win32'):
        try:
            mpv_native.MpvPanePlayer(0, lib=fake)
        except mpv_native.MpvError as e:
            assert 'native Win32' in str(e)
        else:
            raise AssertionError('Expected invalid HWND failure')
        assert fake.destroyed
