"""Offline/static checks: do not claim Windows installer has been executed here."""
from pathlib import Path
import re

ROOT = Path(__file__).resolve().parents[1]
SCRIPT = (ROOT / 'scripts' / 'Install-And-Build.ps1').read_text(encoding='utf-8')


def test_bootstrap_keeps_publisher_pinned_uv():
    assert '0cdc5b38fe5a8168ed6a25814f5ba43c21d313dd3187314fccb37b7cec46e021' in SCRIPT
    assert 'Download-Pinned $uvUrl $uvArchive 1000000 $uvHash' in SCRIPT
    assert 'uv checksum unavailable: refusing unsigned bootstrap.' not in SCRIPT


def test_ffmpeg_archive_fixed_version_and_publisher_hash():
    assert 'ffmpeg-9.0.2-essentials_build.7z' in SCRIPT
    assert '4705843ccaaf54257c16ad90f3e952ece33c17df964ecf7bfdbb0f49c7171077' in SCRIPT
    assert 'https://github.com/GyanD/codexffmpeg/releases/download/9.0.2/' in SCRIPT
    assert 'https://www.gyan.dev/ffmpeg/builds/packages/' in SCRIPT
    assert 'ffmpeg-release-essentials.zip' not in SCRIPT


def test_download_retries_resumes_and_handles_fallback():
    assert "Get-Command 'curl.exe'" in SCRIPT
    for arg in ('--fail', '--location', '--retry', '--continue-at', '--output', '--connect-timeout'):
        assert f"'{arg}'" in SCRIPT
    assert 'Start-BitsTransfer' in SCRIPT
    assert 'foreach ($url in $Urls)' in SCRIPT
    assert 'for ($attempt = 1; $attempt -le 3; $attempt++)' in SCRIPT
    assert 'SHA256' in SCRIPT
    assert '.part' in SCRIPT


def test_native_archives_are_verification_gated():
    assert 'Get-FileHash -Algorithm SHA256' in SCRIPT
    assert 'Assert-Sha256 $Path $Hash' in SCRIPT
    for sha in (
        '0cdc5b38fe5a8168ed6a25814f5ba43c21d313dd3187314fccb37b7cec46e021',
        '4705843ccaaf54257c16ad90f3e952ece33c17df964ecf7bfdbb0f49c7171077',
        '30d3f9fa121ce24638610a9ae52f8957743f9dea416dd37dc4ff7e43589ef843',
        '9bf582b894dfa665f852d7e9112b02290a1c303c2d95a21fcdc41ffcb03143b7',
    ):
        assert re.search(rf'(?<![0-9a-f]){sha}(?![0-9a-f])', SCRIPT, re.I)
    assert '& $extractor t $ffArchive' in SCRIPT
    assert '& $extractor t $mpvArchive' in SCRIPT


def test_ffmpeg_and_ffprobe_copied_from_verified_archive():
    assert "foreach ($name in @('ffmpeg.exe', 'ffprobe.exe'))" in SCRIPT
    assert 'Copy-Item $found.FullName (Join-Path $vendor $name)' in SCRIPT
    assert 'Test-Executable -ExecutablePath $ffmpeg' in SCRIPT
    assert 'Test-Executable -ExecutablePath $ffprobe' in SCRIPT
