from pathlib import Path
from dataclasses import replace
from time import monotonic
import subprocess
import sys
import pytest
from directrgb.load_intent import plan_load
from directrgb.load_scheduler import LoadScheduler
from directrgb.media_cache import MetadataCache,CACHE
from directrgb.process_runner import process_options,run_command
from directrgb.probe import probe_file, probe_file_with_status
from directrgb.loading_metrics import LoadingMetrics


def test_multiple_files_always_replace_specific_panes():
    old=('a.mp4','b.mp4','c.mp4','d.mp4')
    for files in [('new1.mp4','new2.mp4'), ('n1.mp4','n2.mp4','n3.mp4'),('e1','e2','e3','e4')]:
        plan=plan_load(files,existing=old,active_pane=3)
        assert plan.visible_count==len(files)
        assert plan.slots[:len(files)]==files
        assert plan.slots[len(files):]==(None,)*(4-len(files))
        assert plan.target_panes==tuple(range(len(files)))


def test_single_file_replaces_only_active_pane():
    result=plan_load(['new.mp4'],existing=['a','b','c','d'],active_pane=2)
    assert result.slots==('a','b','new.mp4','d')
    assert result.target_panes==(2,)


def test_append_remains_explicit():
    assert plan_load(['c','d'],existing=['a','b',None,None],mode='append').slots==('a','b','c','d')
    with pytest.raises(ValueError,match='Not enough empty'):
        plan_load(['c'],existing=['a','b','c','d'],mode='append')


def test_bad_load_intents_rejected():
    for paths in ([],['a']*5):
        with pytest.raises(ValueError):plan_load(paths)
    with pytest.raises(ValueError):plan_load(['x'],active_pane=4)
    with pytest.raises(ValueError):plan_load(['x'],mode='unknown')


def test_ten_fast_batches_ignore_prior_completions():
    schedule=LoadScheduler()
    ids=[]
    for n in range(10):
        batch=schedule.begin({0:f'a-{n}',1:f'b-{n}',2:f'c-{n}'})
        ids.append(batch.generation)
        assert schedule.update(ids[-1],0,'probing')
    for obsolete in ids[:-1]:
        assert not schedule.update(obsolete,0,'ready')
    last=ids[-1]
    for i in range(3):
        assert schedule.update(last,i,'ready')
    assert schedule.active.valid
    schedule.cancel()
    assert not schedule.current(last)


def test_cached_metadata_invalidates_on_file_modification(tmp_path):
    cache=MetadataCache(2)
    f=tmp_path/'x.mp4';f.write_bytes(b'hello')
    first=cache.key(f,probe_version='x')
    cache.put(first,42)
    assert cache.get(first)==42
    assert cache.hits==1
    f.write_bytes(b'hello world')
    later=cache.key(f,probe_version='x')
    assert first!=later
    assert cache.get(later) is None
    cache.put(later,44)
    cache.put(('third',),55)
    assert len(cache.data)==2
    assert cache.get(first) is None


def test_ffprobe_uses_single_subprocess_and_cache(monkeypatch,tmp_path):
    # Runs real FFmpeg fixture: second call has no process start at all.
    original=Path(__file__).resolve().parents[1]/'assets/test_yuv420_bt709_limited.mkv'
    copy=tmp_path/'isolated.mkv';copy.write_bytes(original.read_bytes())
    import directrgb.probe as p
    calls=[]
    runner=p.run_command
    def count(argv,**kwargs):
        calls.append(argv)
        return runner(argv,**kwargs)
    monkeypatch.setattr(p,'run_command',count)
    a,hit1=probe_file_with_status(str(copy))
    b,hit2=probe_file_with_status(str(copy))
    assert not hit1 and hit2
    assert a is b
    assert len(calls)==1
    assert '-show_frames' in calls[0] and '-show_streams' in calls[0]
    assert a.eligibility[0]


def test_process_runner_never_uses_shell_and_hides_windows():
    opts=process_options('win32')
    assert opts['creationflags'] & 0x08000000
    assert process_options('linux')=={}
    with pytest.raises(ValueError):run_command('cmd.exe /c echo hi')
    with pytest.raises(ValueError):run_command([])
    c=run_command([sys.executable,'-c','print(12)'],timeout=5)
    assert c.returncode==0 and c.stdout.strip()==b'12'


def test_loading_metrics_never_claim_display_measured():
    m=LoadingMetrics(started=0.)
    m.mark('probe_finished',at=.135)
    m.reused_renderer=True
    r=m.snapshot()
    assert r['milliseconds']['probe_finished']==135.
    assert 'UNVERIFIED' in r['actual_visible_frame']
