from pathlib import Path
from directrgb.paths import bundled_tool, missing_runtime_files
from directrgb.probe import probe_file
from directrgb.policy import Overrides
import pytest


PROJECT = Path(__file__).resolve().parents[1]


def test_ffprobe_in_system_or_vendor():
    assert Path(bundled_tool('ffprobe')).is_file()


def test_yuv709_video_metadata():
    p = PROJECT / 'assets/test_yuv420_bt709_limited.mkv'
    d = probe_file(str(p))
    assert d.codec != 'Unspecified'
    assert d.matrix == 'bt709'
    assert d.range == 'tv'
    assert d.width > 0 and d.height > 0


def test_diagnostic_format_not_automatic_color_grade():
    assert Overrides('limited', 'bt709').combined_mpv_override() == (
        'format=colorlevels=limited:colormatrix=bt.709:convert=no')
    assert Overrides().combined_mpv_override() == ''


def test_input_validation():
    with pytest.raises(ValueError):
        Overrides('bad_range', 'auto').normalized()
