from pathlib import Path
import numpy as np
from PIL import Image
import pytest
from directrgb.validation import make_chart, compare_png
from directrgb.sync import Clock
from directrgb.policy import direct_eligibility, Overrides
from directrgb.probe import parse_probe


def test_chart_exact_swatches(tmp_path):
    path = tmp_path / 'test.png'
    info = make_chart(path)
    im = Image.open(path)
    assert im.mode == 'RGB' and 'icc_profile' not in im.info
    for name, data in info['swatches'].items():
        assert list(im.getpixel(tuple(data['sample_xy']))) == data['rgb'], name


def test_identical_image_metrics(tmp_path):
    p = tmp_path/'ref.png'; make_chart(p, 480, 300)
    result = compare_png(p, p)
    assert result['max_absolute_rgb_difference'] == 0
    assert result['mean_absolute_rgb_difference'] == 0
    assert result['exact_pixel_match_pct'] == 100


def test_pixel_rgb_deltas(tmp_path):
    a = np.array([[[10,20,30],[255,0,3]]], np.uint8)
    b = np.array([[[11,20,30],[253,0,4]]], np.uint8)
    Image.fromarray(a).save(tmp_path/'a.png')
    Image.fromarray(b).save(tmp_path/'b.png')
    res = compare_png(tmp_path/'a.png',tmp_path/'b.png',tmp_path/'diff.png')
    assert res['max_absolute_rgb_difference'] == 2
    assert res['exact_pixel_match_pct'] == 0
    assert res['pixels_with_all_channels_diff_le_1_pct'] == 50
    assert res['per_channel']['R']['histogram'] == {'1': 1, '2': 1}
    assert (tmp_path/'diff.png').is_file()


def test_dimension_mismatch_rejected(tmp_path):
    for name, size in [('a', (2,2)),('b',(3,2))]:
        Image.new('RGB', size).save(tmp_path/f'{name}.png')
    with pytest.raises(ValueError, match='dimensions mismatch'):
        compare_png(tmp_path/'a.png',tmp_path/'b.png')


def test_hdr_rejects_direct_playback():
    assert direct_eligibility('smpte2084','bt2020')[0] is False
    assert direct_eligibility('arib-std-b67','bt709')[0] is False
    assert direct_eligibility('bt709','bt709')[0] is True
    assert direct_eligibility('', '')[0] is True


def test_sync_offset_and_frame_policy():
    assert Clock.local_time(2.0, -1.0, 0.5) == 1.5
    assert Clock.error_ms(1.2,1.0) == pytest.approx(200)
    assert Clock.nearest_frame_time(1/30,[0,1/60,1/30,3/60]) == 1/30
    assert Clock.tolerance_seconds(30) >= 0.1


def test_probe_unknown_not_invented():
    data = {'streams':[{'codec_type':'video','codec_name':'h264', 'width':100,'height':100,
                        'pix_fmt':'yuv420p','color_range':'tv'}], 'format': {'duration':'4'}}
    meta = parse_probe('/tmp/example.mp4',data)
    assert meta.matrix == 'Unspecified'
    assert meta.range == 'tv'
    assert meta.bit_depth == '8'
    assert meta.duration == 4


def test_overrides_combine():
    o = Overrides('full','bt709')
    assert 'colorlevels=full' in o.combined_mpv_override()
    assert 'colormatrix=bt.709' in o.combined_mpv_override()


def test_known_yuv_triplets():
    from directrgb.color_math import ycbcr_to_rgb_444, quantize_rgb_8bit
    limited = quantize_rgb_8bit(ycbcr_to_rgb_444([[16,128,128],[235,128,128]],matrix='bt709',range='limited'))
    assert limited.tolist() == [[0,0,0],[255,255,255]]
    full = quantize_rgb_8bit(ycbcr_to_rgb_444([[0,128,128],[255,128,128]],matrix='bt2020nc',range='full'))
    assert full.tolist() == [[0,0,0],[255,255,255]]
