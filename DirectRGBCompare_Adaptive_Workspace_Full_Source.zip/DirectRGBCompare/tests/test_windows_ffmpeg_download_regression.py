"""Network repair static tests only (not a Windows PowerShell execution)."""
from pathlib import Path

SRC = (Path(__file__).resolve().parents[1] / 'scripts' / 'Install-And-Build.ps1').read_text(encoding='utf8')


def test_failed_transfers_are_not_dropped_after_every_attempt():
    download_fn = SRC.split('function Download-File {', 1)[1].split('function Assert-Sha256', 1)[0]
    assert 'Remove-Item $temp' not in download_fn
    assert 'Remove-Item -LiteralPath $part -Force' in download_fn  # BITS requires empty destination
    assert "'--continue-at' '-'" in download_fn


def test_download_fallback_does_not_bypass_digest_check():
    assert 'Download-Pinned -Urls @(' in SRC
    assert 'Assert-Sha256 $Path $Hash; return' in SRC
    assert 'if ($attempt -eq 2) { throw }' in SRC


def test_pin_sources_are_strict_https():
    assert "'https://github.com/GyanD/codexffmpeg/releases/download/9.0.2/" in SRC
    assert "'https://www.gyan.dev/ffmpeg/builds/packages/" in SRC
    assert 'http://' not in '\n'.join(l for l in SRC.splitlines() if not l.strip().startswith('#'))
