"""Static safeguards for Windows native binary invocations.

A Linux test cannot prove successful execution in Windows PowerShell 5.1.
"""
import re
from pathlib import Path

INSTALLER = Path(__file__).resolve().parents[1] / 'scripts' / 'Install-And-Build.ps1'


def test_no_reserved_args_parameter_or_implicit_splatting():
    script = INSTALLER.read_text(encoding='utf8')
    func = script.split('function Test-Executable {',1)[1].split('\n# Pin uv ',1)[0]
    assert re.search(r'\[string\[\]\]\$CommandArguments', func)
    assert not re.search(r'\[string\[\]\]\$args\b', func, flags=re.I)
    assert '& $ExecutablePath @CommandArguments' in func


def test_calls_pass_named_arguments():
    script = INSTALLER.read_text(encoding='utf8')
    for binary, flag in [('uvExe', '--version'),('ffmpeg','-version'),('ffprobe','-version')]:
        assert f"Test-Executable -ExecutablePath ${binary} -CommandArguments @('{flag}')" in script


def test_native_program_not_truncated_by_select_first():
    script = INSTALLER.read_text(encoding='utf8')
    func = script.split('function Test-Executable {',1)[1].split('\n# Pin uv ',1)[0]
    assert 'Select-Object -First 1' not in ''.join(line for line in func.splitlines() if not line.strip().startswith('#'))
    assert '$exitCode = $LASTEXITCODE' in func
    assert 'if ($exitCode -ne 0)' in func
