@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
    echo ERROR: Run RUN_FIRST.bat before this Windows GPU/GUI test.
    pause
    exit /b 1
)
".venv\Scripts\python.exe" tools\adaptive_gui_smoke.py
if errorlevel 1 (
    echo.
    echo Native GUI/load test FAILED or could not run. See diagnostics above.
    pause
    exit /b 1
)
echo Native GUI/loading smoke test passed. Color output STILL requires numeric testing.
pause
