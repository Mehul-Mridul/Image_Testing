# Invoke on Windows with: py -m PyInstaller --noconfirm DirectRGBCompare.spec
from pathlib import Path

root = Path(SPECPATH)
vendor = root / 'vendor' / 'bin'
required = ['ffmpeg.exe', 'ffprobe.exe']
missing = [x for x in required if not (vendor/x).is_file()]
if not list(vendor.glob('*mpv*.dll')):
    missing.append('libmpv-2.dll (or mpv-2.dll)')
if missing:
    raise RuntimeError('Missing redistribution-ready binaries in vendor/bin: ' + ', '.join(missing))

binaries = [(str(p), 'bin') for p in vendor.iterdir() if p.is_file()]
datas = [(str(root / 'docs'), 'docs'), (str(root / 'assets'), 'assets')]
if (root/'vendor'/'licenses').exists():
    datas.append((str(root/'vendor'/'licenses'), 'licenses'))
a = Analysis(
    ['run.py'], pathex=[str(root)], binaries=binaries, datas=datas,
    hiddenimports=['PySide6.QtCore','PySide6.QtGui','PySide6.QtWidgets'],
    hookspath=[], hooksconfig={}, runtime_hooks=[], excludes=[], noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(pyz, a.scripts, [], exclude_binaries=True,
          name='DirectRGBCompare', debug=False, bootloader_ignore_signals=False,
          strip=False, upx=False, console=False, disable_windowed_traceback=False)
coll = COLLECT(exe, a.binaries, a.datas, strip=False, upx=False,
               name='DirectRGBCompare')
