# One-click Windows x64 installer and portable EXE builder.
# Run from RUN_FIRST.bat; does not require Python, FFmpeg, mpv, 7-Zip or admin rights.
# Downloads third-party software from disclosed upstream distribution servers.
param([switch]$Launch, [switch]$SkipBuild)
$ErrorActionPreference = 'Stop'
$ProgressPreference = 'SilentlyContinue'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
Set-Location $root
$cache = Join-Path $root '.downloads'
$vendor = Join-Path $root 'vendor\bin'
$tools = Join-Path $root '.tools'
foreach ($dir in @($cache, $vendor, $tools)) { New-Item -ItemType Directory -Force -Path $dir | Out-Null }

# Downloads: curl.exe is used explicitly (PowerShell 5.1 aliases curl to IWR).
# Keep .part files for resume, retry transient network failures, and use trusted mirrors.
# A completed download must still pass its publisher SHA256 before extraction.
function Download-File {
    param(
        [Parameter(Mandatory=$true)][string[]]$Urls,
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][long]$Minimum,
        [switch]$AlwaysDownload
    )
    if (!$AlwaysDownload -and (Test-Path -LiteralPath $Path -PathType Leaf) -and
        ((Get-Item -LiteralPath $Path).Length -ge $Minimum)) {
        Write-Host "Using downloaded: $(Split-Path $Path -Leaf)"
        return
    }
    $part = "$Path.part"
    $curl = Get-Command 'curl.exe' -ErrorAction SilentlyContinue
    foreach ($url in $Urls) {
        # Retry transient disconnects for a given source; then switch mirrors.
        for ($attempt = 1; $attempt -le 3; $attempt++) {
            Write-Host "Downloading $(Split-Path $Path -Leaf) ($attempt/3) from $url"
            $ok = $false
            if ($curl) {
                # -C - resumes at the current size. -f rejects HTTP error pages.
                # --retry retries transient network failures on Windows curl versions.
                & $curl.Source '--fail' '--location' '--retry' '2' '--retry-delay' '2' '--connect-timeout' '30' '--max-time' '1800' '--continue-at' '-' '--output' $part $url
                $ok = ($LASTEXITCODE -eq 0)
            } else {
                # Rare systems without curl.exe: BITS is more reliable than IWR for large files.
                try {
                    if (Test-Path $part) { Remove-Item -LiteralPath $part -Force }
                    Start-BitsTransfer -Source $url -Destination $part -ErrorAction Stop
                    $ok = $true
                } catch { Write-Warning "BITS download failed: $($_.Exception.Message)" }
            }
            if ($ok -and (Test-Path -LiteralPath $part -PathType Leaf) -and
                ((Get-Item -LiteralPath $part).Length -ge $Minimum)) {
                Move-Item -LiteralPath $part -Destination $Path -Force
                return
            }
            $partLength = 0L
            if (Test-Path $part) { $partLength = (Get-Item $part).Length }
            Write-Warning "Download interrupted or incomplete ($partLength bytes). Retrying..."
            Start-Sleep -Seconds ([Math]::Min(6, 2 * $attempt))
        }
        # The mirrors must serve the SAME pinned archive. We can attempt to resume
        # the same content from either; the final SHA256 must match. If it does not,
        # Download-Pinned discards the file and forces a clean retry.
        Write-Warning "Could not download fully from $url. Trying another source if available."
    }
    throw "All download sources failed for $(Split-Path $Path -Leaf). Partial data retained at $part. Try again later or use the documented manual-install option."
}
function Assert-Sha256([string]$path, [string]$expected) {
    if (!(Test-Path $path)) { throw "Cannot checksum missing file: $path" }
    if ($expected -notmatch '^[0-9a-fA-F]{64}$') { throw "Invalid SHA256 expected value for $path" }
    $actual = (Get-FileHash -Algorithm SHA256 $path).Hash.ToLowerInvariant()
    if ($actual -ne $expected.ToLowerInvariant()) {
        throw "SHA256 mismatch for $path. Expected $expected; actual $actual"
    }
    Write-Host "SHA256 OK: $(Split-Path $path -Leaf)"
}
function Download-Pinned {
    param(
        [Parameter(Mandatory=$true)][string[]]$Urls,
        [Parameter(Mandatory=$true)][string]$Path,
        [Parameter(Mandatory=$true)][long]$Minimum,
        [Parameter(Mandatory=$true)][string]$Hash
    )
    for ($attempt = 1; $attempt -le 2; $attempt++) {
        Download-File -Urls $Urls -Path $Path -Minimum $Minimum -AlwaysDownload:($attempt -gt 1)
        try { Assert-Sha256 $Path $Hash; return }
        catch {
            if (Test-Path $Path) { Remove-Item -LiteralPath $Path -Force }
            if (Test-Path "$Path.part") { Remove-Item -LiteralPath "$Path.part" -Force }
            if ($attempt -eq 2) { throw }
            Write-Warning 'Archive failed SHA256. Discarded cached copy; retrying clean download.'
        }
    }
}
function Test-Executable {
    # PowerShell reserves $args for undeclared arguments; using it as a named
    # parameter dropped --version/-version and ran uv with NO arguments.
    # Also do not pipe native output through Select-Object -First 1: stopping
    # the upstream native process can turn a success into a nonzero exit.
    param(
        [Parameter(Mandatory=$true)][string]$ExecutablePath,
        [Parameter(Mandatory=$true)][string[]]$CommandArguments
    )
    if (!(Test-Path -LiteralPath $ExecutablePath -PathType Leaf)) {
        throw "Missing executable: $ExecutablePath"
    }
    Write-Host "Checking $(Split-Path $ExecutablePath -Leaf) $($CommandArguments -join ' ')"
    & $ExecutablePath @CommandArguments
    $exitCode = $LASTEXITCODE
    if ($exitCode -ne 0) {
        throw "Executable failed with exit $exitCode : $ExecutablePath (arguments: $($CommandArguments -join ' '))"
    }
}

# Pin uv 0.13.7 to the SHA256 published by Astral for this exact x64 ZIP:
# https://releases.astral.sh/github/uv/releases/download/0.13.7/uv-x86_64-pc-windows-msvc.zip.sha256
# Pinned digest avoids the PowerShell .Content parsing failure reported by users.
$uvArchive = Join-Path $cache 'uv-x86_64-pc-windows-msvc.zip'
$uvExe = Join-Path $tools 'uv.exe'
$uvUrl = 'https://releases.astral.sh/github/uv/releases/download/0.13.7/uv-x86_64-pc-windows-msvc.zip'
$uvHash = '0cdc5b38fe5a8168ed6a25814f5ba43c21d313dd3187314fccb37b7cec46e021'
if (!(Test-Path $uvExe)) {
    Download-Pinned $uvUrl $uvArchive 1000000 $uvHash
    $tempUv = Join-Path $cache 'uv-unpacked'
    New-Item -ItemType Directory -Force -Path $tempUv | Out-Null
    Expand-Archive -Path $uvArchive -DestinationPath $tempUv -Force
    $found = Get-ChildItem -Path $tempUv -Recurse -File -Filter 'uv.exe' | Select-Object -First 1
    if (!$found) { throw 'uv.exe not found inside verified release archive.' }
    Copy-Item $found.FullName $uvExe -Force
}
Test-Executable -ExecutablePath $uvExe -CommandArguments @('--version')

# 7-Zip standalone extractor: use a VERSIONED immutable release, not /a/7zr.exe.
# /a/7zr.exe is a mutable endpoint and served 26.04 while the old script
# expected the published 26.05 hash (Windows installation failure, 2026-11-07).
# Verify existing files, too: never run an unverified local executable.
# Publisher hashes:
# 26.05 https://github.com/ip7z/7zip/releases/expanded_assets/26.05
# 26.04 https://sourceforge.net/projects/sevenzip/files/7-Zip/26.04/7zr.exe/download
$extractor = Join-Path $tools '7zr.exe'
$sevenZipHash2605 = '9bf582b894dfa665f852d7e9112b02290a1c303c2d95a21fcdc41ffcb03143b7'
$sevenZipHash2604 = '256feca8e274e5da655e2a284fabafd9f554365eb164862089dacd4e8276d282'
$extractorVerified = $false
if (Test-Path -LiteralPath $extractor -PathType Leaf) {
    $actualExtractorHash = (Get-FileHash -Algorithm SHA256 -LiteralPath $extractor).Hash.ToLowerInvariant()
    if ($actualExtractorHash -eq $sevenZipHash2605) {
        Write-Host 'SHA256 OK: previously installed 7zr.exe (26.05)'
        $extractorVerified = $true
    } elseif ($actualExtractorHash -eq $sevenZipHash2604) {
        # This remains a pinned, publisher-confirmed binary. It can decode our 7z archives.
        Write-Host 'SHA256 OK: previously installed 7zr.exe (26.04); reusing verified binary.'
        $extractorVerified = $true
    } else {
        # Keep the suspicious file for inspection instead of executing it.
        $quarantine = "$extractor.unverified-$(Get-Date -Format yyyyMMdd-HHmmss).bak"
        Move-Item -LiteralPath $extractor -Destination $quarantine -Force
        Write-Warning "Unrecognized 7zr.exe SHA256 ($actualExtractorHash). Moved to $quarantine"
    }
}
if (!$extractorVerified) {
    Download-Pinned -Urls @(
        'https://github.com/ip7z/7zip/releases/download/26.05/7zr.exe',
        'https://sourceforge.net/projects/sevenzip/files/7-Zip/26.05/7zr.exe/download'
    ) -Path $extractor -Minimum 200000 -Hash $sevenZipHash2605
    $extractorVerified = $true
}
if (!$extractorVerified) { throw 'A verified 7-Zip extractor is required.' }
# FFmpeg release essentials v9.0.2, ~34 MB .7z instead of the former ~109 MB ZIP.
# Both sources distribute the SAME immutable build; a pinned publisher checksum
# is enforced. A failed Gyan download can fall back to GitHub or vice versa.
# Publisher's SHA256: https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-9.0.2-essentials_build.7z.sha256
$ffmpeg = Join-Path $vendor 'ffmpeg.exe'
$ffprobe = Join-Path $vendor 'ffprobe.exe'
if (!(Test-Path $ffmpeg) -or !(Test-Path $ffprobe)) {
    $ffArchive = Join-Path $cache 'ffmpeg-9.0.2-essentials_build.7z'
    $ffHash = '4705843ccaaf54257c16ad90f3e952ece33c17df964ecf7bfdbb0f49c7171077'
    Download-Pinned -Urls @(
        'https://github.com/GyanD/codexffmpeg/releases/download/9.0.2/ffmpeg-9.0.2-essentials_build.7z',
        'https://www.gyan.dev/ffmpeg/builds/packages/ffmpeg-9.0.2-essentials_build.7z'
    ) -Path $ffArchive -Minimum 20000000 -Hash $ffHash
    & $extractor t $ffArchive | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'FFmpeg archive could not pass 7z integrity check.' }
    $ffRoot = Join-Path $cache 'ffmpeg-unpacked'
    New-Item -ItemType Directory -Force -Path $ffRoot | Out-Null
    & $extractor x $ffArchive "-o$ffRoot" '-y' | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'FFmpeg extraction failed.' }
    foreach ($name in @('ffmpeg.exe', 'ffprobe.exe')) {
        $found = Get-ChildItem $ffRoot -Recurse -File -Filter $name | Select-Object -First 1
        if (!$found) { throw "Cannot locate $name inside verified FFmpeg archive." }
        Copy-Item $found.FullName (Join-Path $vendor $name) -Force
    }
}
Test-Executable -ExecutablePath $ffmpeg -CommandArguments @('-version')
Test-Executable -ExecutablePath $ffprobe -CommandArguments @('-version')

# libmpv builds are unofficial; shinchiro is listed on mpv.io/installation/.
# Pin to a dated build and log SHA256. mpv's redistribution/license terms depend
# on how the binary was built; consult vendor/README.md before redistributing.
$mpv = Join-Path $vendor 'libmpv-2.dll'
$mpvAlternative = Join-Path $vendor 'mpv-2.dll'
if (!(Test-Path $mpv) -and !(Test-Path $mpvAlternative)) {
    $mpvArchive = Join-Path $cache 'mpv-dev-x86_64-20261101-git-48fca90e8c.7z'
    $mpvUrl = 'https://sourceforge.net/projects/mpv-player-windows/files/libmpv/mpv-dev-x86_64-20261101-git-48fca90e8c.7z/download'
    Download-Pinned $mpvUrl $mpvArchive 10000000 '30d3f9fa121ce24638610a9ae52f8957743f9dea416dd37dc4ff7e43589ef843'
    & $extractor t $mpvArchive | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'Downloaded mpv 7z archive failed integrity test.' }
    $mpvRoot = Join-Path $cache 'mpv-unpacked'
    New-Item -ItemType Directory -Force -Path $mpvRoot | Out-Null
    & $extractor x $mpvArchive "-o$mpvRoot" '-y' | Out-Null
    if ($LASTEXITCODE -ne 0) { throw 'libmpv extraction failed.' }
    $dlls = @(Get-ChildItem $mpvRoot -Recurse -File -Filter '*.dll')
    $main = $dlls | Where-Object { $_.Name -in @('libmpv-2.dll', 'mpv-2.dll', 'libmpv.dll') } | Select-Object -First 1
    if (!$main) { throw 'No libmpv-2.dll or mpv-2.dll found inside the mpv-dev archive.' }
    # shinchiro's builds normally carry a single statically linked DLL. If the
    # archive includes companion DLLs, they must sit beside the main library.
    foreach ($dll in $dlls) { Copy-Item $dll.FullName (Join-Path $vendor $dll.Name) -Force }
    Write-Host "libmpv SHA256 archive: $((Get-FileHash -Algorithm SHA256 $mpvArchive).Hash)"
}
if (!(Test-Path $mpv) -and !(Test-Path $mpvAlternative)) { throw 'libmpv was not installed.' }

# Install isolated Python without modifying system Python or installing packages
# globally. User gets a portable PyInstaller folder, not a Python requirement.
$python = Join-Path $root '.venv\Scripts\python.exe'
if (!(Test-Path $python)) {
    & $uvExe venv --python 3.12 '.venv'
    if ($LASTEXITCODE -ne 0) { throw 'Cannot create self-managed Python environment.' }
}
& $uvExe pip install --python $python -r 'requirements-build.txt'
if ($LASTEXITCODE -ne 0) { throw 'Python package installation failed.' }

Write-Host 'Running source and media regression tests...'
& $python -m pytest -q tests
if ($LASTEXITCODE -ne 0) { throw 'Regression tests failed. Refusing to build broken binary.' }
& $python tools\health_check.py
if ($LASTEXITCODE -ne 0) { throw 'Runtime health check failed. Refusing to build.' }
if ($env:CI -ne 'true') {
    Write-Host 'Checking embedded Windows/D3D11 playback on this PC...'
    & $python tools\windows_smoke.py
    if ($LASTEXITCODE -ne 0) {
        Write-Warning 'D3D11 smoke test failed. Build may finish, but playback is NOT VERIFIED on this PC. Review GPU/driver/runtime diagnostics.'
    }
}

if (!$SkipBuild) {
    Write-Host 'Building portable, self-contained Windows folder...'
    & $python -m PyInstaller --noconfirm --clean 'DirectRGBCompare.spec'
    if ($LASTEXITCODE -ne 0) { throw 'PyInstaller build failed.' }
    $exe = Join-Path $root 'dist\DirectRGBCompare\DirectRGBCompare.exe'
    if (!(Test-Path $exe)) { throw 'Build completed without generating the application EXE.' }
    Write-Host "Built successfully: $exe"
    Write-Host 'IMPORTANT: GUI, color, FastStone and 4K tests must still be validated on this PC.'
    if ($Launch) { Start-Process -FilePath $exe -WorkingDirectory (Split-Path $exe) }
} elseif ($Launch) {
    & $python run.py
}
