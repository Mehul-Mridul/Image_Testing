DIRECTRGB COMPARE - INSTALLER SHA256 HOTFIX (2026-11-07)

ERROR FIXED: "uv checksum unavailable: refusing unsigned bootstrap."

FULL PACKAGE:
  Extract this ZIP as a NEW folder, then run RUN_FIRST.bat.
  Do not start an old EXE from a prior folder.

SMALL PATCH PACKAGE:
  Extract directly into the DirectRGBCompare folder from the previous build.
  Allow it to overwrite scripts\Install-And-Build.ps1 and docs\WINDOWS_SETUP.md.
  Run RUN_FIRST.bat again. Existing downloaded ZIPs may be reused once
  their checksums have been validated.

NOTE: Windows native setup and GPU/GUI playback were not tested in the
Linux authoring environment. This is a source/build package, not a
precompiled Windows EXE.
