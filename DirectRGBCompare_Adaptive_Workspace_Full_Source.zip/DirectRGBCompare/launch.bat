@echo off
setlocal
cd /d "%~dp0"
if exist "dist\DirectRGBCompare\DirectRGBCompare.exe" (
   start "" "dist\DirectRGBCompare\DirectRGBCompare.exe"
   exit /b 0
)
if exist ".venv\Scripts\python.exe" (
   ".venv\Scripts\python.exe" run.py
   if errorlevel 1 pause
   exit /b %errorlevel%
)
call "%~dp0RUN_FIRST.bat"
