@echo off
setlocal
cd /d "%~dp0"
echo.
echo ===========================================================
echo   DirectRGB Compare - Setup, Build and Launch (Windows x64)
echo ===========================================================
echo This downloads trusted upstream runtime packages and creates a
 echo portable EXE in dist\DirectRGBCompare. Internet is required first time.
echo.
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0scripts\Install-And-Build.ps1" -Launch
if errorlevel 1 (
  echo.
  echo Setup/build FAILED. Read the actual error printed above.
  echo See docs\WINDOWS_SETUP.md for troubleshooting.
  pause
  exit /b 1
)
exit /b 0
