# DirectRGB Compare — Adaptive Workspace + Fast Loading Upgrade

## What was actually changed (2026-11-11)

This is a **source implementation** applied to the previous vNext codebase, not a
GUI mockup. It has **not** been verified as a Windows EXE or compared numerically
to FastStone CMS OFF on a real monitor. Do not use it for final color sign-off.

### Video-first workspace

`adaptive_layout.py` is a pure solver that evaluates candidate 1–4 pane arrangements.
It accounts for displayed aspect ratio including rotation and SAR, viewport size,
minimal usable rectangle, image-fit area and fairness so portrait and landscape
sources choose different arrangements. A 90 ms resize debounce and score hysteresis
reduce layout thrash. `adaptive_workspace.py` gives the four native child panes a
single stable QWidget parent and sets their geometries without reparenting native
player HWNDs during rearrangement. Draggable gaps adjust split ratios; F9 or the
pane header focus control fills the workspace with one video; Ctrl+Shift+0 resets
auto selection. Manually resized split preferences are stored in user settings.

The file browser, diagnostics and advanced toolbar are **hidden by default** so
video panes dominate the window. Ctrl+B toggles browser, Ctrl+D diagnostics,
Ctrl+Alt+B advanced color/view controls, and Ctrl+Shift+B toggles individual pane
tools (frame navigation, manual offsets, and move-pane controls). Current color
mode remains available in advanced controls/diagnostics. No RGB shader or
transformation was introduced by the layout solver.

### Loading and replacement

`load_intent.py` maps 2–4 selected videos to panes 1–N deterministically,
**replacing** any existing comparison without a confirmation dialog. A single
video replaces the selected pane only. Ctrl+L and the browser's Enter key load
the selected files; Ctrl+O opens the multi-file dialog, Ctrl+Shift+O opens a
folder. `Ctrl+Shift+L` is an explicit optional **Add to Empty Panes** action.
Group Next/Previous uses the same loading path, keeping missing variant slots
empty instead of shifting files into different panes.

`load_scheduler.py` tracks batch identity and readiness. Existing clip frames
can remain temporarily visible while a replacement is probed, but are clearly
marked **not part of the new comparison**. Synchronization and Play/Pause are
blocked while the requested group is incomplete. Stale probe responses are
rejected by existing per-pane tokens. Superseded running FFprobe processes now
receive cancellation events and are killed, not merely ignored. Probe concurrency
is capped at three workers. Failure statuses are non-modal and inspectable through
Diagnostics. No source video is modified.

### No CMD flashes and faster probing

`process_runner.py` uses argument-vector subprocess calls with `shell=False`,
`CREATE_NO_WINDOW` on Windows, captured outputs and timeouts. The path is invoked
by `probe.py` for video loading; Python CLI-only export utilities remain separate.
The PyInstaller `.spec` already requests `console=False` and is unchanged.

`probe.py` now performs one bounded FFprobe request collecting container,
stream **and first frame** metadata, retaining HDR / wide-gamut side-data checks.
If a first frame cannot be inspected, loading fails explicitly; a skipped
frame check is not treated as proof of SDR safety. A process-local LRU cache
(128 entries) is keyed on canonical path, size, mtime_ns, schema and ffprobe
binary identity. Cached entries include validated first-frame tags, not merely
container headers. The cache does not persist across app restarts.

**Real local fixture measurements:** The previous two-invocation version took
141.1 ms, 159.8 ms and 142.6 ms (three runs on Linux). The revised single-call
uncached probe took 70.3 ms in the recorded final fixture run, and the cached
calls took 0.171 / 0.077 / 0.066 ms. These are FFV1 short local-file measurements;
**they are not 4K Windows or first-visible-frame benchmarks**, and the Windows
GPU/decoder and disk may behave differently. Use `python tools/benchmark_probe.py`
to measure on your own machine and `CHECK_ADAPTIVE_GUI.bat` for a real libmpv
loading smoke test.

### Safe renderer reuse

In Direct RGB mode, successfully probed media are sent to the existing libmpv
instance using its asynchronous `loadfile replace` command, preserving the HWND
and renderer instance when possible. Active diagnostic overrides are cleared
before such reuse, and view and pause/speed states are explicitly reapplied.
For diagnostic mode or failed reuse, the old player is closed and the existing
strict-policy constructor is used; no silent rendering fallback is introduced.
This workflow still requires Windows qualification, especially around failed
asynchronous decoder opens and first-frame visibility.

### Key controls

| Key | Action |
|---|---|
| Ctrl+Shift+O | Open folder and show browser |
| Ctrl+O | Open videos in Windows dialog |
| Ctrl+L or Enter in browser | Replace current comparison with selection |
| Ctrl+Shift+L | Add selected files to empty panes (explicit) |
| Ctrl+PgUp / Ctrl+PgDown | Previous / next comparison set |
| Ctrl+B | Toggle browser |
| Ctrl+D | Toggle diagnostics |
| Ctrl+Alt+B | Toggle advanced toolbar |
| Ctrl+Shift+B | Toggle pane tools |
| F9 | Focus selected pane / restore comparison |
| Ctrl+Shift+0 | Reset optimal layout and manual splits |
| F1 | Edit shortcut assignments |

### Frozen RGB-critical files

These four modules are byte-identical to the previous source archive:

| Module | SHA-256 |
|---|---|
| `policy.py` | `aa373c95266e5c45daadd11be620d60be9acda5931ef2eda71c4706825d89c5e` |
| `mpv_native.py` | `4d2cbe47de440178d38550798fc07ab2a02f000774fdff8c7dee24e8649c8424` |
| `validation.py` | `b39cc37f1ea8e0a5a9067ac6a1551365a4b56cd923ea71f367a7c7d3e5ffd5da` |
| `color_math.py` | `ed0904edc1c1989a879e88a450790cf020e71a4d39ddd5c853699166bbc18a3c` |

Source identity alone does not prove GPU output. The libmpv instance lifecycle
has changed, so comparative Windows captures remain mandatory for that code path.

## Windows release acceptance (unverified)

1. Run the old vNext EXE alongside the new EXE on Windows with the same test
   media; record initial video display area and test 1/2/3/4 panes in portrait,
   landscape and mixed cases. Check 100–200% Windows DPI, no flicker, no HWND
   destruction or change of the actual rendering policy during resizing.
2. Check Ctrl+L and Enter replace three/four occupied panes with no confirmation.
   Check single-file replacement, >4 selection, missing variants, and Ctrl+PgDn
   rapid 10-set navigation; verify stale media is explicitly labelled, not treated
   as part of the current group.
3. Run `CHECK_ADAPTIVE_GUI.bat` on Windows: a Qt+libmpv smoke test loads 2/3/4/2
   panes and writes `docs/adaptive_windows_smoke_results.json`. It measures
   **backend-reported** readiness, not actual measured screen pixels.
4. Run actual packaged EXE, including console-free launching, corrupted media,
   valid/invalid metadata, and rapid load cancellation; observe that no CMD
   windows appear. Source-level flags are not a substitute for a Windows test.
5. Compare the same SDR fixture under original/new Direct RGB modes, native
   scaling, fullscreen, multiple pane arrangements, and known color-management
   conditions. Capture actual renderer output where supported and compare
   numerically against independently decoded reference and FastStone CMS OFF.
6. Stress test multiple **2160 × 3840** files and record first-visible-frame
   latency, peak RAM/VRAM, dropped frames, UI responsiveness and relative PTS.

**Known risks:** actual D3D11 composition, display ICC/DWM, 4K GPU memory,
Windows native-child input routing, synchronized frame accuracy, asynchronous
renderer-open failure recovery, and library download/build compatibility are
**NOT VERIFIED**. No benchmark or success claim is invented for them.
