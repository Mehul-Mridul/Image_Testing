# Renderer architecture and limitations

## Stack

- Windows PySide6 native Qt application controls four `HWND` child surfaces (never resizes top-level window to source video dimensions).
- **libmpv / gpu-next / libplacebo / D3D11** decodes and renders each video without passing 4K RGB frames through Python, NumPy, QImage or QLabel. The active `hwdec-current`, video parameters, requested and queried settings are shown per pane. GPU decoding is preferred (`hwdec=auto-safe`) but explicitly may fall back to software. The output format hint `rgba8` is NOT a proven swapchain result. Screenshot capture is not a raw GPU texture inspection API.
- FFprobe reads metadata off the GUI thread (plus FFmpeg zscale processes independently from display to generate RGB reference PNGs).
- Main timeline uses the first loaded, **visible** video as master; other players seek against relative `time-pos` plus user offset. Each live pane still owns its own clock; the controller checks observed video PTS every 150 ms, reports mismatch, and re-seeks when error exceeds 100 ms or 2 frames. This is **best-effort coarse synchronization**, NOT a genlocked compositor nor an exact-frame deterministic scheduler.
- While paused, frame-step on master uses `frame-step` / `frame-back-step`, then other pane(s) seek to the new master PTS. This is only deterministic if frame timing and seek results are verified for the actual files.
- Bounded demux cache (32 MiB forward + 8 MiB backward) and video decoder queue (64 MiB/6 frames) per pane are requested; decoder's own GPU surfaces are not bounded by these limits. UI uses native overlays and a separate non-blocking probe task.

## Direct mode (policy, not claimed perfect matching)

`SDR YCbCr bitstream -> libavcodec (via mpv) -> correct tagged range/matrix -> libplacebo RGB -> D3D11 sRGB swapchain request -> DWM -> display`.

Ordinary RGB source -> libmpv RGB frame -> output shader. Disables app ICC, embedded ICC, interpolation, debanding, requested dither, extra gamma adjustment (`sdr-adjust-gamma=no`), and third-party scripts.  `target-prim=auto` and `target-trc=auto` **may still adapt wide-gamut or HDR**, so tagged HDR/wide-gamut videos are rejected, not secretly treated as direct SDR. The GPU may still apply chroma scaling, surface format conversion, output encoding, screen adaptation or rounding. These need *numeric verification*, not an undocumented assumption.

Other possible transformations: video scaling at Fit mode, chroma spatial reconstruction, bit-depth quantization, Windows Advanced Color / SDR Automatic Color Management and monitor gamut/driver calibration. For genuine byte comparison use 100% native physical pixels and an explicitly controlled display.

## Diagnostic mode

Overrides use the documented libmpv `vf=format=colormatrix=...:colorlevels=...:convert=no` filter: **reinterpreting** source tags, not performing a creative conversion. Diagnostics report both source `video-dec-params` and selected `video-params`. There is no unlabelled gamma adjustment. HDR/wide-gamut remains blocked in this release.

## Known gaps

1. No Windows binary generated in Linux; PySide6 and libmpv are absent here. Runtime GUI/child-HWND/D3D11 API contract is unverified.
2. Native child mpv HWND may consume mouse input: toolbar pan/zoom shortcuts work independently, but mouse drag/wheel requires Windows testing or a native input hook/Qt overlay.
3. GPU texel/swapchain readback absent; actual rendered pixel pipeline cannot be signed off numerically. Screenshot reference remains a weaker proxy.
4. VFR seeks and multiple decoder clocks are not exact at frame granularity; no unified GPU presentation scheduler.
5. HDR PQ/HLG and tagged BT.2020 or P3 sources are detected and blocked, not converted. Color Managed mode is intentionally not advertised.
6. Frame-level side data not automatically inspected on every frame during playback (the source stream's HDR side data is shown if present); content with untagged HDR or midstream metadata changes needs validation.
7. No native Win GPU/CPU telemetry collector (frame-drop count + PTS drift available; Windows performance counters externally).

## Sources used when selecting stack

- https://mpv.io/manual/stable/ (mpv versions/options, D3D11, color policies, `--wid`)
- https://github.com/mpv-player/mpv/blob/master/DOCS/man/vf.rst (video parameter override semantics)
- https://learn.microsoft.com/en-us/windows/win32/direct3darticles/high-dynamic-range (Windows Advanced Color / DWM)
- https://learn.microsoft.com/en-gb/windows/win32/wcs/advanced-color-icc-profiles (Windows auto color management)
- https://ffmpeg.org/ffmpeg-filters.html#zscale (explicit YCbCr -> RGB reference conversion)
- https://www.faststone.org/FSViewerDetail.htm (FastStone announces embedded-ICC CMS option; undocumented display details require experiment)
