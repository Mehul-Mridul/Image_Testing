# v5: 7zr.exe pinned-URL and checksum repair

- Root cause: mutable `https://www.7-zip.org/a/7zr.exe` returned 26.04 (SHA256 256feca8...), while v4 expected 26.05 (SHA256 9bf582...).
- New downloader: `https://github.com/ip7z/7zip/releases/download/26.05/7zr.exe`, with official SourceForge 26.05 fallback.
- Both source files are subjected to pinned checksum verification; unknown local copies are quarantined.
- Previously installed 26.04 is allowed only if it passes the published 26.04 SHA256.
- No other runtime versions or playback/color settings were changed.
- Tests are offline source-level only; a real Windows setup, EXE build, mpv/D3D11 rendering, and FastStone equivalence are NOT verified by these tests.
