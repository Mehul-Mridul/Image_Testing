# Third-party software sources and license review

This project does not include prebuilt third-party Windows binaries inside the distributed source ZIP. The Windows setup downloads these external components from recognized distribution locations:

- **FFmpeg**: https://ffmpeg.org/ ; Windows binary distributor https://www.gyan.dev/ffmpeg/builds/ ; licenses https://ffmpeg.org/legal.html . Depending on build options, FFmpeg is under LGPL/GPL and may contain separately licensed dependencies. You must review the selected build's configuration and redistribution requirements.
- **mpv/libmpv**: https://mpv.io/ ; Windows builder https://sourceforge.net/projects/mpv-player-windows/files/libmpv/ ; repository https://github.com/mpv-player/mpv ; build options and licenses vary and may include GPL. libplacebo and other dependencies have their own licenses.
- **PySide6 / Qt**: https://doc.qt.io/qtforpython-6/ ; licenses https://www.qt.io/licensing/ . Compliance with LGPL/commercial terms must be independently assessed before redistribution.
- **uv**: https://docs.astral.sh/uv/ ; licensed under Apache-2.0 or MIT.
- **7-Zip**: https://www.7-zip.org/ ; licenses https://www.7-zip.org/license.txt .
- **NumPy / Pillow / PyInstaller / pytest**: inspect installed wheel metadata for exact copyright, licenses, and applicable notices.

The created PyInstaller distribution includes the native FFmpeg and libmpv binaries in `bin`, plus Python and Qt runtime binaries. End users of this distribution need not install Python or FFmpeg separately. You are responsible for shipping the notices, corresponding sources and other compliance artifacts mandated by each specific version/build you redistribute.
