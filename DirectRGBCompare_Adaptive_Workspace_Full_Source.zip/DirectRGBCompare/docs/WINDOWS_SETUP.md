# Windows setup and fault isolation

## Requirements

- Windows 10/11 x64, non-HDR SDR display for initial color comparisons, working D3D11 driver, at least a few GB free storage and internet access for first-time installation.
- Install from a directory you own (`C:\DirectRGBCompare` is easier than a network drive or a very long path).
- Start `RUN_FIRST.bat`. Do not manually install Python, FFmpeg, or random DLLs.

## What one click actually does

`scripts/Install-And-Build.ps1` verifies these runtime sources:

| Package | Source | Verification |
|---|---|---|
| uv 0.13.7 Windows x64 | `releases.astral.sh` (Astral) | pinned published SHA256 (archive verified locally) |
| FFmpeg 9.0.2 release essentials (ffmpeg.exe, ffprobe.exe) | GitHub `GyanD/codexffmpeg` release mirror; Gyan `builds/packages` fallback | pinned SHA256 `4705843c...`, verified before extraction |
| mpv dev x86_64 dated 2026-11-01 | SourceForge shinchiro mpv-player-windows `libmpv` build | pinned SHA256 `30d3f9fa...` |
| 7zr.exe 26.05 | Immutable GitHub `ip7z/7zip` 26.05 asset; versioned SourceForge fallback | pinned SHA256 `9bf582b8...`. Already installed 26.04 accepted only if matching verified publisher SHA256 `256feca8...`. |

**Installer fix 4, 2026-11-07 (7zr.exe SHA mismatch):** The prior script requested the mutable `https://www.7-zip.org/a/7zr.exe` URL, which returned the legitimate 26.04 build (SHA256 `256feca8e274e5da655e2a284fabafd9f554365eb164862089dacd4e8276d282`) while the installer expected the 26.05 SHA256 (`9bf582b894dfa665f852d7e9112b02290a1c303c2d95a21fcdc41ffcb03143b7`). The installer now uses explicit 26.05 release URLs, checks the checksum before executing, and safely reuses an already installed 26.04 extractor only if it matches its separately verified official hash. Unrecognized executable hashes are quarantined, not executed. This correction is covered by source regression checks; full Windows end-to-end execution remains unverified.

**Installer fix 3, 2026-11-07 (remote connection reset):** A Windows user reported that Gyan closed an `Invoke-WebRequest` connection during the ~109 MB FFmpeg ZIP download. The installer now uses the pinned FFmpeg 9.0.2 **~34 MB 7z** archive, first trying GitHub's publisher mirror then Gyan's immutable archive URL. It invokes `curl.exe` with retries and byte-range resume (`--continue-at -`) and preserves `.part` between failed attempts; on systems without curl, it attempts Windows BITS. The archive must match publisher SHA256 `4705843ccaaf54257c16ad90f3e952ece33c17df964ecf7bfdbb0f49c7171077`, so mirror switching cannot silently substitute another build. Successful previously extracted `vendor/bin/ffmpeg.exe` and `ffprobe.exe` are reused. You may also place a manually downloaded copy of that **exact** 7z file in `.downloads/ffmpeg-9.0.2-essentials_build.7z`; it will be checked before extraction. The previous ~109 MB ZIP is not used. This change has passed offline tests but not a complete Windows network setup run.

**Installer fix 2, 2026-11-07 (native command arguments):** The previous installer used a function signature containing `[string[]]$args`, even though `$args` is an automatic PowerShell variable. In the reported Windows PowerShell 5.1 run, `uv.exe` was started with no `--version` argument, printed its usage help, and returned exit code 2. The corrected installer calls `Test-Executable -ExecutablePath $uvExe -CommandArguments @('--version')` and splats `@CommandArguments` into the child process. It also avoids `Select-Object -First 1` on native program output, which can cause upstream native-process cancellation. Existing verified downloads and `.tools/uv.exe` are retained. This was reviewed and covered by offline regression tests; a complete Windows PowerShell execution is still unverified in the authoring environment.

**Installer fix, 2026-11-07:** The preceding Windows installer had `Invoke-WebRequest ... .Content` for text SHA256 sidecars, which may be returned in an unexpected representation by Windows PowerShell 5.1. This version does not interpret the uv checksum from a response object: it uses the publisher's pinned SHA256 `0cdc5b38fe5a8168ed6a25814f5ba43c21d313dd3187314fccb37b7cec46e021` for uv 0.13.7. FFmpeg's matching checksum is saved to disk and read as text, with a corrupt/stale archive retry. Checksums are still mandatory; verification has **not** been disabled. You can retain the existing `.downloads` cache; each archive is verified before extraction. On a SHA mismatch the cached file is discarded and downloaded again. The script was tested statically and with offline tests on Linux; the actual PowerShell process still requires a Windows PC.

The helper downloads into `.downloads`, places FFmpeg and libmpv into `vendor/bin`, creates `.venv` privately via uv (Python 3.12), runs unit and source media tests, checks that libmpv options are accepted, tries to decode a real video in a native Win32 D3D11 HWND, and runs PyInstaller. **No compiled EXE is shipped in this source ZIP.**

If download fails due to corporate firewall, VPN, TLS interception, network restriction, unavailable upstream servers, or antivirus quarantine, check the printed URL/error rather than silently bypassing verification. The script refuses incorrect checksums.

## If `ffprobe.exe not found` appears

1. You have launched the **old** build, or the new runtime download/build did not complete. Close the application.
2. Run `RUN_FIRST.bat`, confirm `vendor\bin\ffprobe.exe` and `dist\DirectRGBCompare\_internal\bin\ffprobe.exe` exist.
3. Launch the new `dist\DirectRGBCompare\DirectRGBCompare.exe`, not a previously copied shortcut or EXE.
4. If it still fails, run `CHECK_WINDOWS_GUI.bat` and check the displayed error. Do not place random FFprobe files into Windows system directories.

## D3D11 or libmpv failed

- `CHECK_WINDOWS_GUI.bat` exercises the **same native HWND and libmpv path** independently of the four-pane UI. Record its full error output.
- `tools/health_check.py` validates the current libmpv accepts every requested option before EXE packaging.
- Update the graphics driver; connect a real monitor; ensure Windows D3D11 is available. Verify `libmpv-2.dll` came from the pinned mpv dev package and is not a random binary.
- Unlike a video player, Direct mode deliberately refuses silently selecting a different renderer/color policy. A failed D3D11 path is an explicit error.

## First-run functional acceptance (must be done on Windows)

1. In SDR mode, open `assets\test_yuv420_bt709_limited.mkv` in pane 1. Verify video is actually displayed and metadata is shown.
2. Load two, three, then four videos. Play, pause, seek, step forward/back, move pane, resize, maximize, fit, 100%, 200%, pan and sync pan.
3. Confirm `hwdec-current`, `current-vo` and `video-target-params` in diagnostics. Software decoder fallback must be indicated, not inferred.
4. Run `CHECK_WINDOWS_GUI.bat` for the separate native renderer smoke test.
5. Compare exported FFmpeg reference PNG and renderer output at native pixel scaling; compare numerically. Test FastStone CMS OFF on the same monitor without HDR/ICC changes, record remaining differences.
6. Run 4K portrait stress (1–4 streams, repeated seek, resize) on the actual GPU. Monitor CPU/GPU/RAM and dropped frames; record failures.

**Do not mark FastStone color-matching, frame-lock synchronization, HDR fidelity or four 4K streams as passed without actual Windows measurements.**
