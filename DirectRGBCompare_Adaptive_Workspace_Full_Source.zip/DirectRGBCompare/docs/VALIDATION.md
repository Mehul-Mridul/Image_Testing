# Direct RGB validation protocol (Windows SDR)

## What is tested and what is not

- `python -m directrgb.validation chart assets/reference_chart.png` creates a **PNG with known RGB samples and no embedded ICC**. A separate JSON manifest identifies the swatches.
- `python -m directrgb.validation extract INPUT.mkv reference.png --at 1.5` decodes the **first frame at or after** that presentation timestamp, using `zscale` with explicit matrix/range. If either is missing, extraction fails instead of guessing. Select a fixed frame or use a truly lossless RGB fixture for the first test.
- `python -m directrgb.validation compare reference.png screenshot.png --heatmap diff.png > metrics.json` measures max/mean absolute differences, per-channel histogram, exact-pixel percentage, one-level differences and creates a heatmap. Images must be pixel-aligned and of equal shape.

**Critical:** The mpv `screenshot-to-file ... window` result represents mpv's video output render path, and may contain OSD/bars/scaling. It is NOT evidence of pixels after Windows DWM composition, and should not be described as the full pre-DWM swapchain readback. An independent compositor/PIX/RenderDoc/DXGI capture and colorimeter/photometer may be needed for definitive device-path verification. Screenshots obtained from different APIs can have different color handling.

## Exact human acceptance procedure

1. Use **one** Windows PC, **one** monitor, Windows **HDR OFF**, automatic color management OFF if exposed, known RGB output levels FULL on GPU, no Night Light, identical desktop gamma/monitor settings. Record GPU and driver, monitor, Windows edition/build, color profile, display resolution, DPI scaling, and mpv/FFmpeg version. Windows may still use calibration lookup tables and the display has its own behavior.
2. Open `assets/reference_chart.png` in FastStone, disable CMS under its Settings → CMS controls, set image display to 100%, disable any auto adjustments/sharpening. Do not infer undocumented source-code internals from this control.
3. Open equivalent lossless RGB FFV1 fixture in the app, **pause**, choose **100% native pixels**, inspect matching swatches. Ensure no image resizing, clipping, zoom-to-fit, rotated image or unexpected DPI scaling. If the frame is bigger than the pane, move the sampling area without resampling.
4. Capture the FastStone reference with a consistent acquisition path; capture the libmpv renderer (`Save renderer PNG`). Confirm cropped regions are aligned, exactly the same size and spatial orientation. Use `compare` on matched RGB regions. **A shared capture mechanism is preferable.** If Win capture is through DWM, document that capture point and any automatic management.
5. For YUV, compare `extract` lossless PNG to application screenshot at the **same exact PTS**, not an approximate nearest time. Select the sample on the master pane. Compare the `video-pts` in diagnostics and the exported frame PTS (may require `ffprobe -show_frames`). Verify no profile changes when switching 1/2/3/4 panes and fullscreen.
6. Test both full and limited range and BT.601/BT.709/BT.2020 NCL on **tagged** fixtures. For missing tags, record the renderer's inferred effective values; use Diagnostic mode only to inspect, not to hide differences.
7. Make separate per-pane screenshot captures of an **identical video in all four panes**, paused at identical presented PTS, at 100% zoom and with identical crop. Compare all six pairs. Document tolerances instead of inflating them to pass.
8. Stress-test four 2160×3840 clips and monitor CPU, hardware video decode usage, GPU memory usage, system memory, frame-drop counts, observed PTS errors, seeking and responsiveness, resize/100%/fit/fullscreen transitions. Try AV1, HEVC 10-bit SDR and variable frame rates if supported by GPU.

## Expected mathematical property

8-bit full-range decoded RGB -> 8-bit RGB surface should be byte-for-byte identical *in an expressly proven no-transform/no-scale test*. YCbCr conversion involves range expansion, chroma sample locations and reconstruction filters, bit-depth precision, float rounding, GPU output quantization and potentially dithering, so differences of 1+ code values can be explainable **only when measured and attributed**. Do not preemptively choose a blanket tolerance. Apply a lossless RGB-only test before YCbCr tests.

## Manual acceptance fields

| Criterion | Current status |
|---|---|
| Reference chart RGB pixels generated and unit-tested | Automated PASS (see `docs/TEST_RESULTS.json`) |
| FFV1 RGB decode round trip against chart | Automated PASS (Linux FFmpeg) |
| BT.709 limited YUV fixture reference extraction | Automated PASS (Linux FFmpeg), NOT a comparison with mpv output |
| FastStone CMS-OFF numeric match | NOT TESTED (Windows / FastStone needed) |
| 1-4 pane GUI playback and independent GPU frames | NOT TESTED (Windows / libmpv needed) |
| Fullscreen vs windowed color and DWM effects | NOT TESTED |
| 4K portrait x1/2/3/4 performance | NOT TESTED |
| Deterministic stepping of VFR clips | NOT TESTED; timestamp nearest-frame policy requires hardening |
| HDR output | NOT IMPLEMENTED; HDR and tagged wide gamut blocked rather than silently tone-mapped |

Any test not executed should remain NOT TESTED. A source-code policy is not proof of color correctness.
