# FFmpeg transfer repair v4, 2026-11-07

Windows install failure reported by user:

```
Downloading ffmpeg-release-essentials.zip ...
Invoke-WebRequest : Unable to read data from the transport connection:
An existing connection was forcibly closed by the remote host.
```

Installer fix: smaller immutable FFmpeg 9.0.2 essentials 7z archive, verified against Gyan publisher SHA256
`4705843ccaaf54257c16ad90f3e952ece33c17df964ecf7bfdbb0f49c7171077`; sourced from the Gyan GitHub release mirror or the Gyan package repository. Uses `curl.exe` with retry and resume, retaining `.part` across failures; BITS fallback when curl.exe is not available. Keeps the previous `uv` and native-command argument repairs.

**Tests**: 30 offline automated Python tests passed on Linux on 2026-11-07. They do not execute Windows PowerShell, D3D11, or FastStone. Windows download, packaging and GUI behavior remain unverified. The original 19-pass test report in `TEST_RESULTS.json` is historical, not the latest v4 count.

If both trusted HTTPS hosts are blocked, no downloader can guarantee success. Manually download the *exact* publisher archive and place it at `.downloads/ffmpeg-9.0.2-essentials_build.7z` before rerunning. The installer still checks its SHA256.
