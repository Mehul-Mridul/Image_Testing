@echo off
setlocal
cd /d "%~dp0"
if not exist ".venv\Scripts\python.exe" (
  echo Run RUN_FIRST.bat first to prepare Python and Qt.
  pause
  exit /b 1
)
".venv\Scripts\python.exe" tools\vnext_gui_smoke.py
if errorlevel 1 (
  echo Native Qt GUI smoke test failed. The application must not be accepted without fixing the issue.
  pause
  exit /b 1
)
echo GUI shell smoke test passed. Native D3D11 rendering and FastStone RGB still need independent Windows verification.
pause
