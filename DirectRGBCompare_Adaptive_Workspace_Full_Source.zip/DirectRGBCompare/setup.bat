@echo off
call "%~dp0RUN_FIRST.bat"
