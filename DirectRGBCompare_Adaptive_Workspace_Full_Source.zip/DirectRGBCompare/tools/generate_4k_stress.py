"""Generate four native 2160x3840 portrait SDR clips for a *future* Windows stress run.

NOT run by the Linux tests. Requires H.264 encoder libx264 in your FFmpeg build.
"""
import argparse
from pathlib import Path
import subprocess
from directrgb.paths import bundled_tool


def main():
    p = argparse.ArgumentParser()
    p.add_argument('--output', default='stress_4k')
    p.add_argument('--count', type=int, choices=(1,2,3,4), default=4)
    p.add_argument('--seconds', type=int, default=5)
    args = p.parse_args()
    dest = Path(args.output); dest.mkdir(parents=True,exist_ok=True)
    for i in range(args.count):
        name = dest/f'portrait_4k_{i+1}.mp4'
        cmd = [bundled_tool('ffmpeg'), '-hide_banner','-nostdin','-v','error','-y',
               '-f','lavfi','-i',f'testsrc2=s=2160x3840:r=30:d={args.seconds}',
               '-vf',f'hue=h={i*35},format=yuv420p', '-c:v','libx264',
               '-preset','veryfast','-crf','25','-threads','4',
               '-color_range','tv','-colorspace','bt709','-color_primaries','bt709',
               '-color_trc','bt709','-movflags','+faststart',str(name)]
        print('Generating',name,flush=True)
        subprocess.run(cmd,check=True)
    print('Load generated streams in GUI and record actual CPU/GPU/VRAM/drop stats; none are pre-certified.')

if __name__=='__main__':
    main()
