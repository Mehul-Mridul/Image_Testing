"""Real-Windows GUI and native D3D11 smoke test. Not an RGB proof.

Run CHECK_ADAPTIVE_GUI.bat after Windows installer has provisioned dependencies.
Writes detailed JSON results to docs/adaptive_windows_smoke_results.json.
"""
from __future__ import annotations
import json
from pathlib import Path
import sys
from time import monotonic

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    if sys.platform!='win32':
        print('NOT RUN: requires Windows and a real D3D11 display')
        return 2
    from PySide6.QtCore import QTimer
    from PySide6.QtWidgets import QApplication
    from directrgb.vnext_gui import MainWindow

    app=QApplication([])
    w=MainWindow();w.show()
    file=str(ROOT/'assets'/'test_yuv420_bt709_limited.mkv')
    checks=[]
    seq=[2,3,4,2]
    started=monotonic()
    phase_start=started
    current=-1

    def start_next():
        nonlocal phase_start,current
        current+=1
        if current>=len(seq):
            finalize(0)
            return
        phase_start=monotonic()
        n=seq[current]
        w.load_paths(0,[file]*n)
        print('Requested replacement of',n,'panes')

    def finalize(code):
        result={
            'platform':sys.platform,
            'test':'actual native Qt + libmpv loading; not color/output numerical verification',
            'phases':checks,
            'pipeline':'unchanged v5 decoder and color policy',
            'visible_video_pixels_captured':'NO',
            'faststone_match':'NOT VERIFIED',
            'four_4k_stress':'NOT TESTED',
            'result':'PASSED' if code==0 else 'FAILED'
        }
        dest=ROOT/'docs'/'adaptive_windows_smoke_results.json'
        dest.write_text(json.dumps(result,indent=2),encoding='utf8')
        print(json.dumps(result,indent=2))
        w.close()
        app.exit(code)

    def poll():
        if current<0:return
        batch=w.batch_scheduler.active
        if batch and batch.complete:
            phase={'pane_count':seq[current],'seconds_to_backend_ready':round(monotonic()-phase_start,3),
                   'statuses':dict(batch.statuses),'renderer_reuse':
                   {i:m.reused_renderer for i,m in w._load_metrics.items()},
                   'layout':w.canvas.previous.name if w.canvas.previous else 'unavailable'}
            checks.append(phase)
            if batch.valid and all(w.panes[i].player for i in range(seq[current])):
                QTimer.singleShot(100,start_next)
            else:
                finalize(1)
        elif monotonic()-phase_start>25:
            checks.append({'pane_count':seq[current],'timeout':True,
                           'statuses':dict(batch.statuses) if batch else {}})
            finalize(1)

    timer=QTimer(w)
    timer.setInterval(100)
    timer.timeout.connect(poll)
    timer.start()
    QTimer.singleShot(350,start_next)
    return app.exec()


if __name__=='__main__':
    raise SystemExit(main())
