"""Offline runtime preflight: run before packaging and optionally by developers."""
import json
import subprocess
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from directrgb.paths import bundled_tool, mpv_library_candidates


def main():
    report = {'os': sys.platform, 'executables': {}, 'dll': None, 'status': 'OK'}
    for name in ('ffmpeg', 'ffprobe'):
        cmd = bundled_tool(name)
        proc = subprocess.run([cmd, '-version'], capture_output=True, text=True,
                              timeout=20, check=True)
        report['executables'][name] = {'path': cmd, 'version': proc.stdout.splitlines()[0]}
    if sys.platform == 'win32':
        import ctypes
        from directrgb.mpv_native import load_mpv
        lib = load_mpv()
        report['dll'] = {'loaded': True, 'client_api_version': hex(lib.mpv_client_api_version())}
        # Validate the current native libmpv build accepts every configured option
        # before an end user attempts to open a video.
        from directrgb.policy import DIRECT_OPTIONS
        handle = lib.mpv_create()
        if not handle:
            raise RuntimeError('mpv_create failed')
        try:
            for key, val in DIRECT_OPTIONS.items():
                status = lib.mpv_set_option_string(handle, key.encode(), val.encode())
                if status < 0:
                    msg = lib.mpv_error_string(status)
                    raise RuntimeError('Unsupported libmpv option ' + key + '=' + val + ': ' +
                                       (msg.decode(errors='replace') if msg else str(status)))
            init = lib.mpv_initialize(handle)
            if init < 0:
                msg = lib.mpv_error_string(init)
                raise RuntimeError('mpv_initialize failed: ' +
                                   (msg.decode(errors='replace') if msg else str(init)))
            report['dll']['options_accepted'] = len(DIRECT_OPTIONS)
            report['dll']['initialized'] = True
        finally:
            lib.mpv_terminate_destroy(handle)
        if ctypes.sizeof(ctypes.c_void_p) != 8:
            raise RuntimeError('Windows build must be x64.')
    print(json.dumps(report, indent=2))


if __name__ == '__main__':
    main()
