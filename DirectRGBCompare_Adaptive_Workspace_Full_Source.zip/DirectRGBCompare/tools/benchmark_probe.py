"""Measure this platform's FFprobe latency using shipped fixture, no invented timings.
Does not measure libmpv, D3D, UI latency or 4K performance.
"""
from pathlib import Path
from time import perf_counter
import json
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from directrgb.probe import probe_file_with_status


def main():
    source=str(ROOT/'assets'/'test_yuv420_bt709_limited.mkv')
    results=[]
    for _ in range(4):
        started=perf_counter()
        video,cached=probe_file_with_status(source)
        results.append({'seconds':round(perf_counter()-started,6),'cache_hit':cached,
                        'codec':video.codec,'eligibility':video.eligibility[0]})
    print(json.dumps({'platform':sys.platform,'fixture':Path(source).name,'results':results,
                      'caution':'Synthetic local fixture only; no Windows GUI or 4K claim.'},indent=2))


if __name__=='__main__':
    main()
