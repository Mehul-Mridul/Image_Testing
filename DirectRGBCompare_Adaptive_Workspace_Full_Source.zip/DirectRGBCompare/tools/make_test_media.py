"""Generate reproducible SDR test streams; no existing videos are altered."""
from pathlib import Path
import json
import subprocess
from directrgb.paths import bundled_tool
from directrgb.validation import make_chart, reference_png, compare_png


def run(cmd):
    p = subprocess.run(cmd, capture_output=True, text=True, timeout=180)
    if p.returncode:
        raise RuntimeError(f'Command {cmd!r} failed:\n{p.stderr[-1500:]}')


def main():
    root = Path(__file__).resolve().parent.parent / 'assets'
    root.mkdir(exist_ok=True)
    png = root / 'reference_chart.png'
    chart = make_chart(png)
    (root/'reference_chart.json').write_text(json.dumps(chart,indent=2),encoding='utf-8')
    ffmpeg = bundled_tool('ffmpeg')
    rgb = root / 'reference_rgb_ffv1.mkv'
    run([ffmpeg,'-hide_banner','-v','error','-y','-loop','1','-framerate','5',
         '-i',str(png),'-t','2','-c:v','ffv1','-pix_fmt','gbrp',str(rgb)])
    yuv = root / 'test_yuv420_bt709_limited.mkv'
    run([ffmpeg,'-hide_banner','-v','error','-y','-loop','1','-framerate','5',
         '-i',str(png),'-t','2','-vf',
         'format=gbrp,zscale=matrix=709:range=limited:filter=bilinear,format=yuv420p',
         '-c:v','ffv1','-level','3','-color_range','tv','-colorspace','bt709',
         '-color_primaries','bt709','-color_trc','bt709',str(yuv)])
    ref = root/'reference_rgb_decoded.png'
    reference_png(str(rgb),str(ref),0)
    stats = compare_png(str(png),str(ref))
    print('RGB FFV1 reference round-trip:',stats['max_absolute_rgb_difference'],'max code difference')
    assert stats['max_absolute_rgb_difference']==0
    print('Generated:',png,rgb,yuv,ref,sep='\n  ')

if __name__ == '__main__':
    main()
