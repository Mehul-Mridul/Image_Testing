"""Real Windows/D3D11 smoke test (not a FastStone/color-accuracy test).

Uses a real Qt native window and tries decoding a test video with libmpv.
Results depend on GPU, driver, session and display. Exits nonzero if unavailable.
"""
from __future__ import annotations
import json
from pathlib import Path
import sys
import time

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))


def main():
    if sys.platform != 'win32':
        print('Windows D3D11 smoke test: NOT RUN; current platform is ' + sys.platform)
        return 2
    from PySide6.QtWidgets import QApplication, QWidget
    from PySide6.QtCore import Qt
    from directrgb.mpv_native import MpvPanePlayer

    app = QApplication.instance() or QApplication([])
    host = QWidget()
    host.setWindowTitle('DirectRGB Compare - Runtime/Decoder Smoke Test')
    host.resize(800, 520)
    host.setAttribute(Qt.WidgetAttribute.WA_NativeWindow, True)
    host.show()
    app.processEvents()
    player = None
    try:
        player = MpvPanePlayer(int(host.winId()))
        source = root / 'assets' / 'test_yuv420_bt709_limited.mkv'
        player.load(str(source))
        target = time.monotonic() + 15.0
        configured = False
        errors = []
        while time.monotonic() < target:
            app.processEvents()
            errors.extend(e['message'] for e in player.drain_events() if e['error'] < 0)
            configured = player.get_bool('vo-configured') is True
            if configured and player.get_double('video-pts') is not None:
                break
            time.sleep(.05)
        details = player.runtime_diagnostics()
        result = {'backend': 'libmpv D3D11 gpu-next embedded HWND',
                  'vo_configured': configured,
                  'pts_available': player.get_double('video-pts') is not None,
                  'errors': errors,
                  'renderer_info': details,
                  'faststone_color_equivalence': 'NOT TESTED',
                  'actual_swapchain_color_space': 'NOT INSTRUMENTED',
                  'note': 'No visual or numerical output verification is done by this smoke test.'}
        print(json.dumps(result, indent=2))
        return 0 if result['vo_configured'] and result['pts_available'] and not errors else 1
    finally:
        if player: player.close()
        host.close()


if __name__ == '__main__':
    sys.exit(main())
