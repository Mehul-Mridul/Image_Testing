"""Native Qt GUI smoke test, must be run on a real Windows desktop.

This tests widget construction, folder navigation, command registration and
shortcut presence. A separate renderer smoke test handles libmpv/D3D11.
"""
import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))


def main():
    if sys.platform != 'win32':
        print('NOT RUN: PySide6/D3D11 Windows GUI qualification requires Windows.')
        return 2
    from PySide6.QtWidgets import QApplication
    from PySide6.QtCore import QTimer
    from directrgb.vnext_gui import MainWindow
    app=QApplication.instance() or QApplication([])
    win=MainWindow()
    win.show()
    ok=[]
    def verify():
        try:
            assert win.browser is not None
            assert win.browser.set_folder(str(ROOT/'assets'))
            assert win.actions.map.sequence('file.open_folder')
            assert win.actions.map.sequence('sync.here')
            assert win.browser_dock.isVisible()
            assert win.visible_count==2
            assert len(win.panes)==4
            ok.append(True)
            print('vNext Qt browser, shortcuts, 4-pane shell: PASS (native video not exercised)')
        except Exception as e:
            print('vNext GUI smoke test FAILED:',repr(e));ok.append(False)
        finally:
            win.close();app.quit()
    QTimer.singleShot(1800,verify)
    app.exec()
    return 0 if ok==[True] else 1

if __name__=='__main__':raise SystemExit(main())
