"""Produce a fresh, platform-specific offline diagnostics report without overwriting
baseline results or misreporting GPU/FastStone tests as successful.
"""
import json
from pathlib import Path
import platform
import subprocess
import sys

root = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(root))
from directrgb.paths import bundled_tool
from directrgb.validation import compare_png


def main():
    run = subprocess.run([sys.executable, '-m', 'pytest', '-q', str(root/'tests')],
                         cwd=root, capture_output=True, text=True, timeout=120)
    def version(name):
        try:
            return subprocess.run([bundled_tool(name), '-version'],
                                  capture_output=True, text=True, timeout=10,
                                  check=True).stdout.splitlines()[0]
        except Exception as exc:
            return 'UNAVAILABLE: ' + str(exc)
    base = root/'assets/reference_chart.png'
    sources = {
        'lossless_rgb_ffv1': root/'assets/reference_rgb_decoded.png',
        'bt709_limited_yuv_source_vs_png': root/'assets/reference_yuv709_decoded.png',
        'bt601_full_yuv_source_vs_png': root/'assets/reference_yuv601_decoded.png',
    }
    comparisons = {}
    for name, asset in sources.items():
        if base.exists() and asset.exists():
            r = compare_png(str(base), str(asset))
            comparisons[name] = {k:r[k] for k in (
                'max_absolute_rgb_difference', 'mean_absolute_rgb_difference',
                'exact_pixel_match_pct', 'pixels_with_all_channels_diff_le_1_pct')}
    report = {
        'platform': platform.platform(), 'python': sys.version.split()[0],
        'ffmpeg': version('ffmpeg'), 'ffprobe': version('ffprobe'),
        'unit_tests': {'exit_code': run.returncode, 'output': run.stdout.strip(),
                       'errors': run.stderr.strip()},
        'offline_reference_vs_reencoded_video': comparisons,
        'qualifier': 'YUV vs RGB differences may be caused by deliberate YUV subsampling, not the display pipeline.',
        'faststone_cms_off_match': 'NOT TESTED',
        'windows_gpu_direct_rgb_texel_readback': 'NOT TESTED',
        'windows_gui_four_video_4k': 'NOT TESTED',
        'windows_executable_distribution': 'NOT TESTED BY THIS SCRIPT',
    }
    dest = root / 'docs' / 'runtime_test_results.json'
    dest.write_text(json.dumps(report, indent=2), encoding='utf-8')
    print(json.dumps(report, indent=2))
    if run.returncode:
        sys.exit(run.returncode)


if __name__ == '__main__':
    main()
