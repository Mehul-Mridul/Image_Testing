@echo off
setlocal
cd /d "%~dp0"
title DirectRGB Compare - Restore vNext Folder Browser
if not "%~1"=="" (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY_UI_RECOVERY.ps1" -ProjectPath "%~1"
) else (
    powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0APPLY_UI_RECOVERY.ps1"
)
if errorlevel 1 (
    echo.
    echo ERROR: Recovery did not complete. Read the message above.
    echo You may drag your existing Adaptive DirectRGBCompare folder onto this BAT.
    pause
    exit /b 1
)
echo.
echo Repair applied. Open LAUNCH_CURRENT_SOURCE_DEBUG.bat from the selected project.
pause
