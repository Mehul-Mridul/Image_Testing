DIRECTRGB COMPARE — vNext file-browser UI recovery

This repair addresses two verified issues in the Adaptive Workspace package:
(1) the vNext browser was hidden by default on startup;
(2) source patches did not rebuild an old compiled EXE.

1. Extract this entire repair ZIP. Run APPLY_UI_RECOVERY.bat.
2. Choose/confirm the correct existing Adaptive Workspace project directory.
   You can drag its DirectRGBCompare folder onto APPLY_UI_RECOVERY.bat.
3. The script checks the original strict RGB core hashes, backs up files and
   updates only the vNext UI, settings, file browser and two test/launch scripts.
4. Run LAUNCH_CURRENT_SOURCE_DEBUG.bat from the repaired project folder.
   This launches run.py directly using the project's .venv Python, not an
   outdated EXE, and prints source module path/startup errors.
5. Press Ctrl+Shift+R to restore folder browser at any time. Ctrl+B toggles.
6. After confirming UI, run build_windows.bat to build an updated EXE.

If the patch refuses because source was modified or no adaptive workspace
exists, use the complete UI Recovery Full Source ZIP in a NEW directory.
The patch does not overwrite dist or your previous EXE, DLLs or source videos.

Source-level tests pass on Linux; Windows Qt controls, GPU playback and
FastStone CMS-OFF numerical matching are NOT tested in this environment.
