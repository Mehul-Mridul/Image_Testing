param([string]$ProjectPath = '')
$ErrorActionPreference = 'Stop'
$repairRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$payload = Join-Path $repairRoot 'payload'
$manifest = Get-Content (Join-Path $repairRoot 'BASELINES.json') -Raw | ConvertFrom-Json
if (!(Test-Path -LiteralPath (Join-Path $payload 'directrgb\vnext_gui.py'))) {
    throw 'Repair ZIP incomplete. Extract the entire package before applying.'
}
$downloads = Join-Path $env:USERPROFILE 'Downloads'
$candidates = @()
if ($ProjectPath) {
    $candidates += $ProjectPath
} else {
    $candidates += @(
        $repairRoot,
        (Join-Path $repairRoot 'DirectRGBCompare'),
        (Join-Path $downloads 'DirectRGBCompare_Adaptive_Workspace_Full_Source\DirectRGBCompare'),
        (Join-Path $downloads 'DirectRGBCompare_vNext_Full_Source\DirectRGBCompare'),
        (Join-Path $downloads 'DirectRGBCompare_Windows_Source_v5\DirectRGBCompare')
    )
}
$matches = @()
foreach ($candidate in $candidates) {
    if (!$candidate) { continue }
    if ((Test-Path -LiteralPath (Join-Path $candidate 'run.py')) -and
        (Test-Path -LiteralPath (Join-Path $candidate 'directrgb\adaptive_workspace.py')) -and
        (Test-Path -LiteralPath (Join-Path $candidate 'directrgb\vnext_gui.py'))) {
        $abs = (Resolve-Path -LiteralPath $candidate).Path
        if ($matches -notcontains $abs) { $matches += $abs }
    }
}
if ($matches.Count -eq 0) {
    throw 'Adaptive project not found. Extract this repair ZIP INSIDE your Adaptive DirectRGBCompare project folder beside run.py and run again. Do not apply to plain v5 or the older vNext-only project.'
}
if ($matches.Count -eq 1) {
    $project = $matches[0]
} else {
    Write-Host 'Multiple adaptive projects discovered. Choose the one you actually run:' -ForegroundColor Yellow
    for ($i=0; $i -lt $matches.Count; $i++) { Write-Host "  [$($i+1)] $($matches[$i])" }
    $selection = Read-Host 'Project number'
    $number = 0
    if (![int]::TryParse($selection,[ref]$number) -or $number -lt 1 -or $number -gt $matches.Count) { throw 'Invalid project selection.' }
    $project=$matches[$number-1]
}
Write-Host "\nRepair target: $project" -ForegroundColor Cyan
$confirm = Read-Host 'Apply UI recovery to THIS folder? Type YES'
if ($confirm -ne 'YES') { throw 'Cancelled without editing any files.' }
foreach($prop in $manifest.rgb_core.PSObject.Properties) {
    $path=Join-Path $project $prop.Name.Replace('/','\')
    if (!(Test-Path -LiteralPath $path -PathType Leaf)) {throw "RGB core file missing: $path"}
    $actual=(Get-FileHash -LiteralPath $path -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actual -ne $prop.Value) {throw "RGB core not expected baseline: $($prop.Name). Nothing changed."}
}
$sourceFiles = @(Get-ChildItem -LiteralPath $payload -Recurse -File)
$updates = @()
foreach($source in $sourceFiles) {
    $relative=$source.FullName.Substring($payload.Length+1)
    $target=Join-Path $project $relative
    $norm=$relative.Replace('\','/')
    $expectedProperty=$manifest.adaptive_files.PSObject.Properties[$norm]
    if ($expectedProperty -and (Test-Path -LiteralPath $target)) {
        $hash=(Get-FileHash -LiteralPath $target -Algorithm SHA256).Hash.ToLowerInvariant()
        $newHash=(Get-FileHash -LiteralPath $source.FullName -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $expectedProperty.Value -and $hash -ne $newHash) {
            throw "File has custom edits, not the expected adaptive baseline: $relative. Nothing changed. Use the full source ZIP in a separate folder instead."
        }
    }
    $updates+=@([pscustomobject]@{source=$source.FullName;target=$target;relative=$relative})
}
$backup = Join-Path $project ('backup\ui-recovery-'+(Get-Date -Format 'yyyyMMdd-HHmmss'))
New-Item -ItemType Directory -Force -Path $backup | Out-Null
$copied=@()
try {
    foreach($entry in $updates) {
        if (Test-Path -LiteralPath $entry.target) {
            $backupTarget=Join-Path $backup $entry.relative
            New-Item -ItemType Directory -Force (Split-Path -Parent $backupTarget) | Out-Null
            Copy-Item -LiteralPath $entry.target -Destination $backupTarget -Force
        }
    }
    foreach($entry in $updates) {
        New-Item -ItemType Directory -Force (Split-Path -Parent $entry.target) | Out-Null
        Copy-Item -LiteralPath $entry.source -Destination $entry.target -Force
        if ((Get-FileHash -LiteralPath $entry.source -Algorithm SHA256).Hash -ne (Get-FileHash -LiteralPath $entry.target -Algorithm SHA256).Hash) {
            throw "Failed verifying installed patch file: $($entry.relative)"
        }
        $copied+=@($entry)
    }
} catch {
    foreach($entry in $copied) {
        $back=Join-Path $backup $entry.relative
        if (Test-Path -LiteralPath $back) { Copy-Item -LiteralPath $back -Destination $entry.target -Force }
        elseif(Test-Path -LiteralPath $entry.target) { Remove-Item -LiteralPath $entry.target -Force }
    }
    throw
}
Write-Host "\nSUCCESS: $($updates.Count) files installed; RGB core unchanged." -ForegroundColor Green
Write-Host "Backup: $backup"
Write-Host "To verify the actual NEW source, run: $project\LAUNCH_CURRENT_SOURCE_DEBUG.bat"
Write-Host 'To build the upgraded GUI executable after verifying source, use build_windows.bat.'
Write-Host 'Existing dist/DirectRGBCompare.exe was NOT changed. Run the new build, not the old EXE.'
